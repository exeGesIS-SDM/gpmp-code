<?php

	# generating session and session id

	session_start();
	$sid = session_id();

	// Nasty HACK alert!
	// the code below is the equivalent of using the old and now removed php option 'register_globals On'
	// This website relies on it as it doesn't read $_GET and $_POST implicitly
	// added by Simon 2017-09-26, authorised by Crispin as a stop gap measure
	if (isset($_SESSION) and is_array($_SESSION)) foreach($_SESSION as $k=>$v) $$k=$v;
	if (isset($_COOKIE) and is_array($_COOKIE)) foreach($_COOKIE as $k=>$v) $$k=$v;
	if (isset($_POST) and is_array($_POST)) foreach($_POST as $k=>$v) $$k=$v;
	if (isset($_GET) and is_array($_GET)) foreach($_GET as $k=>$v) $$k=$v;

	error_reporting(~E_NOTICE);

	// added by Simon 2017-09-26, I also added the proper initialisation of the following variables:
	if(!isset($logout)) $logout='no';
	if(!isset($saveastxt)) $saveastxt='no';
	if(!isset($saveaspdf)) $saveaspdf='no';

	// added by Simon 2017-09-26, I also added the proper initialisation of the following variables:
	if(!isset($_SESSION['sessiontimelastuse'])) $_SESSION['sessiontimelastuse']=0;
	if(!isset($_SESSION['sessionrealm'])) $_SESSION['sessionrealm']='';
	if(!isset($_SESSION['sessionuseraccesslevel'])) $_SESSION['sessionuseraccesslevel']=0;
	if(!isset($_SESSION['sessionuserinitials'])) $_SESSION['sessionuserinitials']='';
	if(!isset($_SESSION['sessionuserid'])) $_SESSION['sessionuserid']=0;

	$timelastuse=$_SESSION['sessiontimelastuse'];
	$realm=$_SESSION['sessionrealm'];
	$useraccesslevel=$_SESSION['sessionuseraccesslevel'];
	$userinitials=$_SESSION['sessionuserinitials'];
	$userid=$_SESSION['sessionuserid'];

	if (!$timelastuse)
	{
		$timelastuse=time();
		$_SESSION['sessiontimelastuse']=$timelastuse;
		$realm=$timelastuse;
		$_SESSION['sessionrealm']=$realm;
	}

	$sitemaintenance = "no";

	$sitebasefile = "indexstart.php";


	if ($sitemaintenance=='yes')
	{
		echo 'GPMP excavation database is currently under maintenance - please try again later!';
		die;
	}

	# define connection string

	if	(!isset($_SERVER['PHP_AUTH_USER']))
	{
		authenticate($realm);
	}
	elseif (strpos($_SERVER['PHP_AUTH_USER'],"'")===FALSE and strpos($_SERVER['PHP_AUTH_PW'],"'")===FALSE)
	{
		// you need to create this file and add credential into it as per the $DB... variables below!
		include("db_credentials.php");
		$dbh = pg_connect("host=$DBhost dbname=$DBdbname user='$DBuser' password='$DBpassword' port=$DBport");

		$checkuser=checkuser(dbconnect($DBdbname, $DBuser, $DBpassword, $DBhost, $DBport), $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'], $_SERVER['QUERY_STRING']);
		if	(!$checkuser)
		{
			authenticate($realm);
			die;
		}
		$timenow=time();

		if ($logout=='yes')
		{
			session_unset();
			session_destroy();
			session_start();
			$timelastuse=0;
			$_SESSION['sessiontimelastuse']=$timelastuse;
		}

		$timeout=$timenow-$timelastuse;
		if ($timeout>600)
		{
			$newtime=time();
			$_SESSION['sessiontimelastuse']=$newtime;
			$realm=$newtime;
			$_SESSION['sessionrealm']=$realm;
			authenticate($realm);
			die;
		}
		else
		{
			$timelastuse=time();
			$_SESSION['sessiontimelastuse']=$timelastuse;
		}

	}
	else
	{
		authenticate($realm);
	}
	//debuglog($_GET,'$_GET');
	//debuglog($_POST,'$_POST');
	//debuglog($_COOKIE,'$_COOKIE');
	//debuglog($_SESSION,'$_SESSION');
	$PHP_AUTH_USER = $_SERVER['PHP_AUTH_USER']; //this will now populate db tables properly with the correct user details



	function debuglog($var,$title='') {
		if(is_array($var) or is_object($var)) $var=print_r($var,1);
		$file='output/GPMP_Debug.log';
		if($fp=fopen($file,'a+')) {
			fwrite($fp,date('Y-m-d H:i:s : ').$title.' : '.$var."\n");
			@fclose($fp);
		}
	}

	function authenticate($realm)
	{
		//header("WWW-Authenticate: Basic realm=\"$realm\"");
		header("WWW-Authenticate: Basic realm=\"GPMP Excavation Database\"");
		header("HTTP/1.0 401 Unauthorized");
		echo  "You  must  enter  a  username and  password  to  access  the gpmp excavation database!\n";

		exit;
	}

	# connect to database ...
	function dbconnect($DBdbname, $DBuser, $DBpassword, $DBhost, $DBport)
	{
		$dbh = pg_connect("dbname=$DBdbname user='$DBuser' password='$DBpassword' host=$DBhost port=$DBport")
			or die ("cannot connect to database<br>");
		return $dbh;
	}

	# check if the user is valid ...
	function checkuser($dbh, $user, $pwd, $url)
	{
		// check for username validity
		$sql = "SELECT COUNT(*) FROM fielddata.authentication
			WHERE authentication.name='$user' AND authentication.passwd='$pwd' AND authentication.valid=true;";
		@$ret = pg_exec($dbh, $sql);
		@$line = pg_fetch_row($ret, 0);

		if	($line[0] > 0)
		{
			$sql = "SELECT authentication.groupid, authentication.initials, authentication.dbuserid FROM fielddata.authentication WHERE authentication.name='$user' AND authentication.passwd='$pwd' AND authentication.valid=true;";
			@$stat = pg_exec($dbh, $sql);
			@$rows = pg_numrows($stat);
			@$data = pg_fetch_row($stat, 0);

			$useraccesslevel=$data[0];
			//$useraccesslevel=1;		// set database to readonly for everybody

			$userinitials=$data[1];
			$userid=$data[2];
			$_SESSION['sessionuseraccesslevel']=$useraccesslevel;
			$_SESSION['sessionuserinitials']=$userinitials;
			$_SESSION['sessionuserid']=$userid;

			# add login to user log
			$sql = "INSERT INTO fielddata.userlog (dbuserid, url) VALUES ('".$userid."', '".$url."');";
			@$stat = pg_exec($dbh, $sql);
			if ($userid > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}




// functions


/**
 * Exam if a remote file or folder exists
 *
 * This function is adopted from setec's version.
 * + What's new:
 * Error code with descriptive string.
 * More accurate status code handling.
 * Redirection tracing supported.
 *
 * @retval true resource exists
 * @retval false resource doesn't exist
 * @retval "1 Invalid URL host"
 * @retval "2 Unable to connect to remote host"
 * @retval "3 Status Code not supported: {STATUS_CODE REASON}"
 */



function remote_file_exists($url)
{
	# change spaces to %20
	$url=str_replace(" ", "%20", $url);

   $head = '';
   @$url_p = parse_url ($url);

   if (isset ($url_p['host']))
   { $host = $url_p['host']; }
   else
   {
       return '1 Invalid URL host';
   }

   if (isset ($url_p['path']))
   { $path = $url_p['path']; }
   else
   { $path = ''; }

   @$fp = fsockopen ($host, 80, $errno, $errstr, 20);
   if (!$fp)
   {
       return '2 Unable to connect to remote host';
   }
   else
   {
       $parse = parse_url($url);
       $host = $parse['host'];

       fputs($fp, 'HEAD '.$url." HTTP/1.1\r\n");
       fputs($fp, 'HOST: '.$host."\r\n");
       fputs($fp, "Connection: close\r\n\r\n");
       $headers = '';
       while (!feof ($fp))
       { $headers .= fgets ($fp, 128); }
   }
   fclose ($fp);

   // for debug
   // echo nl2br($headers);
   // echo $url;

   $arr_headers = explode("\n", $headers);
   if (isset ($arr_headers[0]))    {
       if(strpos ($arr_headers[0], '200') !== false)
       { return true; }
       if( (strpos ($arr_headers[0], '404') !== false) ||
           (strpos ($arr_headers[0], '410') !== false))
       { return false; }
       if( (strpos ($arr_headers[0], '301') !== false) ||
           (strpos ($arr_headers[0], '302') !== false))
       {
           preg_match("/Location:\s*(.+)\r/i", $headers, $matches);
           if(!isset($matches[1]))
               return false;
           $nextloc = $matches[1];
           return remote_file_exists($nextloc);
       }
   }
   preg_match('/HTTP.*(\d\d\d.*)\r/i', $headers, $matches);
   return '3 Status Code not supported'.
       (isset($matches[1])?": $matches[1]":'');
}


function isinteger($evaluationdata)
{
	$castevaluationdata=(int)$evaluationdata;

	if ($evaluationdata==(string)$castevaluationdata)
	{
		return true;
	}
	else
	{
		return false;
	}
}


function recordexists($dbh, $table, $column, $value)
{
	$sql = "SELECT $column FROM $table WHERE $table.valid=true AND $column='$value';";
	$stat = pg_exec($dbh, $sql);
	@$rows = pg_numrows($stat);

	if ($rows>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}


function combirecordexists($dbh, $table, $column1, $column2, $value1, $value2)
{
	$sql = "SELECT $column1, $column2 FROM $table WHERE $table.valid=true AND $column1='$value1' AND $column2='$value2';";
	@$stat = pg_exec($dbh, $sql);
	@$rows = pg_numrows($stat);

	if ($rows>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}


function checkforduplicates($dataarray, $value)
{
	if (in_array($value, $dataarray))
	{
		return true;
	}
	else
	{
		return false;
	}
}



if ($saveastxt==='yes' or $saveaspdf==='yes')
{
}
else
{
echo'<html>
		<head>
		<link rel="stylesheet" href="style.css" type="text/css">
		<title>gpmp excavation database  --- ver 1.82 @ 01jun2011 ---</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<script language="JavaScript">
		<!--
		function MM_reloadPage(init) {  //reloads the window if Nav4 resized
		  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
		    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
		  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
		}
		MM_reloadPage(true);
		// -->


		</script>
		</head>';
}

?>