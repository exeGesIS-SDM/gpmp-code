<?php

	echo'

		<div id="Layer2" style="position:absolute; left:'.$left.'px; top:'.($top+15).'px; width:800; height:555px; z-index:2; background-color: #000000; layer-background-color: #000000; border: 1px none #000000; overflow: visible">';


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE ADD DATA BAGREGISTER

		case "bagregister":

		# variables controlling the data input

		$tablename = "fielddata.bagregister";
		$columns = "6";
		$columnnames[1] = "bagprefix";
			$columnheader[1] = "season prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "6";
			$fieldcolumnwidth[1] = "80";
			$defaultvalue[1] = date('Y');
		$columnnames[2] = "bagnumber";
			$columnheader[2] = "bag number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "3";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "featurenumber";
			$columnheader[3] = "feature";
			$fieldtype[3] = "text";
			$fieldlength[3] = "5";
			$fieldsize[3] = "5";
			$fieldcolumnwidth[3] = "80";
		$columnnames[4] = "date";
			$columnheader[4] = "date";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "80";
		$columnnames[5] = "category";
			$columnheader[5] = "category";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listbagcategories.bagcategory FROM fielddata.listbagcategories WHERE listbagcategories.valid=true ORDER BY listbagcategories.bagcategory;";
			$fieldlength[5] = "10";
			$fieldcolumnwidth[5] = "80";
		$columnnames[6] = "comments";
			$columnheader[6] = "comments";
			$fieldtype[6] = "text";
			$fieldlength[6] = "255";
			$fieldsize[6] = "40";
			$fieldcolumnwidth[6] = "200";

		break;



////////// CASE ADD DATA BURIALFEATURES

		case "burialfeatures":

		# variables controlling the data input

		$tablename = "fielddata.burialfeatures";
		$columns = "3";
		$columnnames[1] = "burialnumber";
			$columnheader[1] = "burial";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "featurenumber";
			$columnheader[2] = "feature";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "5";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "burialtype";
			$columnheader[3] = "burial type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listburialtypes.burialtype FROM fielddata.listburialtypes WHERE listburialtypes.valid=true ORDER BY listburialtypes.burialtype;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "80";

		break;


////////// CASE ADD DATA BROADAREAS

		case "broadareas":

		# variables controlling the data input
		$tablename = "fielddata.broadareas";
		$keyidname = "broadareas.broadareaid";
		$tablewidth = 800;
		$columns = "2";
		$columnnames[1] = "broadareacode";
			$columnheader[1] = "broad area code";
			$fieldtype[1] = "text";
			$fieldlength[1] = 5;
			$fieldsize[1] = 6;
			$fieldcolumnwidth[1] = 80;
		$columnnames[2] = "broadareaname";
			$columnheader[2] = "broad area name";
			$fieldtype[2] = "text";
			$fieldlength[2] = 50;
			$fieldsize[2] = 50;
			$fieldcolumnwidth[2] = 160;

		$subtables = 1;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.broadareaslocalareas";
		$subkeyidname[1] = "broadareaid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "localareacode";
			$subcolumnheader[1][1] = "local area code(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT localareas.localareacode FROM fielddata.localareas WHERE localareas.valid=true ORDER BY localareas.localareacode;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "80";
		break;


////////// CASE ADD DATA CD INVENTORY

		case "cdinventory":

		# variables controlling the data input

		$tablename = "fielddata.cdinventory";
		$columns = "6";
		$columnnames[1] = "storagemedium";
			$columnheader[1] = "storage medium";
			$fieldtype[1] = "dropdown";
			$dropdownsql[1] = "SELECT DISTINCT liststoragemediums.storagemedium FROM fielddata.liststoragemediums WHERE liststoragemediums.valid=true ORDER BY liststoragemediums.storagemedium;";
			$fieldlength[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "number";
			$columnheader[2] = "number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "4";
			$fieldsize[2] = "4";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "contents";
			$columnheader[3] = "contents";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "80";
			$fieldcolumnwidth[3] = "400";
		$columnnames[4] = "giza";
			$columnheader[4] = "in Giza";
			$fieldtype[4] = "checkbox";
			$fieldcolumnwidth[4] = "30";
		$columnnames[5] = "boston";
			$columnheader[5] = "in Boston";
			$fieldtype[5] = "checkbox";
			$fieldcolumnwidth[5] = "30";
		$columnnames[6] = "newyork";
			$columnheader[6] = "in New York";
			$fieldtype[6] = "checkbox";
			$fieldcolumnwidth[6] = "30";

		break;



////////// CASE ADD DATA DRAWING LOG

		case "drawinglog":

		# variables controlling the data input

		$tablename = "fielddata.drawinglog";
		$keyidname = "drawinglog.drawingid";
		$tablewidth = 800;
		$columns = 18;
		$columnnames[1] = "season";
			$columnheader[1] = "season";
			$fieldtype[1] = "dropdown";
			$dropdownsql[1] = "SELECT DISTINCT listdrawingseasons.seasonyear FROM fielddata.listdrawingseasons WHERE listdrawingseasons.valid=true ORDER BY listdrawingseasons.seasonyear;";
			$fieldlength[1] = "5";
			$fieldcolumnwidth[1] = "60";
			$defaultvalue[1] = "2009";
		$columnnames[2] = "drawingnumber";
			$columnheader[2] = "drawing number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "3";
			$fieldcolumnwidth[2] = "40";
		$columnnames[3] = "area";
			$columnheader[3] = "area";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "date";
			$columnheader[4] = "date";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "70";
		$columnnames[5] = "drawinglabel";
			$columnheader[5] = "description";
			$fieldtype[5] = "text";
			$fieldlength[5] = "255";
			$fieldsize[5] = "25";
			$fieldcolumnwidth[5] = "150";
		$columnnames[6] = "scale";
			$columnheader[6] = "scale (1:X)";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listscales.scale FROM fielddata.listscales WHERE listscales.valid=true ORDER BY listscales.scale;";
			$fieldlength[6] = "4";
			$fieldcolumnwidth[6] = "50";
		$columnnames[7] = "checked";
			$columnheader[7] = "checked?";
			$fieldtype[7] = "dropdown";
			$dropdownsql[7] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[7] = "4";
			$fieldcolumnwidth[7] = "30";
			$defaultvalue[7] = "no";
		$columnnames[8] = "cd";
			$columnheader[8] = "CD/DVD storage";
			$fieldtype[8] = "dropdown";
			$dropdownsql[8] = "SELECT DISTINCT cdinventory.number FROM fielddata.cdinventory WHERE cdinventory.valid=true ORDER BY cdinventory.number;";
			$fieldlength[8] = "4";
			$fieldcolumnwidth[8] = "30";
		$columnnames[9] = "drawingtype";
			$columnheader[9] = "drawing type";
			$fieldtype[9] = "dropdown";
			$dropdownsql[9] = "SELECT DISTINCT listdrawingtypes.drawingtype FROM fielddata.listdrawingtypes WHERE listdrawingtypes.valid=true ORDER BY listdrawingtypes.drawingtype;";
			$fieldlength[9] = "8";
			$fieldcolumnwidth[9] = "80";
			$defaultvalue[9] = "field";
		$columnnames[10] = "portfolionumber";
			$columnheader[10] = "portfolio number";
			$fieldtype[10] = "dropdown";
			$dropdownsql[10] = "SELECT DISTINCT listportfolios.portfolionumber FROM fielddata.listportfolios WHERE listportfolios.valid=true ORDER BY listportfolios.portfolionumber;";
			$fieldlength[10] = "4";
			$fieldcolumnwidth[10] = "30";
		$columnnames[11] = "locationoriginal";
			$columnheader[11] = "location of original";
			$dropdownsql[11] = "SELECT DISTINCT listlocations.location FROM fielddata.listlocations WHERE listlocations.valid=true ORDER BY listlocations.location;";
			$fieldlength[11] = "8";
			$fieldcolumnwidth[11] = "80";
			$startnewline[11] = "yes";
		$columnnames[12] = "copied";
			$columnheader[12] = "copied?";
			$fieldtype[12] = "dropdown";
			$dropdownsql[12] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[12] = "4";
			$fieldcolumnwidth[12] = "30";
			$defaultvalue[12] = "no";
		$columnnames[13] = "scanned";
			$columnheader[13] = "scanned?";
			$fieldtype[13] = "dropdown";
			$dropdownsql[13] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[13] = "4";
			$fieldcolumnwidth[13] = "30";
			$defaultvalue[13] = "no";
		$columnnames[14] = "cropped";
			$columnheader[14] = "cropped?";
			$fieldtype[14] = "dropdown";
			$dropdownsql[14] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[14] = "4";
			$fieldcolumnwidth[14] = "30";
			$defaultvalue[14] = "no";
		$columnnames[15] = "renamed";
			$columnheader[15] = "renamed?";
			$fieldtype[15] = "dropdown";
			$dropdownsql[15] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[15] = "4";
			$fieldcolumnwidth[15] = "30";
			$defaultvalue[15] = "no";
		$columnnames[16] = "burnttocd";
			$columnheader[16] = "burnt to CD?";
			$fieldtype[16] = "dropdown";
			$dropdownsql[16] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[16] = "4";
			$fieldcolumnwidth[16] = "60";
			$defaultvalue[16] = "no";
		$columnnames[17] = "scanuploaded";
			$columnheader[17] = "scan uploaded?";
			$fieldtype[17] = "dropdown";
			$dropdownsql[17] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[17] = "4";
			$fieldcolumnwidth[17] = "60";
			$defaultvalue[17] = "no";
		$columnnames[18] = "drawingsenttoboston";
			$columnheader[18] = "date drawing sent to boston";
			$fieldtype[18] = "text";
			$fieldlength[18] = "10";
			$fieldsize[18] = "10";
			$fieldcolumnwidth[18] = "120";

		$subtables = 3;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:250px; width:220px; height:150px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.drawinglogsupervisors";
		$subkeyidname[1] = "drawingid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "supervisor";
			$subcolumnheader[1][1] = "artist(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "80";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:250px; width:200px; height:300px; z-index:3; overflow: auto";
		$subtablename[2] = "fielddata.drawinglogsquares";
		$subkeyidname[2] = "drawingid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:500px; top:250px; width:200px; height:300px; z-index:4; overflow: auto";
		$subtablename[3] = "fielddata.drawinglogfeatures";
		$subkeyidname[3] = "drawingid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "featurenumber";
			$subcolumnheader[3][1] = "feature(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[3][1] = "6";
			$subfieldcolumnwidth[3][1] = "100";

		break;



////////// CASE ADD DATA ENTITY LOG

		case "entitylog":

		# variables controlling the data input

		$tablename = "fielddata.entitylog";
		$keyidname = "entitylog.entitynumber";
		$tablewidth = 760;
		$columns = "7";
		$columnnames[1] = "entitynumber";
			$columnheader[1] = "entity";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "entitytype";
			$columnheader[2] = "type";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "SELECT DISTINCT listentitytypes.entitytype FROM fielddata.listentitytypes WHERE listentitytypes.valid=true ORDER BY listentitytypes.entitytype;";
			$fieldlength[2] = "10";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "entityname";
			$columnheader[3] = "name";
			$fieldtype[3] = "text";
			$fieldlength[3] = "100";
			$fieldsize[3] = "15";
			$fieldcolumnwidth[3] = "80";
		$columnnames[4] = "excavationarea";
			$columnheader[4] = "area";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$fieldlength[4] = "10";
			$fieldcolumnwidth[4] = "80";
		$columnnames[5] = "date";
			$columnheader[5] = "date";
			$fieldtype[5] = "text";
			$fieldlength[5] = "10";
			$fieldsize[5] = "8";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "supervisor";
			$columnheader[6] = "creator";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[6] = "5";
			$fieldcolumnwidth[6] = "80";
		$columnnames[7] = "description";
			$columnheader[7] = "description";
			$fieldtype[7] = "text";
			$fieldlength[7] = "255";
			$fieldsize[7] = "10";
			$fieldcolumnwidth[7] = "50";

		$subtables = "4";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:240px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.entitylogdefinedbyfeaturenumbers";
		$subkeyidname[1] = "entitynumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "definedbyfeaturenumber";
			$subcolumnheader[1][1] = "defined by feature(s)";
			$subfieldtype[1][1] = "text";
			$subfieldlength[1][1] = "5";
			$subfieldsize[1][1] = "4";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:180px; width:220px; height:160px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.entitylogincludesentitynumbers";
		$subkeyidname[2] = "entitynumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "inclentitynumber";
			$subcolumnheader[2][1] = "includes entity / entities";
			$subfieldtype[2][1] = "text";
			$subfieldlength[2][1] = "5";
			$subfieldsize[2][1] = "3";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:160px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.entitylogincludesfeaturenumbers";
		$subkeyidname[3] = "entitynumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "inclfeaturenumber";
			$subcolumnheader[3][1] = "includes feature(s)";
			$subfieldtype[3][1] = "text";
			$subfieldlength[3][1] = "5";
			$subfieldsize[3][1] = "4";
			$subfieldcolumnwidth[3][1] = "100";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:360px; width:370px; height:140px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.entitylogchanges";
		$subkeyidname[4] = "entitynumber";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "3";
		$subcolumnnames[4][1] = "date";
			$subcolumnheader[4][1] = "modifications (date)";
			$subfieldtype[4][1] = "text";
			$subfieldlength[4][1] = "10";
			$subfieldsize[4][1] = "8";
			$subfieldcolumnwidth[4][1] = "50";
		$subcolumnnames[4][2] = "supervisor";
			$subcolumnheader[4][2] = "modifications (creator)";
			$subfieldtype[4][2] = "dropdown";
			$subdropdownsql[4][2] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[4][2] = "5";
			$subfieldcolumnwidth[4][2] = "50";
		$subcolumnnames[4][3] = "description";
			$subcolumnheader[4][3] = "modifications (description)";
			$subfieldtype[4][3] = "text";
			$subfieldlength[4][3] = "200";
			$subfieldsize[4][3] = "20";
			$subfieldcolumnwidth[4][3] = "100";

		break;



////////// CASE ADD DATA EXOTICMATERIALREGISTER

		case "exoticmaterialregister":

		# variables controlling the data input

		$tablename = "fielddata.exoticmaterialregister";
		$columns = "7";
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "materialcategory";
			$columnheader[3] = "category";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listexoticmaterialcategories.materialcategory FROM fielddata.listexoticmaterialcategories WHERE listexoticmaterialcategories.valid=true ORDER BY listexoticmaterialcategories.materialcategory;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "count";
			$columnheader[4] = "count";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "3";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "weightprefix";
			$columnheader[5] = "weight prefix";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listweightprefix.weightprefix FROM fielddata.listweightprefix WHERE listweightprefix.valid=true ORDER BY listweightprefix.weightprefix;";
			$fieldlength[5] = "4";
			$fieldcolumnwidth[5] = "40";
		$columnnames[6] = "weight";
			$columnheader[6] = "weight (g)";
			$fieldtype[6] = "text";
			$fieldlength[6] = "10";
			$fieldsize[6] = "8";
			$fieldcolumnwidth[6] = "40";
		$columnnames[7] = "comments";
			$columnheader[7] = "comments";
			$fieldtype[7] = "text";
			$fieldlength[7] = "100";
			$fieldsize[7] = "40";
			$fieldcolumnwidth[7] = "200";

		break;




////////// CASE ADD DATA FEATURE LOG

		case "featurelog":

		# variables controlling the data input

		$tablename = "fielddata.featurelog";
		$keyidname = "featurelog.featurenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "145";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "4";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.featurelogsquares";
		$subkeyidname[1] = "featurenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.featurelogareas";
		$subkeyidname[2] = "featurenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.featurelogsupervisors";
		$subkeyidname[3] = "featurenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:350px; width:300px; height:100px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.reassignedfeatures";
		$subkeyidname[4] = "featurenumber";
		$subtablewidth[4] = 250;
		$subcolumns[4] = "2";
		$subcolumnnames[4][1] = "oldfeaturenumber";
			$subcolumnheader[4][1] = "old feature number";
			$subfieldtype[4][1] = "text";
			$subfieldlength[4][1] = "25";
			$subfieldsize[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "100";
		$subcolumnnames[4][2] = "olddate";
			$subcolumnheader[4][2] = "old date";
			$subfieldtype[4][2] = "text";
			$subfieldlength[4][2] = "10";
			$subfieldsize[4][2] = "8";
			$subfieldcolumnwidth[4][2] = "80";

		break;





////////// CASE ADD DATA GROUPLOG

		case "grouplog":

		# variables controlling the data edit

		$tablename = "fielddata.grouplog";
		$keyidname = "grouplog.groupnumber";
		$tablewidth = 760;
		$columns = "4";
		$columnnames[1] = "groupnumber";
			$columnheader[1] = "group no.";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";
		$columnnames[4] = "phase";
			$columnheader[4] = "phase";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "80";


		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[1] = "fielddata.grouplogareas";
		$subkeyidname[1] = "groupnumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[2] = "fielddata.grouplogsupervisors";
		$subkeyidname[2] = "groupnumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "supervisor";
			$subcolumnheader[2][1] = "supervisor(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[2][1] = "5";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:300px; height:260px; z-index:6; overflow: auto";
		$subtablename[3] = "fielddata.grouplogfeatures";
		$subkeyidname[3] = "groupnumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "featurenumber";
			$subcolumnheader[3][1] = "feature(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[3][1] = "6";
			$subfieldcolumnwidth[3][1] = "100";


		break;






////////// CASE ADD DATA IMAGE COLLECTION

		case "imagecollection":

		# variables controlling the data input

		$tablename = "fielddata.imagecollection";
		$keyidname = "imagecollection.photoid";
		$tablewidth = 760;
		$columns = 15;
		$columnnames[1] = "imagenumber";
			$columnheader[1] = "number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "6";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "40";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "facing";
			$columnheader[4] = "facing";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listdirections.direction FROM fielddata.listdirections WHERE listdirections.valid=true ORDER BY listdirections.direction;";
			$fieldlength[4] = "7";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "photographer";
			$columnheader[5] = "photographer";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[5] = "5";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "cdnumber";
			$columnheader[6] = "cd number";
			$fieldtype[6] = "text";
			$fieldlength[6] = "3";
			$fieldsize[6] = "2";
			$fieldcolumnwidth[6] = "50";
		$columnnames[7] = "slideboxnumber";
			$columnheader[7] = "slide box no";
			$fieldtype[7] = "text";
			$fieldlength[7] = "3";
			$fieldsize[7] = "2";
			$fieldcolumnwidth[7] = "50";
		$columnnames[8] = "slideprimaryheading";
			$columnheader[8] = "primary heading";
			$fieldtype[8] = "text";
			$fieldlength[8] = "255";
			$fieldsize[8] = "140";
			$fieldcolumnwidth[8] = "150";
			$startnewline[8] = "yes";
		$columnnames[9] = "slidesecondaryheading";
			$columnheader[9] = "secondary heading";
			$fieldtype[9] = "text";
			$fieldlength[9] = "255";
			$fieldsize[9] = "140";
			$fieldcolumnwidth[9] = "150";
			$startnewline[9] = "yes";
		$columnnames[10] = "slidetertiaryheading";
			$columnheader[10] = "tertiary heading";
			$fieldtype[10] = "text";
			$fieldlength[10] = "255";
			$fieldsize[10] = "140";
			$fieldcolumnwidth[10] = "150";
			$startnewline[10] = "yes";
		$columnnames[11] = "lectureslide";
			$columnheader[11] = "lecture slide";
			$fieldtype[11] = "dropdown";
			$dropdownsql[11] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[11] = "4";
			$fieldcolumnwidth[11] = "30";
			$defaultvalue[11] = "no";
			$startnewline[11] = "yes";
		$columnnames[12] = "year";
			$columnheader[12] = "year";
			$fieldtype[12] = "text";
			$fieldlength[12] = "5";
			$fieldsize[12] = "4";
			$fieldcolumnwidth[12] = "50";
		$columnnames[13] = "photoregister";
			$columnheader[13] = "photo register";
			$fieldtype[13] = "text";
			$fieldlength[13] = "20";
			$fieldsize[13] = "20";
			$fieldcolumnwidth[13] = "80";
		$columnnames[14] = "phototype";
			$columnheader[14] = "phototype";
			$fieldtype[14] = "text";
			$fieldlength[14] = "20";
			$fieldsize[14] = "15";
			$fieldcolumnwidth[14] = "80";
		$columnnames[15] = "notes";
			$columnheader[15] = "notes";
			$fieldtype[15] = "text";
			$fieldlength[15] = "255";
			$fieldsize[15] = "60";
			$fieldcolumnwidth[15] = "110";

		$subtables = "5";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:250px; top:460px; width:220px; height:120px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.photologsquares";
		$subkeyidname[1] = "photoid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:500px; top:460px; width:220px; height:120px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.photologfeatures";
		$subkeyidname[2] = "photoid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "featurenumber";
			$subcolumnheader[2][1] = "feature(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[2][1] = "6";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:0px; top:600px; width:280px; height:120px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.photologspecialists";
		$subkeyidname[3] = "photoid";
		$subtablewidth[3] = 220;
		$subcolumns[3] = "2";
		$subcolumnnames[3][1] = "specialistcategory";
			$subcolumnheader[3][1] = "specialist category";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listspecialistcategories.specialistcategory FROM fielddata.listspecialistcategories WHERE listspecialistcategories.valid=true ORDER BY listspecialistcategories.specialistcategory;";
			$subfieldlength[3][1] = "7";
			$subfieldcolumnwidth[3][1] = "80";
		$subcolumnnames[3][2] = "specialistid";
			$subcolumnheader[3][2] = "specialist id";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = "20";
			$subfieldsize[3][2] = "14";
			$subfieldcolumnwidth[3][2] = "110";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:460px; width:220px; height:120px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.photologareas";
		$subkeyidname[4] = "photoid";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "1";
		$subcolumnnames[4][1] = "area";
			$subcolumnheader[4][1] = "area(s)";
			$subfieldtype[4][1] = "dropdown";
			$subdropdownsql[4][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "80";

		$subdivid[5] = "layer7";
		$subdivstyle[5] = "position:absolute; left:300px; top:600px; width:250px; height:120px; z-index:6; overflow: auto";
		$subtablename[5] = "fielddata.imagecollectionsources";
		$subkeyidname[5] = "photoid";
		$subtablewidth[5] = 250;
		$subcolumns[5] = "1";
		$subcolumnnames[5][1] = "sourcetitle";
			$subcolumnheader[5][1] = "source title";
			$subfieldtype[5][1] = "dropdown";
			$subdropdownsql[5][1] = "SELECT DISTINCT listsources.sourcetitle FROM fielddata.listsources WHERE listsources.valid=true ORDER BY listsources.sourcetitle;";
			$subfieldlength[5][1] = "15";
			$subfieldcolumnwidth[5][1] = "120";


		# add button for viewing photo of data entry

		if ($clearform or $commit)
		{
			unset($imagenumberdatainput);
			$_SESSION['imagenumberdatainputsession']=$imagenumberdatainput;
		}

		if ($update)
		{
			$imagenumberdatainput=$toplinedata1;
			$_SESSION['imagenumberdatainputsession']=$imagenumberdatainput;
		}
		else
		{
			$imagenumberdatainput=$_SESSION['imagenumberdatainputsession'];
		}

		if ($imagenumberdatainput!='')
		{
			$custombutton='yes';
			$custombuttonform='<form name="viewimageform" action="moduleviewdigitals.php?imagenumber='.$imagenumberdatainput.'" method="POST" target="_blank"><td align="center">
							<input type="submit" class="submitbutton" name="viewimage" value="view image"></td></form>';
		}

		break;


////////// CASE ADD DATA LOCALAREAS

		case "localareas":

		# variables controlling the data input
		$tablename = "fielddata.localareas";
		$keyidname = "localareas.localareaid";
		$tablewidth = 800;
		$columns = "2";
		$columnnames[1] = "localareacode";
			$columnheader[1] = "local area code";
			$fieldtype[1] = "text";
			$fieldlength[1] = 5;
			$fieldsize[1] = 6;
			$fieldcolumnwidth[1] = 80;
		$columnnames[2] = "localareaname";
			$columnheader[2] = "local area name";
			$fieldtype[2] = "text";
			$fieldlength[2] = 50;
			$fieldsize[2] = 50;
			$fieldcolumnwidth[2] = 160;

		$subtables = 2;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.localareasexcavators";
		$subkeyidname[1] = "localareaid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = 1;
		$subcolumnnames[1][1] = "supervisor";
			$subcolumnheader[1][1] = "supervisor(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "100";
		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:180px; width:220px; height:260px; z-index:6; overflow: auto";
		$subtablename[2] = "fielddata.localareassquares";
		$subkeyidname[2] = "localareaid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = 1;
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		break;


////////// CASE ADD DATA NOTEBOOKSCATALOG

		case "notebookscatalog":

		# variables controlling the data input

		$tablename = "fielddata.notebookscatalog";
		$keyidname = "notebookscatalog.notebookid";
		$tablewidth = 760;
		$columns = 7;
		$columnnames[1] = "notebookname";
			$columnheader[1] = "notebook name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "15";
			$fieldcolumnwidth[1] = "100";
		$columnnames[2] = "datestarted";
			$columnheader[2] = "date started";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "6";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "datecompleted";
			$columnheader[3] = "date completed";
			$fieldtype[3] = "text";
			$fieldlength[3] = "10";
			$fieldsize[3] = "6";
			$fieldcolumnwidth[3] = "50";
		$columnnames[4] = "comments";
			$columnheader[4] = "comments";
			$fieldtype[4] = "text";
			$fieldlength[4] = "80";
			$fieldsize[4] = "60";
			$fieldcolumnwidth[4] = "300";
		$columnnames[5] = "cdlocation";
			$columnheader[5] = "cd";
			$fieldtype[5] = "text";
			$fieldlength[5] = "4";
			$fieldsize[5] = "2";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "bindertype";
			$columnheader[6] = "binder type";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listbinders.bindertype FROM fielddata.listbinders WHERE listbinders.valid=true ORDER BY listbinders.bindertype;";
			$fieldlength[6] = "4";
			$fieldcolumnwidth[6] = "30";
		$columnnames[7] = "arearecordbinderlocation";
			$columnheader[7] = "binder number";
			$fieldtype[7] = "text";
			$fieldlength[7] = "4";
			$fieldsize[7] = "2";
			$fieldcolumnwidth[7] = "30";

		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.notebookscatalogareas";
		$subkeyidname[1] = "notebookid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.notebookscatalogsquares";
		$subkeyidname[2] = "notebookid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:460px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.notebookscatalogsupervisors";
		$subkeyidname[3] = "notebookid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";

		break;


////////// CASE ADD DATA PHOTOLOG

		case "photolog":

		# variables controlling the data input

		$tablename = "fielddata.photolog";
		$keyidname = "photolog.photoid";
		$tablewidth = 760;
		$columns = 6;
		$columnnames[1] = "imagenumber";
			$columnheader[1] = "number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "6";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "40";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "facing";
			$columnheader[4] = "facing";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listdirections.direction FROM fielddata.listdirections WHERE listdirections.valid=true ORDER BY listdirections.direction;";
			$fieldlength[4] = "7";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "photographer";
			$columnheader[5] = "photographer";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[5] = "5";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "cdnumber";
			$columnheader[6] = "cd number";
			$fieldtype[6] = "text";
			$fieldlength[6] = "3";
			$fieldsize[6] = "2";
			$fieldcolumnwidth[6] = "50";

		$subtables = "6";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:250px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.photologsquares";
		$subkeyidname[1] = "photoid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.photologfeatures";
		$subkeyidname[2] = "photoid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "featurenumber";
			$subcolumnheader[2][1] = "feature(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[2][1] = "6";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:0px; top:360px; width:300px; height:160px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.photologspecialists";
		$subkeyidname[3] = "photoid";
		$subtablewidth[3] = 220;
		$subcolumns[3] = "2";
		$subcolumnnames[3][1] = "specialistcategory";
			$subcolumnheader[3][1] = "specialist category";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listspecialistcategories.specialistcategory FROM fielddata.listspecialistcategories WHERE listspecialistcategories.valid=true ORDER BY listspecialistcategories.specialistcategory;";
			$subfieldlength[3][1] = "7";
			$subfieldcolumnwidth[3][1] = "80";
		$subcolumnnames[3][2] = "specialistid";
			$subcolumnheader[3][2] = "specialist id";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = "20";
			$subfieldsize[3][2] = "14";
			$subfieldcolumnwidth[3][2] = "110";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.photologareas";
		$subkeyidname[4] = "photoid";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "1";
		$subcolumnnames[4][1] = "area";
			$subcolumnheader[4][1] = "area(s)";
			$subfieldtype[4][1] = "dropdown";
			$subdropdownsql[4][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "80";

		$subdivid[5] = "layer7";
		$subdivstyle[5] = "position:absolute; left:340px; top:360px; width:220px; height:160px; z-index:7; overflow: auto";
		$subtablename[5] = "fielddata.photologindex";
		$subkeyidname[5] = "photoid";
		$subtablewidth[5] = 160;
		$subcolumns[5] = "1";
		$subcolumnnames[5][1] = "indexcode";
			$subcolumnheader[5][1] = "index code";
			$subfieldtype[5][1] = "dropdown";
			$subdropdownsql[5][1] = "SELECT DISTINCT listphotoindex.indexcode FROM fielddata.listphotoindex WHERE listphotoindex.valid=true ORDER BY listphotoindex.indexcode;";
			$subfieldlength[5][1] = "10";
			$subfieldcolumnwidth[5][1] = "80";

		$subdivid[6] = "layer8";
		$subdivstyle[6] = "position:absolute; left:580px; top:360px; width:220px; height:160px; z-index:7; overflow: auto";
		$subtablename[6] = "fielddata.photologrelatedphotos";
		$subkeyidname[6] = "photoid";
		$subtablewidth[6] = 160;
		$subcolumns[6] = "1";
		$subcolumnnames[6][1] = "imagenumber";
			$subcolumnheader[6][1] = "image number";
			$subfieldtype[6][1] = "dropdown";
			$subdropdownsql[6][1] = "SELECT DISTINCT photolog.imagenumber FROM fielddata.photolog WHERE photolog.valid=true ORDER BY photolog.imagenumber;";
			$subfieldlength[6][1] = "8";
			$subfieldcolumnwidth[6][1] = "40";


		# add button for viewing photo of data entry

		if ($clearform or $commit)
		{
			unset($imagenumberdatainput);
			$_SESSION['imagenumberdatainputsession']=$imagenumberdatainput;
		}

		if ($update)
		{
			$imagenumberdatainput=$toplinedata1;
			$_SESSION['imagenumberdatainputsession']=$imagenumberdatainput;
		}
		else
		{
			$imagenumberdatainput=$_SESSION['imagenumberdatainputsession'];
		}

		if ($imagenumberdatainput!='')
		{
			$custombutton='yes';
			$custombuttonform='<form name="viewimageform" action="moduleviewdigitals.php?imagenumber='.$imagenumberdatainput.'" method="POST" target="_blank"><td align="center">
							<input type="submit" class="submitbutton" name="viewimage" value="view image"></td></form>';
		}

		break;




////////// CASE ADD DATA REPORTSCATALOG

		case "reportscatalog":

		# variables controlling the data input

		$tablename = "fielddata.reportscatalog";
		$keyidname = "reportscatalog.reportid";
		$tablewidth = 760;
		$columns = 5;
		$columnnames[1] = "reportname";
			$columnheader[1] = "report name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "42";
			$fieldcolumnwidth[1] = "240";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "6";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "reporttype";
			$columnheader[3] = "report type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listreporttypes.reporttype FROM fielddata.listreporttypes WHERE listreporttypes.valid=true ORDER BY listreporttypes.reporttype;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "comments";
			$columnheader[4] = "comments";
			$fieldtype[4] = "text";
			$fieldlength[4] = "80";
			$fieldsize[4] = "55";
			$fieldcolumnwidth[4] = "260";
		$columnnames[5] = "cd";
			$columnheader[5] = "CD";
			$fieldtype[5] = "text";
			$fieldlength[5] = "5";
			$fieldsize[5] = "2";
			$fieldcolumnwidth[5] = "30";

		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.reportscatalogareas";
		$subkeyidname[1] = "reportid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.reportscatalogsquares";
		$subkeyidname[2] = "reportid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:460px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.reportscatalogauthors";
		$subkeyidname[3] = "reportid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "author";
			$subcolumnheader[3][1] = "author(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";

		break;





////////// CASE ADD DATA SAMPLEREGISTER

		case "sampleregister":

		# variables controlling the data input

		$tablename = "fielddata.sampleregister";
		$columns = "7";
		$columnnames[1] = "sampleprefix";
			$columnheader[1] = "season prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "6";
			$fieldcolumnwidth[1] = "80";
			$defaultvalue[1] = date('Y');
		$columnnames[2] = "samplenumber";
			$columnheader[2] = "sample number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "3";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "featurenumber";
			$columnheader[3] = "feature";
			$fieldtype[3] = "text";
			$fieldlength[3] = "5";
			$fieldsize[3] = "5";
			$fieldcolumnwidth[3] = "50";
		$columnnames[4] = "bagnumber";
			$columnheader[4] = "bag";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "3";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "date";
			$columnheader[5] = "date";
			$fieldtype[5] = "text";
			$fieldlength[5] = "10";
			$fieldsize[5] = "8";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "sampletype";
			$columnheader[6] = "type";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listsampletypes.sampletype FROM fielddata.listsampletypes WHERE listsampletypes.valid=true ORDER BY listsampletypes.sampletype;";
			$fieldlength[6] = "10";
			$fieldcolumnwidth[6] = "80";
		$columnnames[7] = "comments";
			$columnheader[7] = "comments";
			$fieldtype[7] = "text";
			$fieldlength[7] = "255";
			$fieldsize[7] = "40";
			$fieldcolumnwidth[7] = "200";

		break;


////////// CASE ADD DATA SPACELOG

		case "spacelog":

		# variables controlling the data edit

		$tablename = "fielddata.spacelog";
		$keyidname = "spacelog.spacenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "spacenumber";
			$columnheader[1] = "space";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "3";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.spacelogsquares";
		$subkeyidname[1] = "spacenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.spacelogareas";
		$subkeyidname[2] = "spacenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.spacelogsupervisors";
		$subkeyidname[3] = "spacenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";



		break;

////////// CASE ADD DATA STRUCTURELOG

		case "structurelog":

		# variables controlling the data edit

		$tablename = "fielddata.structurelog";
		$keyidname = "structurelog.structurenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "structurenumber";
			$columnheader[1] = "structure";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "3";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.structurelogsquares";
		$subkeyidname[1] = "structurenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.structurelogareas";
		$subkeyidname[2] = "structurenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.structurelogsupervisors";
		$subkeyidname[3] = "structurenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";



		break;


////////// CASE ADD DATA SYNOPTIC FEATURE FORM

		case "synopticfeatureform":

		$tablename = "fielddata.synopticfeatureform";
		$keyidname = "synopticfeatureform.featurenumber";
		$tablewidth = 760;
		$columns = 25;
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "featurecategory";
			$columnheader[2] = "D/C/A/F";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "SELECT DISTINCT listfeaturecategory.featurecategory FROM fielddata.listfeaturecategory WHERE listfeaturecategory.valid=true ORDER BY listfeaturecategory.featurecategory;";
			$fieldlength[2] = "8";
			$fieldcolumnwidth[2] = "120";
		$columnnames[3] = "featuretype";
			$columnheader[3] = "feature type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listfeaturetypes.featuretype FROM fielddata.listfeaturetypes WHERE listfeaturetypes.valid=true ORDER BY listfeaturetypes.featuretype;";
			$fieldlength[3] = "13";
			$fieldcolumnwidth[3] = "160";
		$columnnames[4] = "matrixgroupnumber";
			$columnheader[4] = "matrix group number";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "5";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "groupnumberclosed";
			$columnheader[5] = "group number closed";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[5] = "4";
			$fieldcolumnwidth[5] = "30";
		$columnnames[6] = "roomdesignations";
			$columnheader[6] = "room designations";
			$fieldtype[6] = "text";
			$fieldlength[6] = "50";
			$fieldsize[6] = "10";
			$fieldcolumnwidth[6] = "100";
		$columnnames[7] = "spacenumber";
			$columnheader[7] = "space number";
			$fieldtype[7] = "text";
			$fieldlength[7] = "5";
			$fieldsize[7] = "5";
			$fieldcolumnwidth[7] = "50";
		$columnnames[8] = "structurenumber";
			$columnheader[8] = "structure number";
			$fieldtype[8] = "text";
			$fieldlength[8] = "5";
			$fieldsize[8] = "5";
			$fieldcolumnwidth[8] = "50";

		$columnnames[9] = "extendedfeaturedescription";
			$columnheader[9] = "extended feature description";
			$fieldtype[9]= "text";
			$fieldlength[9]= "500";
			$fieldsize[9]= "140";
			$fieldcolumnwidth[9]= "500";
			$startnewline[9] = "yes";

		$columnnames[10] = "orientation";
			$columnheader[10] = "orientation";
			$fieldtype[10] = "dropdown";
			$dropdownsql[10] = "SELECT DISTINCT listorientation.orientation FROM fielddata.listorientation WHERE listorientation.valid=true ORDER BY listorientation.orientation;";
			$fieldlength[10] = "7";
			$fieldcolumnwidth[10] = "20";
			$startnewline[10] = "yes";
		$columnnames[11] = "maxlengthqualifier";
			$columnheader[11] = "max length qualifier";
			$fieldtype[11]= "text";
			$fieldlength[11]= "1";
			$fieldsize[11]= "1";
			$fieldcolumnwidth[11]= "70";
		$columnnames[12] = "maxlength";
			$columnheader[12] = "max length (m)";
			$fieldtype[12]= "text";
			$fieldlength[12]= "5";
			$fieldsize[12]= "5";
			$fieldcolumnwidth[12]= "70";
		$columnnames[13] = "maxwidthqualifier";
			$columnheader[13] = "max width qualifier";
			$fieldtype[13]= "text";
			$fieldlength[13]= "1";
			$fieldsize[13]= "1";
			$fieldcolumnwidth[13]= "70";
		$columnnames[14] = "maxwidth";
			$columnheader[14] = "max width (m)";
			$fieldtype[14]= "text";
			$fieldlength[14]= "5";
			$fieldsize[14]= "5";
			$fieldcolumnwidth[14]= "70";
		$columnnames[15] = "maxvdqualifier";
			$columnheader[15] = "max vd qualifier";
			$fieldtype[15]= "text";
			$fieldlength[15]= "1";
			$fieldsize[15]= "1";
			$fieldcolumnwidth[15]= "70";
		$columnnames[16] = "maxvd";
			$columnheader[16] = "max vd (m)";
			$fieldtype[16]= "text";
			$fieldlength[16]= "5";
			$fieldsize[16]= "5";
			$fieldcolumnwidth[16]= "70";
		$columnnames[17] = "fullextentvisibleinplan";
			$columnheader[17] = "full extent visible in plan";
			$fieldtype[17] = "dropdown";
			$dropdownsql[17] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[17] = "4";
			$fieldcolumnwidth[17] = "60";
		$columnnames[18] = "leveltop";
			$columnheader[18] = "level top (m)";
			$fieldtype[18]= "text";
			$fieldlength[18]= "5";
			$fieldsize[18]= "5";
			$fieldcolumnwidth[18]= "50";
		$columnnames[19] = "levelbottom";
			$columnheader[19] = "level bottom (m)";
			$fieldtype[19]= "text";
			$fieldlength[19]= "5";
			$fieldsize[19]= "5";
			$fieldcolumnwidth[19]= "50";

		$columnnames[20] = "int_ext";
			$columnheader[20] = "int/ext/structural";
			$fieldtype[20] = "dropdown";
			$dropdownsql[20] = "SELECT DISTINCT listint_ext.int_ext FROM fielddata.listint_ext WHERE listint_ext.valid=true ORDER BY listint_ext.int_ext;";
			$fieldlength[20] = "8";
			$fieldcolumnwidth[20] = "50";
			$startnewline[20] = "yes";
		$columnnames[21] = "excavated";
			$columnheader[21] = "excavated";
			$fieldtype[21] = "dropdown";
			$dropdownsql[21] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[21] = "4";
			$fieldcolumnwidth[21] = "30";
		$columnnames[22] = "fullyexcavated";
			$columnheader[22] = "100% excavated";
			$fieldtype[22] = "dropdown";
			$dropdownsql[22] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[22] = "4";
			$fieldcolumnwidth[22] = "30";
		$columnnames[23] = "contaminated";
			$columnheader[23] = "risk of contamination";
			$fieldtype[23] = "dropdown";
			$dropdownsql[23] = "SELECT DISTINCT listcontamination.contamination FROM fielddata.listcontamination WHERE listcontamination.valid=true ORDER BY listcontamination.contamination;";
			$fieldlength[23] = "8";
			$fieldcolumnwidth[23] = "50";
		$columnnames[24] = "lastmodified";
			$columnheader[24] = "last modified";
			$fieldtype[24] = "text";
			$fieldlength[24] = "10";
			$fieldsize[24] = "8";
			$fieldcolumnwidth[24] = "80";
		$columnnames[25] = "excavationnote";
			$columnheader[25] = "excavation notes";
			$fieldtype[25] = "text";
			$fieldlength[25] = "500";
			$fieldsize[25] = "50";
			$fieldcolumnwidth[25] = "200";

		$subtables = 3;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:370px; width:280px; height:200px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.synopticfeatureformphases";
		$subkeyidname[1] = "featurenumber";
		$subtablewidth[1] = 220;
		$subcolumns[1] = 2;
		$subcolumnnames[1][1] = "seasonname";
			$subcolumnheader[1][1] = "phase season";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdrawingseasons.seasonyear FROM fielddata.listdrawingseasons WHERE listdrawingseasons.valid=true ORDER BY listdrawingseasons.seasonyear;";
			$subfieldlength[1][1] = 7;
			$subfieldcolumnwidth[1][1] = 40;
		$subcolumnnames[1][2] = "phase";
			$subcolumnheader[1][2] = "phase number";
			$subfieldtype[1][2] = "text";
			$subfieldlength[1][2] = 6;
			$subfieldsize[1][2] = 7;
			$subfieldcolumnwidth[1][2] = 50;

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:290px; top:370px; width:280px; height:200px; z-index:6; overflow: auto";
		$subtablename[2] = "fielddata.synopticfeatureformrelationships";
		$subkeyidname[2] = "featurenumber";
		$subtablewidth[2] = 220;
		$subcolumns[2] = 2;
		$subcolumnnames[2][1] = "relationshiptype";
			$subcolumnheader[2][1] = "relationship type";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listrelationshiptype.relationshiptype FROM fielddata.listrelationshiptype WHERE listrelationshiptype.valid=true ORDER BY listrelationshiptype.relationshiptype;";
			$subfieldlength[2][1] = 7;
			$subfieldcolumnwidth[2][1] = 40;
		$subcolumnnames[2][2] = "relatedfeaturenumber";
			$subcolumnheader[2][2] = "feature number";
			$subfieldtype[2][2] = "text";
			$subfieldlength[2][2] = 5;
			$subfieldsize[2][2] = 7;
			$subfieldcolumnwidth[2][2] = 50;

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:580px; top:370px; width:280px; height:200px; z-index:6; overflow: auto";
		$subtablename[3] = "fielddata.synopticfeatureformcutfillrelationships";
		$subkeyidname[3] = "featurenumber";
		$subtablewidth[3] = 220;
		$subcolumns[3] = 2;
		$subcolumnnames[3][1] = "relationshiptype";
			$subcolumnheader[3][1] = "cut/fill relationship type";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listcutfillrelationshiptype.relationshiptype FROM fielddata.listcutfillrelationshiptype WHERE listcutfillrelationshiptype.valid=true ORDER BY listcutfillrelationshiptype.relationshiptype;";
			$subfieldlength[3][1] = 7;
			$subfieldcolumnwidth[3][1] = 40;
		$subcolumnnames[3][2] = "relatedfeaturenumber";
			$subcolumnheader[3][2] = "cut/fill feature number";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = 5;
			$subfieldsize[3][2] = 7;
			$subfieldcolumnwidth[3][2] = 50;
		break;




////////// CASE ADD DATA LISTAREAS

		case "listareas":

		# variables controlling the data input

		$tablename = "fielddata.listareas";
		$columns = "2";
		$columnnames[1] = "area";
			$columnheader[1] = "abbreviation";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "areafullname";
			$columnheader[2] = "full name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "50";
			$fieldsize[2] = "30";
			$fieldcolumnwidth[2] = "200";

		break;



////////// CASE ADD DATA LISTBAGCATEGORIES

		case "listbagcategories":

		# variables controlling the data input

		$tablename = "fielddata.listbagcategories";
		$columns = "1";
		$columnnames[1] = "bagcategory";
			$columnheader[1] = "category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "18";
			$fieldsize[1] = "18";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTBAGSEASONS

		case "listbagseasons":

		# variables controlling the data input

		$tablename = "fielddata.listbagseasons";
		$columns = "1";
		$columnnames[1] = "season";
			$columnheader[1] = "season";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTBINDERS

		case "listbinders":

		# variables controlling the data input

		$tablename = "fielddata.listbinders";
		$columns = "3";
		$columnnames[1] = "bindertype";
			$columnheader[1] = "binder type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "bindernumber";
			$columnheader[2] = "binder number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "4";
			$fieldsize[2] = "5";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "binderdescription";
			$columnheader[3] = "binder description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "255";
			$fieldsize[3] = "50";
			$fieldcolumnwidth[3] = "200";

		break;



////////// CASE ADD DATA LISTBURIALTYPES

		case "listburialtypes":

		# variables controlling the data input

		$tablename = "fielddata.listburialtypes";
		$columns = "1";
		$columnnames[1] = "burialtype";
			$columnheader[1] = "burial type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTDATAENTRYSQUARES

		case "listdataentrysquares":

		# variables controlling the data input

		$tablename = "fielddata.listdataentrysquares";
		$columns = "1";
		$columnnames[1] = "squarename";
			$columnheader[1] = "square(s)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		break;


////////// CASE ADD DATA LISTDIRECTIONS

		case "listdirections":

		# variables controlling the data input

		$tablename = "fielddata.listdirections";
		$columns = "1";
		$columnnames[1] = "direction";
			$columnheader[1] = "direction";
			$fieldtype[1] = "text";
			$fieldlength[1] = "9";
			$fieldsize[1] = "9";
			$fieldcolumnwidth[1] = "80";

		break;


////////// CASE ADD DATA LISTDRAWINGSEASONS

		case "listdrawingseasons":

		# variables controlling the data input

		$tablename = "fielddata.listdrawingseasons";
		$columns = "1";
		$columnnames[1] = "seasonyear";
			$columnheader[1] = "season";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		break;


////////// CASE ADD DATA LISTDRAWINGTYPES

		case "listdrawingtypes":

		# variables controlling the data input

		$tablename = "fielddata.listdrawingtypes";
		$columns = "1";
		$columnnames[1] = "drawingtype";
			$columnheader[1] = "drawing type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "20";
			$fieldsize[1] = "20";
			$fieldcolumnwidth[1] = "80";

		break;


////////// CASE ADD DATA LISTENTITYTYPES

		case "listentitytypes":

		# variables controlling the data input

		$tablename = "fielddata.listentitytypes";
		$columns = "1";
		$columnnames[1] = "entitytype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "25";
			$fieldsize[1] = "25";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTEXCAVATORS

		case "listexcavators":

		# variables controlling the data input

		$tablename = "fielddata.listexcavators";
		$columns = "2";
		$columnnames[1] = "initials";
			$columnheader[1] = "initials";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "fullnames";
			$columnheader[2] = "full name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "54";
			$fieldsize[2] = "54";
			$fieldcolumnwidth[2] = "80";

		break;



////////// CASE ADD DATA LISTEXOTICMATERIALCATEGORIES

		case "listexoticmaterialcategories":

		# variables controlling the data input

		$tablename = "fielddata.listexoticmaterialcategories";
		$columns = "1";
		$columnnames[1] = "materialcategory";
			$columnheader[1] = "category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "25";
			$fieldsize[1] = "15";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTFEATURETYPEGROUPS

		case "listfeaturetypegroups":

		# variables controlling the data input

		$tablename = "fielddata.listfeaturetypegroups";
		$columns = "2";
		$columnnames[1] = "featuretypegroup";
			$columnheader[1] = "group";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "groupname";
			$columnheader[2] = "name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "25";
			$fieldsize[2] = "25";
			$fieldcolumnwidth[2] = "80";

		break;



////////// CASE ADD DATA LISTFEATURETYPES

		case "listfeaturetypes":

		# variables controlling the data input

		$tablename = "fielddata.listfeaturetypes";
		$columns = "2";
		$columnnames[1] = "featuretype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "featuretypegroup";
			$columnheader[2] = "group";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "select listfeaturetypegroups.featuretypegroup from fielddata.listfeaturetypegroups
							where listfeaturetypegroups.valid=true order by listfeaturetypegroups.featuretypegroup;";
			$fieldlength[2] = "5";
			$fieldcolumnwidth[2] = "80";

		break;



////////// CASE ADD DATA LISTINT/EXT

		case "listint/ext":

		# variables controlling the data input

		$tablename = "fielddata.listint_ext";
		$columns = "1";
		$columnnames[1] = "int_ext";
			$columnheader[1] = "int/ext";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTLOCATIONS

		case "listlocations":

		# variables controlling the data input

		$tablename = "fielddata.listlocations";
		$columns = "1";
		$columnnames[1] = "location";
			$columnheader[1] = "location";
			$fieldtype[1] = "text";
			$fieldlength[1] = "20";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "120";

		break;


////////// CASE ADD DATA LISTPHASES

		case "listphases":

		# variables controlling the data input

		$tablename = "fielddata.listphases";
		$columns = "1";
		$columnnames[1] = "phase";
			$columnheader[1] = "phase";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTPHOTOTYPES

		case "listphototypes":

		# variables controlling the data input

		$tablename = "fielddata.listphototypes";
		$columns = "1";
		$columnnames[1] = "phototype";
			$columnheader[1] = "photo type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "10";
			$fieldsize[1] = "7";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTPHOTOINDEX

		case "listphotoindex":

		# variables controlling the data input

		$tablename = "fielddata.listphotoindex";
		$columns = 2;
		$columnnames[1] = "indexcode";
			$columnheader[1] = "index code";
			$fieldtype[1] = "text";
			$fieldlength[1] = "7";
			$fieldsize[1] = "7";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "indexdescription";
			$columnheader[2] = "index description";
			$fieldtype[2] = "text";
			$fieldlength[2] = "100";
			$fieldsize[2] = "50";
			$fieldcolumnwidth[2] = "160";

		break;



////////// CASE ADD DATA LISTPORTFOLIOS

		case "listportfolios":

		# variables controlling the data input

		$tablename = "fielddata.listportfolios";
		$keyidname = "listportfolios.portfolionumber";
		$tablewidth = 300;
		$columns = 1;
		$columnnames[1] = "portfolionumber";
			$columnheader[1] = "portfolio number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		$subtables = "1";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[1] = "fielddata.listportfolioareas";
		$subkeyidname[1] = "portfolionumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		break;



////////// CASE ADD DATA LISTREPORTTYPES

		case "listreporttypes":

		# variables controlling the data input

		$tablename = "fielddata.listreporttypes";
		$columns = "1";
		$columnnames[1] = "reporttype";
			$columnheader[1] = "report type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "20";
			$fieldcolumnwidth[1] = "80";

		break;



////////// CASE ADD DATA LISTSAMPLETYPES

		case "listsampletypes":

		# variables controlling the data input

		$tablename = "fielddata.listsampletypes";
		$columns = "1";
		$columnnames[1] = "sampletype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "16";
			$fieldsize[1] = "16";
			$fieldcolumnwidth[1] = "80";

		break;


////////// CASE ADD DATA LISTSCALES

		case "listscales":

		# variables controlling the data input

		$tablename = "fielddata.listscales";
		$columns = "1";
		$columnnames[1] = "scale";
			$columnheader[1] = "scale (1:X)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		break;




////////// CASE ADD DATA LISTSITESEASONS

		case "listsiteseasons":

		# variables controlling the data input

		$tablename = "fielddata.listsiteseasons";
		$columns = 3;
		$columnnames[1] = "seasonname";
			$columnheader[1] = "season name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "10";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "startdate";
			$columnheader[2] = "start date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "enddate";
			$columnheader[3] = "end date";
			$fieldtype[3] = "text";
			$fieldlength[3] = "10";
			$fieldsize[3] = "7";
			$fieldcolumnwidth[3] = "50";

		break;



////////// CASE ADD DATA LISTSOURCES

		case "listsources":

		# variables controlling the data input

		$tablename = "fielddata.listsources";
		$columns = 5;
		$columnnames[1] = "sourcetitle";
			$columnheader[1] = "source title";
			$fieldtype[1] = "text";
			$fieldlength[1] = "255";
			$fieldsize[1] = "50";
			$fieldcolumnwidth[1] = "150";
		$columnnames[2] = "author";
			$columnheader[2] = "author(s)";
			$fieldtype[2] = "text";
			$fieldlength[2] = "255";
			$fieldsize[2] = "30";
			$fieldcolumnwidth[2] = "150";
		$columnnames[3] = "publisher";
			$columnheader[3] = "publisher(s)";
			$fieldtype[3] = "text";
			$fieldlength[3] = "255";
			$fieldsize[3] = "30";
			$fieldcolumnwidth[3] = "150";
		$columnnames[4] = "year";
			$columnheader[4] = "year";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "5";
			$fieldcolumnwidth[4] = "30";
		$columnnames[5] = "location";
			$columnheader[5] = "location";
			$fieldtype[5] = "text";
			$fieldlength[5] = "50";
			$fieldsize[5] = "30";
			$fieldcolumnwidth[5] = "150";

		break;



////////// CASE ADD DATA LISTSPECIALISTCATEGORIES

		case "listspecialistcategories":

		# variables controlling the data input

		$tablename = "fielddata.listspecialistcategories";
		$columns = 1;
		$columnnames[1] = "specialistcategory";
			$columnheader[1] = "sepcialist category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "18";
			$fieldsize[1] = "14";
			$fieldcolumnwidth[1] = "100";

		break;



////////// CASE ADD DATA LISTSQUARES

		case "listsquares":

		# variables controlling the data input

		$tablename = "fielddata.listsquares";
		$columns = "1";
		$columnnames[1] = "squarename";
			$columnheader[1] = "square(s)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		break;




////////// CASE ADD DATA LISTSTORAGEMEDIUMS

		case "liststoragemediums":

		# variables controlling the data input

		$tablename = "fielddata.liststoragemediums";
		$columns = "1";
		$columnnames[1] = "storagemedium";
			$columnheader[1] = "storage medium";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "200";

		break;



////////// CASE ADD DATA LISTWEIGHTPREFIX

		case "listweightprefix":

		# variables controlling the data input

		$tablename = "fielddata.listweightprefix";
		$columns = "1";
		$columnnames[1] = "weightprefix";
			$columnheader[1] = "weight prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "1";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "200";

		break;



////////// CASE ADD DATA LISTYESNO

		case "listyesno":

		# variables controlling the data input

		$tablename = "fielddata.listyesno";
		$columns = "1";
		$columnnames[1] = "yesno";
			$columnheader[1] = "yes/no";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "50";

		break;
	}

if ($useraccesslevel>=4)
{
	switch ($submenuaction)
	{

////////// CASE ADD DATA DBUSERS

		case "authentication":

		# variables controlling the data input

		$tablename = "fielddata.authentication";
		$columns = "5";
		$columnnames[1] = "name";
			$columnheader[1] = "username";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "10";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "passwd";
			$columnheader[2] = "password";
			$fieldtype[2] = "password";
			$fieldlength[2] = "50";
			$fieldsize[2] = "10";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "groupid";
			$columnheader[3] = "security level<br>1 = read only<br>2 = add/edit<br>3 = add/edit/delete<br>4 = superuser";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1";
			$fieldsize[3] = "1";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "initials";
			$columnheader[4] = "initials";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[4] = "5";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "email";
			$columnheader[5] = "e-mail";
			$fieldtype[5] = "text";
			$fieldlength[5] = "50";
			$fieldsize[5] = "30";
			$fieldcolumnwidth[5] = "120";

		break;
	}
}


// decide which module to load

if ($tablename)
{
	if ($keyidname)
	{
		include 'moduledatainputmultiple.php';
	}
	else
	{
		include 'moduledatainputsingle.php';
	}
}
	echo '</div>';


?>