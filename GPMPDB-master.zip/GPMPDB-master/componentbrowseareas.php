<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "SELECT broadareas.broadareacode AS \"broad area code\", broadareas.broadareaname AS \"broad area name\", localareas.localareacode AS \"local area code\", localareas.localareaname AS \"local area name\", localareas.localareaid
						FROM (fielddata.localareas
								LEFT JOIN fielddata.broadareaslocalareas ON localareas.localareacode=broadareaslocalareas.localareacode)
						LEFT JOIN fielddata.broadareas ON broadareaslocalareas.broadareaid=broadareas.broadareaid
						WHERE localareas.valid=true AND broadareas.valid=true AND broadareaslocalareas.valid=true";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 6;

# add sort option
	
	include 'componentsortdata.php';
		

# add freetext search option
	
	include 'modulefreetextsearch.php';


		$keynumberofcolumns = 2;
		$keycolumn[1] = 4;
		$keyquery[1] = "SELECT localareasexcavators.supervisor as \"supervisors(s)\" FROM fielddata.localareasexcavators WHERE localareasexcavators.valid=true";
		$keysort[1] = "localareasexcavators.supervisor";
		$keycolumn[2] = 4;
		$keyquery[2] = "SELECT localareassquares.squarename as \"square(s)\" FROM fielddata.localareassquares WHERE localareassquares.valid=true";
		$keysort[2] = "localareassquares.squarename";
		
		
switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE LOG

		case "browseallareas":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse broad and local areas";
		$heading1 = "option:";
		$text1 = "all areas";
		$heading2 = "areas:";
		$text2 = "all";
		$savename="complete broad and local areas";
		$norecordtext="ERROR!!!<br><br> No areas exist in database!";

		break;

		
////////// CASE BY BROAD AREA CODE

		case "browsebybroadareacode":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "broadareas.broadareacode = '$filtervalues[$i]'";
			}
			$where_broadareacode = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_broadareacode =	"broadareas.broadareacode = '$broadareacode'";
			$headingstring = $broadareacode;
		}

		$query = "$superquery AND ($where_broadareacode) $searchsql ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&broadareacode=$broadareacode&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse broad and local areas";
		$heading1 = "option:";
		$text1 = "by broad area code";
		$heading2 = "broad area code(s):";
		$text2 = $headingstring;
		$savename="broad and local areas from broad area code(s) $headingstring";
		$norecordtext="ERROR!!!<br><br> No areas exist in database!";

		break;
		
////////// CASE BY LOCAL AREA CODE

		case "browsebylocalareacode":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "localareas.localareacode = '$filtervalues[$i]'";
			}
			$where_localareacode = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_localareacode = "localareas.localareacode = '$localareacode'";
			$headingstring = $localareacode;
		}

		$query = "$superquery AND ($where_localareacode) $searchsql ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&localareacode=$localareacode&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse broad and local areas";
		$heading1 = "option:";
		$text1 = "by local area code";
		$heading2 = "local area code(s):";
		$text2 = $headingstring;
		$savename="broad and local areas from local area code(s) $headingstring";
		$norecordtext="ERROR!!!<br><br> No areas exist in database!";

		break;

////////// CASE BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "localareasexcavators.supervisor = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor = "localareasexcavators.supervisor = '$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "SELECT DISTINCT broadareas.broadareacode AS \"broad area code\", broadareas.broadareaname AS \"broad area name\", localareas.localareacode AS \"local area code\", localareas.localareaname AS \"local area name\", localareas.localareaid
						FROM ((fielddata.localareas
								LEFT JOIN fielddata.broadareaslocalareas ON localareas.localareacode=broadareaslocalareas.localareacode)
						LEFT JOIN fielddata.broadareas ON broadareaslocalareas.broadareaid=broadareas.broadareaid)
						LEFT JOIN fielddata.localareasexcavators ON localareas.localareaid=localareasexcavators.localareaid
						WHERE localareas.valid=true AND broadareas.valid=true AND broadareaslocalareas.valid=true
						AND ($where_supervisor) $searchsql ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse broad and local areas";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="broad and local areas from supervisor(s) $headingstring";
		$norecordtext="ERROR!!!<br><br> No areas exist in database!";

		break;

		
////////// CASE BY SUPERVISOR

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "localareassquares.squarename = '$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square = "localareassquares.squarename = '$squarename'";
			$headingstring = $squarename;
		}

		$query = "SELECT DISTINCT broadareas.broadareacode AS \"broad area code\", broadareas.broadareaname AS \"broad area name\", localareas.localareacode AS \"local area code\", localareas.localareaname AS \"local area name\", localareas.localareaid
						FROM ((fielddata.localareas
								LEFT JOIN fielddata.broadareaslocalareas ON localareas.localareacode=broadareaslocalareas.localareacode)
						LEFT JOIN fielddata.broadareas ON broadareaslocalareas.broadareaid=broadareas.broadareaid)
						LEFT JOIN fielddata.localareassquares ON localareas.localareaid=localareassquares.localareaid
						WHERE localareas.valid=true AND broadareas.valid=true AND broadareaslocalareas.valid=true
						AND ($where_square) $searchsql ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse broad and local areas";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="broad and local areas from square(s) $headingstring";
		$norecordtext="ERROR!!!<br><br> No areas exist in database!";

		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>