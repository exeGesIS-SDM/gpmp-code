<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select (CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END) AS bag, bagregister.featurenumber AS feature, bagregister.date, bagregister.category, bagregister.comments, bagregister.bagregisterid from fielddata.bagregister WHERE bagregister.valid=true";

		$keynumberofcolumns = 1;
		$keycolumn[1] = "5";
		$keyquery[1] = "SELECT bagregistersquares.squarename AS \"square(s)\" FROM fielddata.bagregistersquares WHERE bagregistersquares.valid='t'";
		$keysort[1] = "bagregistersquares.squarename";
		
		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 6;

# add sort option
	
	include 'componentsortdata.php';

	
# add freetext search option
	
	include 'modulefreetextsearch.php';
		
		

switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompleteregister":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse bag register";
		$heading1 = "option:";
		$text1 = "complete register";
		$heading2 = "bags:";
		$text2 = "all";
		$savename="complete bagregister";
		$norecordtext="ERROR!!!<br><br> No bags exist in database!";

		
		break;



		
////////// CASE SINGLEBAG

		
		case "browsesinglebag":

		if	($featurenumber>0)
			{
				$query = "$superquery AND bagnumber=$bagnumber AND featurenumber=$featurenumber $searchsql ORDER BY $sortsql;";
				$uservariables = "bagnumber=$bagnumber&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse bag register";
				$heading1 = "option:";
				$text1 = "single bag";
				$heading2 = "bag:";
				$text2 = "bag $bagnumber of feature $featurenumber";
				$savename="bag $bagnumber of feature $featurenumber from bagregister";
				
			}
			else
			{
				if	($bagprefix!='')
				{
					$query = "$superquery AND bagnumber=$bagnumber AND bagprefix='$bagprefix' $searchsql ORDER BY $sortsql;";
					$uservariables = "bagnumber=$bagnumber&bagprefix=$bagprefix&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse bag register";
					$heading1 = "option:";
					$text1 = "single bag";
					$heading2 = "bag:";
					$text2 = "bag $bagnumber of bagprefix $bagprefix";
					$savename="bag $bagnumber of bagprefix $bagprefix from bagregister";
				}
				else
				{
					$query = "$superquery AND bagnumber=$bagnumber $searchsql ORDER BY $sortsql;";
					$uservariables = "bagnumber=$bagnumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse bag register";
					$heading1 = "option:";
					$text1 = "single bag";
					$heading2 = "bag:";
					$text2 = "$bagnumber";
					$savename="bag $bagnumber from bagregister";
				}
			}

		$norecordtext="ERROR!!!<br><br> Bag does not exist in database!";

		
		break;
		

////////// CASE BAG SERIES

		case "browsebagseries":

		if	($featurenumber>0)
			{
				$query = "$superquery AND bagnumber>=$firstbagnumber AND bagnumber<=$lastbagnumber AND featurenumber=$featurenumber $searchsql ORDER BY $sortsql;";
				$uservariables = "firstbagnumber=$firstbagnumber&lastbagnumber=$lastbagnumber&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse bag register";
				$heading1 = "option:";
				$text1 = "bag series";
				$heading2 = "bags:";
				$text2 = "bag $firstbagnumber to $lastbagnumber of feature $featurenumber";
				$savename="bag series $firstbagnumber-$lastbagnumber of feature $featurenumber from bagregister";
				
			}
			else
			{
				if	($bagprefix!='')
				{
					$query = "$superquery AND bagnumber>=$firstbagnumber AND bagnumber<=$lastbagnumber AND bagprefix='$bagprefix' $searchsql ORDER BY $sortsql;";
					$uservariables = "firstbagnumber=$firstbagnumber&lastbagnumber=$lastbagnumber&bagprefix=$bagprefix&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse bag register";
					$heading1 = "option:";
					$text1 = "bag series";
					$heading2 = "bags:";
					$text2 = "bag $firstbagnumber to $lastbagnumber of bagprefix $bagprefix";
					$savename="bag series $firstbagnumber-$lastbagnumber of bagprefix $bagprefix from bagregister";
				}
				else
				{
					$query = "$superquery AND bagnumber>=$firstbagnumber AND bagnumber<=$lastbagnumber $searchsql ORDER BY $sortsql;";
					$uservariables = "firstbagnumber=$firstbagnumber&lastbagnumber=$lastbagnumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse bag register";
					$heading1 = "option:";
					$text1 = "bag series";
					$heading2 = "bags:";
					$text2 = "bag $firstbagnumber to $lastbagnumber";
					$savename="bag series $firstbagnumber-$lastbagnumber from bagregister";
				}
			}

		$norecordtext="ERROR!!!<br><br> Bag series does not exist in database!";
		
		break;


		
////////// CASE BY FEATURE

		case "browsebyfeature":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "featurenumber= '$filtervalues[$i]'";
			}
			$where_feature = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_feature = "featurenumber='$featurenumber'";
			$headingstring = $featurenumber;
		}
		
		$query = "$superquery AND ($where_feature) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse bag register";
		$heading1 = "option:";
		$text1 = "by feature";
		$heading2 = "bags:";
		$text2 = "of feature(s) $headingstring";
		$savename="all bags of feature(s) $headingstring from bagregister";
		$norecordtext="ERROR!!!<br><br> No bags matching this feature exist in database!";
		
		break;	

		
		
////////// CASE BY CATEGORY

		case "browsebycategory":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "category='$filtervalues[$i]'";
			}
			$where_category = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_category = "category='$category'";
			$headingstring = $category;
		}
		
		$query = "$superquery AND ($where_category) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&category=$category&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse bag register";
		$heading1 = "option:";
		$text1 = "by category";
		$heading2 = "bags:";
		$text2 = "of category(ies) $headingstring";
		$savename="all bags of category(ies) $headingstring from bagregister";
		$norecordtext="ERROR!!!<br><br> No bags matching this category exist in database!";
		
		break;	



////////// CASE BAGREGISTER FOR AREA DEFINITION

		case "dsrbagregister":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "bagregistersquares.squarename='".$squarename[$i]."'";
			}
			$sqlbagsquares = "OR (".implode(" OR ", $squarename).")";
		}

		$query = "select distinct (CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END) AS bag, bagregister.bagprefix, bagregister.bagnumber, bagregister.featurenumber AS feature, bagregister.date, bagregister.category , bagregister.comments, bagregister.bagregisterid
						from (((fielddata.bagregister left join fielddata.featurelogareas on bagregister.featurenumber = featurelogareas.featurenumber) left join fielddata.featurelogsquares on bagregister.featurenumber = featurelogsquares.featurenumber) left join fielddata.featurelogsupervisors on bagregister.featurenumber = featurelogsupervisors.featurenumber) left join fielddata.bagregistersquares on bagregister.bagregisterid = bagregistersquares.bagregisterid 
						WHERE bagregister.valid=true $wherearea $wheresquares $wheresupervisors
						$sqlarea $sqlsquares $sqlsupervisors $sqlbagsquares $searchsql
						ORDER BY $sortsql;";
	
		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "bagregister";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records bagregister from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No bags for this query exist in database!";

		$keycolumn[1] = "7";

		unset ($outputcolumn);
		unset ($outputcolumns);

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 5;
		$outputcolumn[4]= 6;
		$outputcolumn[5]= 8;		
		
		break;
	}

	
if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>