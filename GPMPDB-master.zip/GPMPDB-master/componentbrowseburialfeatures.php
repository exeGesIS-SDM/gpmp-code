<?php


////////// GENERAL VARIABLES

		$superquery = "select burialfeatures.burialnumber AS \"burial\", burialfeatures.featurenumber AS \"feature\", burialfeatures.burialtype AS \"burial type\" from fielddata.burialfeatures WHERE burialfeatures.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		

# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompleteregister":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse burial features";
		$heading1 = "option:";
		$text1 = "complete register";
		$heading2 = "samples:";
		$text2 = "all";
		$savename="complete burialfeatures";
		$norecordtext="ERROR!!!<br><br> No burials exist in database!";

		break;

	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>