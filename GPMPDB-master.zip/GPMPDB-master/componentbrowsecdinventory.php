<?php

////////// GENERAL VARIABLES

		$superquery = "SELECT cdinventory.storagemedium AS \"storage medium\", cdinventory.number, cdinventory.contents,
						CASE WHEN cdinventory.giza='t' THEN 'yes' WHEN cdinventory.giza='f' THEN 'no' END AS \"in Giza\",
						CASE WHEN cdinventory.boston='t' THEN 'yes' WHEN cdinventory.boston='f' THEN 'no' END AS \"in Boston\",
						CASE WHEN cdinventory.newyork='t' THEN 'yes' WHEN cdinventory.newyork='f' THEN 'no' END AS \"in New York\"
						from fielddata.cdinventory WHERE cdinventory.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;


# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE INVENTORY

		case "browsecompleteinventory":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse cd inventory";
		$heading1 = "option:";
		$text1 = "complete inventory";
		$heading2 = "cds:";
		$text2 = "all";
		$savename="complete cdinventory";
		$norecordtext="ERROR!!!<br><br> No cds exist in database!";

		break;
	}


if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}
	
	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}

?>