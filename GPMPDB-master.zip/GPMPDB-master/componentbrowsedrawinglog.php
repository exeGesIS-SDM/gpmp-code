<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";



////////// GENERAL VARIABLES

		$superquery = "select (CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid from fielddata.drawinglog WHERE drawinglog.valid=true";

		$filedownloadheader="downloadable file";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/drawings";
		# $filedownloadextension="tif";
		$filedownloadextensions=array("tif", "jpg");
		$filedownloadcolumn=0;
		$filedownloadprefix="GPMP";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 20;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 18;
		$outputcolumn[3]= 19;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 20;
		$outputcolumn[8]= 5;
		$outputcolumn[9]= 6;
		$outputcolumn[10]= 7;
		$outputcolumn[11]= 8;
		$outputcolumn[12]= 9;
		$outputcolumn[13]= 10;
		$outputcolumn[14]= 11;
		$outputcolumn[15]= 12;
		$outputcolumn[16]= 13;
		$outputcolumn[17]= 14;
		$outputcolumn[18]= 15;
		$outputcolumn[19]= 16;

# add sort option

	include 'componentsortdata.php';



# add freetext search option

	include 'modulefreetextsearch.php';


		$keynumberofcolumns = 3;
		$keycolumn[1] = 17;
		$keyquery[1] = "SELECT drawinglogsupervisors.supervisor AS \"artist(s)\" FROM fielddata.drawinglogsupervisors WHERE drawinglogsupervisors.valid=true";
		$keysort[1] = "drawinglogsupervisors.supervisor";
		$keycolumn[2] = 17;
		$keyquery[2] = "SELECT drawinglogsquares.squarename AS \"square(s)\" FROM fielddata.drawinglogsquares WHERE drawinglogsquares.valid=true";
		$keysort[2] = "drawinglogsquares.squarename";
		$keycolumn[3] = 17;
		$keyquery[3] = "SELECT drawinglogfeatures.featurenumber AS \"feature(s)\" FROM fielddata.drawinglogfeatures WHERE drawinglogfeatures.valid=true";
		$keysort[3] = "drawinglogfeatures.featurenumber";

switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse drawing log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "drawings:";
		$text2 = "all";
		$savename="complete drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawing exist in database!";


		break;




////////// CASE SINGLE DRAWING


		case "browsesingledrawing":

		if	($season!='')
			{
				$query = "$superquery AND drawingnumber=$drawingnumber AND season='$season' $searchsql ORDER BY $sortsql;";
				$uservariables = "drawingnumber=$drawingnumber&season=$season&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse drawing log";
				$heading1 = "option:";
				$text1 = "single drawing";
				$heading2 = "drawing:";
				$text2 = "drawing $drawingnumber of season $season";
				$savename="drawing $drawingnumber of season $season from drawinglog";

			}
			else
			{
				$query = "$superquery AND drawingnumber=$drawingnumber $searchsql ORDER BY season, drawingnumber;";
				$uservariables = "drawingnumber=$drawingnumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse drawing log";
				$heading1 = "option:";
				$text1 = "single drawing";
				$heading2 = "drawing:";
				$text2 = "$drawingnumber";
				$savename="drawing $drawingnumber from drawinglog";

			}

		$norecordtext="ERROR!!!<br><br> Drawing does not exist in database!";

		break;


////////// CASE DRAWING SERIES

		case "browsedrawingseries":

			if	($season!='')
			{
				$query = "$superquery AND drawingnumber>=$firstdrawingnumber AND drawingnumber<=$lastdrawingnumber AND season='$season' $searchsql ORDER BY $sortsql;";
				$uservariables = "firstdrawingnumber=$firstdrawingnumber&lastdrawingnumber=$lastdrawingnumber&season=$season&sortsql=$sortsql&pageidentifiername=$pageidentifiername";
				$title = "browse drawing log";
				$heading1 = "option:";
				$text1 = "drawing series";
				$heading2 = "drawings:";
				$text2 = "drawing $firstdrawingnumber to $lastdrawingnumber of season $season";
				$savename="drawing series $firstdrawingnumber-$lastdrawingnumber of season $season from drawinglog";
			}
			else
			{
				$query = "$superquery AND drawingnumber>=$firstdrawingnumber AND drawingnumber<=$lastdrawingnumber $searchsql ORDER BY $sortsql;";
				$uservariables = "firstdrawingnumber=$firstdrawingnumber&lastdrawingnumber=$lastdrawingnumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse drawing log";
				$heading1 = "option:";
				$text1 = "drawing series";
				$heading2 = "drawings:";
				$text2 = "drawing $firstdrawingnumber to $lastdrawingnumber";
				$savename="drawing series $firstdrawingnumber-$lastdrawingnumber from drawinglog";
			}

		$norecordtext="ERROR!!!<br><br> Drawing series does not exist in database!";

		break;



////////// CASE BY SEASON

		case "browsebyseason":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "season='$filtervalues[$i]'";
			}
			$where_season = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_season =	"season='$season'";
			$headingstring = $season;
		}

		$query = "$superquery AND ($where_season) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&season=$season&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse drawinglog";
		$heading1 = "option:";
		$text1 = "by season";
		$heading2 = "drawings:";
		$text2 = "of season(s) $headingstring";
		$savename="all drawings of season(s) $headingstring from drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawings matching this season exist in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "drawinglogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"drawinglogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct(CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid, drawinglog.season, drawinglog.drawingnumber
					from fielddata.drawinglog inner join fielddata.drawinglogsquares on drawinglog.drawingid = drawinglogsquares.drawingid
					where ($where_square) and drawinglog.valid=true and drawinglogsquares.valid=true
					$searchsql
					ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$outputcolumns = 20;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 20;
		$outputcolumn[3]= 21;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 22;
		$outputcolumn[8]= 5;
		$outputcolumn[9]= 6;
		$outputcolumn[10]= 7;
		$outputcolumn[11]= 8;
		$outputcolumn[12]= 9;
		$outputcolumn[13]= 10;
		$outputcolumn[14]= 11;
		$outputcolumn[15]= 12;
		$outputcolumn[16]= 13;
		$outputcolumn[17]= 14;
		$outputcolumn[18]= 15;
		$outputcolumn[19]= 16;

		$title = "browse drawinglog";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "drawings:";
		$text2 = "of square(s) $headingstring";
		$savename="all drawings of square(s) $headingstring from drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawings matching this square exist in database!";

		break;



		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "drawinglog.area = '$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"drawinglog.area = '$area'";
			$headingstring = $area;
		}

		$query = "select (CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid
					from fielddata.drawinglog
					where ($where_area) and drawinglog.valid=true
					$searchsql
					ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse drawinglog";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "drawings:";
		$text2 = "of area(s) $headingstring";
		$savename="all drawings of area(s) $headingstring from drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawings matching this area exist in database!";

		break;



////////// CASE DRAWINGLOG BY FEATURE

		case "browsebyfeature":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "drawinglogfeatures.featurenumber = '$filtervalues[$i]'";
			}
			$where_feature = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_feature =	"drawinglogfeatures.featurenumber = '$featurenumber'";
			$headingstring = $featurenumber;
		}

		$query = "select distinct(CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid, drawinglog.season, drawinglog.drawingnumber
					FROM fielddata.drawinglog left join fielddata.drawinglogfeatures on drawinglog.drawingid = drawinglogfeatures.drawingid
					WHERE drawinglog.valid=true AND ($where_feature) and drawinglogfeatures.valid=true
					$searchsql
					ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$outputcolumns = 20;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 20;
		$outputcolumn[3]= 21;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 22;
		$outputcolumn[8]= 5;
		$outputcolumn[9]= 6;
		$outputcolumn[10]= 7;
		$outputcolumn[11]= 8;
		$outputcolumn[12]= 9;
		$outputcolumn[13]= 10;
		$outputcolumn[14]= 11;
		$outputcolumn[15]= 12;
		$outputcolumn[16]= 13;
		$outputcolumn[17]= 14;
		$outputcolumn[18]= 15;
		$outputcolumn[19]= 16;

		$title = "browse drawinglog";
		$heading1 = "option:";
		$text1 = "by feature";
		$heading2 = "drawings:";
		$text2 = "of feature(s) $headingstring";
		$savename="all drawings with feature(s) $headingstring from drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawings matching this feature exist in database!";

		break;



////////// CASE DRAWINGLOG BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "drawinglogsupervisors.supervisor='$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor = "drawinglogsupervisors.supervisor='$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "select distinct(CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid, drawinglog.season, drawinglog.drawingnumber
					FROM fielddata.drawinglog left join fielddata.drawinglogsupervisors on drawinglog.drawingid = drawinglogsupervisors.drawingid
					WHERE drawinglog.valid=true AND ($where_supervisor) and drawinglogsupervisors.valid=true
					$searchsql
					ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$outputcolumns = 20;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 20;
		$outputcolumn[3]= 21;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 22;
		$outputcolumn[8]= 5;
		$outputcolumn[9]= 6;
		$outputcolumn[10]= 7;
		$outputcolumn[11]= 8;
		$outputcolumn[12]= 9;
		$outputcolumn[13]= 10;
		$outputcolumn[14]= 11;
		$outputcolumn[15]= 12;
		$outputcolumn[16]= 13;
		$outputcolumn[17]= 14;
		$outputcolumn[18]= 15;
		$outputcolumn[19]= 16;

		$title = "browse drawinglog";
		$heading1 = "option:";
		$text1 = "by artist";
		$heading2 = "drawings:";
		$text2 = "of artist(s) $headingstring";
		$savename="all drawings of artist(s) $headingstring from drawinglog";
		$norecordtext="ERROR!!!<br><br> No drawings matching this supervisor exist in database!";

		break;



////////// CASE DRAWINGLOG FOR AREA DEFINITION

		case "dsrdrawinglog":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "drawinglogsquares.squarename='".$squarename[$i]."'";

			}
			$sqlsquares = "AND (".implode(" OR ", $squarename).")";
			$wheresquares = "AND drawinglogsquares.valid=true";
		}

		if ($countsupervisors>0)
		{
			$supervisor = explode("<br>or ", $listsupervisors);
			for ($i=0; $i<$countsupervisors; $i++)
			{
				$supervisor[$i] = "drawinglogsupervisors.supervisor='".$supervisor[$i]."'";
			}
			$sqlsupervisors = "AND (".implode(" OR ", $supervisor).")";
			$wheresupervisors = "AND drawinglogsupervisors.valid=true";
		}

		if ($area!='')
		{
			$sqlarea = "AND drawinglog.area='$area'";
		}


		$query = "select distinct(CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\",
					drawinglog.drawingid, drawinglog.season, drawinglog.drawingnumber, drawinglog.checked, drawinglog.drawingtype, drawinglog.scale, drawinglog.portfolionumber, drawinglog.locationoriginal, drawinglog.copied, drawinglog.scanned, drawinglog.cropped, drawinglog.renamed, drawinglog.burnttocd, drawinglog.scanuploaded,	drawinglog.drawingsenttoboston
					from (fielddata.drawinglog left join fielddata.drawinglogsquares on drawinglog.drawingid = drawinglogsquares.drawingid)
						left join fielddata.drawinglogsupervisors on drawinglog.drawingid = drawinglogsupervisors.drawingid
					WHERE drawinglog.valid=true $wheresquares $wheresupervisors	$sqlarea $sqlsquares $sqlsupervisors $searchsql
					ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "drawinglog";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records drawinglog from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No drawing for this query exist in database!";

		$keycolumn[1] = 17;
		$keycolumn[2] = 17;
		$keycolumn[3] = 17;

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 20;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 32;
		$outputcolumn[3]= 33;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 34;
		$outputcolumn[8]= 5;
		$outputcolumn[9]= 6;
		$outputcolumn[10]= 7;
		$outputcolumn[11]= 8;
		$outputcolumn[12]= 9;
		$outputcolumn[13]= 10;
		$outputcolumn[14]= 11;
		$outputcolumn[15]= 12;
		$outputcolumn[16]= 13;
		$outputcolumn[17]= 14;
		$outputcolumn[18]= 15;
		$outputcolumn[19]= 16;

		break;

	}


if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>