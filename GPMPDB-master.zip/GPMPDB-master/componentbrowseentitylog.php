<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select entitylog.entitynumber AS \"entity\", entitylog.entitytype AS \"type\", entitylog.entityname AS \"name\", entitylog.excavationarea AS \"area\", entitylog.date, entitylog.supervisor AS \"creator\", entitylog.description,
						entitylog.entitynumber
						from fielddata.entitylog WHERE entitylog.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 11;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 8;
		$outputcolumn[8]= 9;
		$outputcolumn[9]= 10;
		$outputcolumn[10]= 11;
		
		$keynumberofcolumns = 4;
		$keycolumn[1] = 7;
		$keycolumn[2] = 7;
		$keycolumn[3] = 7;
		$keycolumn[4] = 7;
		$keyquery[1] = "SELECT entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber AS \"defined by feature(s)\" FROM fielddata.entitylogdefinedbyfeaturenumbers WHERE entitylogdefinedbyfeaturenumbers.valid=true";
		$keyquery[2] = "SELECT entitylogincludesentitynumbers.inclentitynumber AS \"includes entity / entities\" FROM fielddata.entitylogincludesentitynumbers WHERE entitylogincludesentitynumbers.valid=true";
		$keyquery[3] = "SELECT entitylogincludesfeaturenumbers.inclfeaturenumber AS \"includes feature(s)\" FROM fielddata.entitylogincludesfeaturenumbers WHERE entitylogincludesfeaturenumbers.valid=true";
		$keyquery[4] = "SELECT '[' || entitylogchanges.date || ' ' || entitylogchanges.supervisor || '] ' || entitylogchanges.description AS \"modification(s)\" FROM fielddata.entitylogchanges WHERE entitylogchanges.valid=true";
		$keysort[1] = "entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber";
		$keysort[2] = "entitylogincludesentitynumbers.inclentitynumber";
		$keysort[3] = "entitylogincludesfeaturenumbers.inclfeaturenumber";
		$keysort[4] = "entitylogchanges.date";
		

# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


	
switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "entities:";
		$text2 = "all";
		$savename="complete entitylog";
		$norecordtext="ERROR!!!<br><br> No entities exist in database!";

		break;


		
////////// CASE BY ENTITY

		case "browsesingleentity":

		$query = "$superquery AND entitynumber=$entitynumber $searchsql ORDER BY $sortsql;";
		$uservariables = "entitynumber=$entitynumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "single entity";
		$heading2 = "entity:";
		$text2 = "$entitynumber";
		$savename="entity $entitynumber from entitylog";
		$norecordtext="ERROR!!!<br><br> Entity does not exist in database!";

		break;


		
////////// CASE ENTITY SERIES

		case "browseentityseries":

		$query = "$superquery AND entitynumber>=$firstentitynumber AND entitynumber<=$lastentitynumber $searchsql ORDER BY $sortsql;";
		$uservariables = "firstentitynumber=$firstentitynumber&lastentitynumber=$lastentitynumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "entity series";
		$heading2 = "entities:";
		$text2 = "$firstentitynumber - $lastentitynumber";
		$savename="entities $firstentitynumber - $lastentitynumber from entitylog";
		$norecordtext="ERROR!!!<br><br> Selected entity series does not exist in database!";

		break;

		
////////// CASE BY ENTITY TYPE

		case "browsebyentitytype":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "entitytype='$filtervalues[$i]'";
			}
			$where_entitytype = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_entitytype =	"entitytype='$entitytype'";
			$headingstring = $entitytype;
		}
		
		$query = "$superquery AND ($where_entitytype) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&entitytype=$entitytype&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "by entity type";
		$heading2 = "entity type(s):";
		$text2 = "$headingstring";
		$savename="entities with entitytype(s) $headingstring from entitylog";
		$norecordtext="ERROR!!!<br><br> No entities with this type exist in database!";

		break;
		
		
////////// CASE BY EXCAVATION AREA

		case "browsebyexcavationarea":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "excavationarea='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"excavationarea='$excavationarea'";
			$headingstring = $excavationarea;
		}

		$query = "$superquery AND ($where_area) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&excavationarea=$excavationarea&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "by excavation area";
		$heading2 = "excavation area(s):";
		$text2 = $headingstring;
		$savename="entities with excavationarea(s) $headingstring from entitylog";
		$norecordtext="ERROR!!!<br><br> No entities of this excavation area exist in database!";

		break;
		
		
////////// CASE BY SUPERVISOR

		case "browsebysupervisor":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "supervisor='$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor = "supervisor='$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "$superquery AND ($where_supervisor) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="entities of supervisor(s) $headingstring from entitylog";
		$norecordtext="ERROR!!!<br><br> No entities of this supervisor exist in database!";

		break;


		case "browsebydeffeature":

		$query = "select entitylog.entitynumber AS \"entity\", entitylog.entitytype AS \"type\", entitylog.entityname AS \"name\", entitylog.excavationarea AS \"area\", entitylog.date, entitylog.supervisor AS \"creator\", entitylog.description,
					entitylog.entitynumber
					FROM fielddata.entitylog LEFT JOIN fielddata.entitylogdefinedbyfeaturenumbers ON entitylog.entitynumber=entitylogdefinedbyfeaturenumbers.entitynumber
					WHERE entitylog.valid=true AND entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber=$featurenumber AND entitylogdefinedbyfeaturenumbers.valid=true
					$searchsql
					ORDER BY $sortsql;";
		$uservariables = "featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "by defined by feature";
		$heading2 = "feature:";
		$text2 = "$featurenumber";
		$savename="entities of defined by feature $featurenumber from entitylog";
		$norecordtext="ERROR!!!<br><br> No entities of this defined by feature exist in database!";

		break;

		
		case "browsebyinclfeature":

		$query = "select entitylog.entitynumber AS \"entity\", entitylog.entitytype AS \"type\", entitylog.entityname AS \"name\", entitylog.excavationarea AS \"area\", entitylog.date, entitylog.supervisor AS \"creator\", entitylog.description,
					entitylog.entitynumber
					FROM fielddata.entitylog LEFT JOIN fielddata.entitylogincludesfeaturenumbers ON entitylog.entitynumber=entitylogincludesfeaturenumbers.entitynumber
					WHERE entitylog.valid=true AND entitylogincludesfeaturenumbers.inclfeaturenumber=$featurenumber AND entitylogincludesfeaturenumbers.valid=true
					$searchsql
					ORDER BY $sortsql;";
		$uservariables = "featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse entity log";
		$heading1 = "option:";
		$text1 = "by includes feature";
		$heading2 = "feature:";
		$text2 = "$featurenumber";
		$savename="entities of includes feature $featurenumber from entitylog";
		$norecordtext="ERROR!!!<br><br> No entities of this includes feature exist in database!";

		break;
	}


if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}

?>