<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";



////////// GENERAL VARIABLES

		$superquery = "select exoticmaterialregister.exoticmaterialregisterid, exoticmaterialregister.featurenumber AS \"feature\", exoticmaterialregister.date, exoticmaterialregister.materialcategory AS \"category\", exoticmaterialregister.count, (CASE WHEN exoticmaterialregister.weightprefix IS NULL THEN '' WHEN exoticmaterialregister.weightprefix IS NOT NULL THEN exoticmaterialregister.weightprefix END) || exoticmaterialregister.weight as \"weight (g)\", exoticmaterialregister.comments from fielddata.exoticmaterialregister WHERE exoticmaterialregister.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 6;
		$outputcolumn[6]= 7;

		$keynumberofcolumns = 1;
		$keycolumn[1] = 0;
		$keyquery[1] = "SELECT exoticmaterialregistersquares.squarename as \"square(s)\" FROM fielddata.exoticmaterialregistersquares WHERE exoticmaterialregistersquares.valid=true";
		$keysort[1] = "exoticmaterialregistersquares.squarename";
		

# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompleteregister":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse exotic material register";
		$heading1 = "option:";
		$text1 = "complete register";
		$heading2 = "exotics:";
		$text2 = "all";
		$savename="complete exoticmaterialregister";
		$norecordtext="ERROR!!!<br><br> No exotics exist in database!";

		break;



////////// CASE BY FEATURE

		case "browsebyfeature":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "exoticmaterialregister.featurenumber='$filtervalues[$i]'";
			}
			$where_feature = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_feature =	"exoticmaterialregister.featurenumber='$featurenumber'";
			$headingstring = $featurenumber;
		}
		
		$query = "$superquery AND ($where_feature) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse exotic material register";
		$heading1 = "option:";
		$text1 = "by feature";
		$heading2 = "exotics:";
		$text2 = "of feature(s) $headingstring";
		$savename="all exotics of feature(s) $headingstring from exoticmaterialregister";
		$norecordtext="ERROR!!!<br><br> No exotics matching this feature exist in database!";

		break;

		
////////// CASE EXOTICS FOR AREA DEFINITION

		case "dsrexoticmaterialregister":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "exoticmaterialregistersquares.squarename='".$squarename[$i]."'";
			}
			$sqlexoticsquares = "OR (".implode(" OR ", $squarename).")";
		}

		$query = "select distinct exoticmaterialregister.exoticmaterialregisterid, exoticmaterialregister.featurenumber AS \"feature\", exoticmaterialregister.date, exoticmaterialregister.materialcategory AS \"category\", exoticmaterialregister.count, (CASE WHEN exoticmaterialregister.weightprefix IS NULL THEN '' WHEN exoticmaterialregister.weightprefix IS NOT NULL THEN exoticmaterialregister.weightprefix END) || exoticmaterialregister.weight as \"weight (g)\", exoticmaterialregister.comments,
						exoticmaterialregister.featurenumber, exoticmaterialregister.materialcategory, exoticmaterialregister.weight
						from (((fielddata.exoticmaterialregister left join fielddata.featurelogareas on exoticmaterialregister.featurenumber = featurelogareas.featurenumber) left join fielddata.featurelogsquares on exoticmaterialregister.featurenumber = featurelogsquares.featurenumber) left join fielddata.featurelogsupervisors on exoticmaterialregister.featurenumber = featurelogsupervisors.featurenumber) left join fielddata.exoticmaterialregistersquares on exoticmaterialregister.exoticmaterialregisterid = exoticmaterialregistersquares.exoticmaterialregisterid 
						WHERE exoticmaterialregister.valid=true $wherearea $wheresquares $wheresupervisors
						$sqlarea $sqlsquares $sqlsupervisors $sqlexoticsquares
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "exoticmaterialregister";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records exoticmaterialregister from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No exotics for this query exist in database!";
		
		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 6;
		$outputcolumn[6]= 10;
		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>