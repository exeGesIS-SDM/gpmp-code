<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select featurelog.featurenumber as feature, featurelog.date, featurelog.description, featurelog.featurenumber from fielddata.featurelog WHERE featurelog.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176";

		$filedownloadheader="pdf feature forms";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/featureforms";
		$filedownloadextension="pdf";
		$filedownloadcolumn=0;


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 5;
		$outputcolumn[4]= 6;
		$outputcolumn[5]= 2;
		$outputcolumn[6]= 7;
		$outputcolumn[7]= 8;

# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';


		$keynumberofcolumns = 5;
		$keycolumn[1] = 3;
		$keyquery[1] = "SELECT featurelogsquares.squarename as \"square(s)\" FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keysort[1] = "featurelogsquares.squarename";
		$keycolumn[2] = 3;
		$keyquery[2] = "SELECT featurelogareas.area as \"area(s)\" FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keysort[2] = "featurelogareas.area";
		$keycolumn[3] = 3;
		$keyquery[3] = "SELECT featurelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.featurelogsupervisors WHERE featurelogsupervisors.valid=true";
		$keysort[3] = "featurelogsupervisors.supervisor";
		$keycolumn[4] = 3;
		$keyquery[4] = "SELECT reassignedfeatures.oldfeaturenumber as \"old feature number\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[4] = "reassignedfeatures.oldfeaturenumber";
		$keycolumn[5] = 3;
		$keyquery[5] = "SELECT reassignedfeatures.olddate as \"old date\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[5] = "reassignedfeatures.oldfeaturenumber";


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE LOG

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "features:";
		$text2 = "all";
		$savename="complete featurelog";
		$norecordtext="ERROR!!!<br><br> No features exist in database!";

		break;



////////// CASE REASSIGNED FEATURES

		case "browsereassignedfeatures":

		$query = "select featurelog.featurenumber as feature, featurelog.date, featurelog.description, featurelog.featurenumber, reassignedfeatures.oldfeaturenumber AS \"old feature number\"
					FROM fielddata.featurelog left join fielddata.reassignedfeatures ON featurelog.featurenumber=reassignedfeatures.featurenumber
					WHERE featurelog.valid=true AND reassignedfeatures.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176 AND reassignedfeatures.oldfeaturenumber IS NOT NULL
					$searchsql
					ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "reassigned features";
		$heading2 = "features:";
		$text2 = "all reassigned";
		$savename="reassigned features from featurelog";
		$norecordtext="ERROR!!!<br><br> No reassigned features exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 5;
		$outputcolumn[3]= 6;
		$outputcolumn[4]= 7;
		$outputcolumn[5]= 2;
		$outputcolumn[6]= 8;
		$outputcolumn[7]= 9;

		break;



////////// CASE SINGLEFEATURE


		case "browsesinglefeature":

		$query = "$superquery AND featurelog.featurenumber=$featurenumber $searchsql;";
		$uservariables = "featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "single feature";
		$heading2 = "feature:";
		$text2 = "$featurenumber";
		$savename="feature $featurenumber from featurelog";
		$norecordtext="ERROR!!!<br><br> Feature does not exist in database!";

		break;


////////// CASE FEATURESERIES

		case "browsefeatureseries":

		$query = "$superquery AND featurelog.featurenumber>=$firstfeaturenumber AND featurelog.featurenumber<=$lastfeaturenumber $searchsql ORDER BY $sortsql;";
		$uservariables = "firstfeaturenumber=$firstfeaturenumber&lastfeaturenumber=$lastfeaturenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "feature series";
		$heading2 = "features:";
		$text2 = "$firstfeaturenumber - $lastfeaturenumber";
		$savename="feature series $firstfeaturenumber-$lastfeaturenumber from featurelog";
		$norecordtext="ERROR!!!<br><br> None of the selected features in this series do exist in database!";

		break;



////////// CASE BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "listexcavators.fullnames = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor =	"listexcavators.fullnames = '$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "select distinct featurelog.featurenumber AS feature, featurelog.date, featurelog.description, featurelog.featurenumber
				from (fielddata.featurelog left join fielddata.featurelogsupervisors on featurelog.featurenumber = featurelogsupervisors.featurenumber) left join fielddata.listexcavators on featurelogsupervisors.supervisor = listexcavators.initials
				where ($where_supervisor) and featurelog.valid=true and featurelogsupervisors.valid=true and listexcavators.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176
				$searchsql
				ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="features from supervisor(s) $headingstring from featurelog";
		$norecordtext="ERROR!!!<br><br> No features exist for this supervisor(s) in database!";

		break;



////////// CASE BY DATE


		case "browsebydate":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "featurelog.date = '$filtervalues[$i]'";
			}
			$where_date = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_date =	"featurelog.date = '$date'";
			$headingstring = $date;
		}

		$query = "$superquery AND ($where_date) $searchsql ORDER BY $sortsql";
		$uservariables = "filtervaluesserial=$filtervaluesserial&date=$date&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "by date";
		$heading2 = "date(s):";
		$text2 = $headingstring;
		$savename="features from date(s) $headingstring from featurelog";
		$norecordtext="ERROR!!!<br><br> No feature exist for this date in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "featurelogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"featurelogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct featurelog.featurenumber AS feature, featurelog.date, featurelog.description, featurelog.featurenumber
				from fielddata.featurelog inner join fielddata.featurelogsquares on featurelog.featurenumber = featurelogsquares.featurenumber
				where ($where_square) and featurelog.valid=true and featurelogsquares.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="features from square(s) $headingstring from featurelog";
		$norecordtext="ERROR!!!<br><br> No feature exist for this square in database!";

		break;


		////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "featurelogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"featurelogareas.area='$area'";
			$headingstring = $area;
		}


		$query = "select distinct featurelog.featurenumber AS feature, featurelog.date, featurelog.description, featurelog.featurenumber
				from fielddata.featurelog inner join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber
				where ($where_area) and featurelog.valid=true and featurelogareas.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176
				$searchsql
				order by $sortsql;";

		//echo $query;

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="features from area(s) $headingstring from featurelog";
		$norecordtext="ERROR!!!<br><br> No feature exist for this area in database!";

		break;


////////// CASE FEATURELOG FOR AREA DEFINITION

		case "dsrfeaturelog":

		$query = "select distinct featurelog.featurenumber as feature, featurelog.date, featurelog.description, featurelog.featurenumber
						from ((fielddata.featurelog left join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber) left join fielddata.featurelogsquares on featurelog.featurenumber = featurelogsquares.featurenumber) left join fielddata.featurelogsupervisors on featurelog.featurenumber = featurelogsupervisors.featurenumber
						WHERE featurelog.valid=true
						$sqlarea $sqlsquares $sqlsupervisors
						AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176 $wherearea $wheresquares $wheresupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "featurelog";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records featurelog from area/squares/supervisors";
		$norecordtext="ERROR!!!<br><br> No features for this query exist in database!";

		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>