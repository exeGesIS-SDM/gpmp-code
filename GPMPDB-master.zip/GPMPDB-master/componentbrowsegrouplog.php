<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select grouplog.groupnumber, grouplog.date, grouplog.description, grouplog.phase from fielddata.grouplog WHERE grouplog.valid=true";

		#$filedownloadheader="pdf feature forms";
		#$filedownloadlink="http://gpmpfiles.esdm.co.uk/groupforms";
		#$filedownloadextension="pdf";
		#$filedownloadcolumn=0;


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 4;
		$outputcolumn[2]= 5;
		$outputcolumn[3]= 1;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 6;
		$outputcolumn[6]= 3;
		
# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';


		

		$keynumberofcolumns = 3;

		$keycolumn[1] = 0;
		$keyquery[1] = "SELECT grouplogareas.area as \"area(s)\" FROM fielddata.grouplogareas WHERE grouplogareas.valid=true";
		$keysort[1] = "grouplogareas.area";
		$keycolumn[2] = 0;
		$keyquery[2] = "SELECT grouplogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.grouplogsupervisors WHERE grouplogsupervisors.valid=true";
		$keysort[2] = "grouplogsupervisors.supervisor";
		$keycolumn[3] = 0;
		$keyquery[3] = "SELECT grouplogfeatures.featurenumber as \"feature(s)\" FROM fielddata.grouplogfeatures WHERE grouplogfeatures.valid=true";
		$keysort[3] = "grouplogfeatures.featurenumber";		



switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE LOG

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse group log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "group numbers:";
		$text2 = "all";
		$savename="complete grouplog";
		$norecordtext="ERROR!!!<br><br> No groups exist in database!";

		break;


////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "grouplogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"grouplogareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct grouplog.groupnumber, grouplog.date, grouplog.description, grouplog.phase from fielddata.grouplog inner join fielddata.grouplogareas on grouplog.groupnumber = grouplogareas.groupnumber where ($where_area) and grouplog.valid=true $searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse group log";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="groups from area(s) $headingstring from grouplog";
		$norecordtext="ERROR!!!<br><br> No group exist for this area in database!";

		break;

	}
if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>