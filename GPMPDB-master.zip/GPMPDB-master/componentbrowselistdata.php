<?php

# switch sorting AND freetext searching options off (remove sorting bar in output)

	$nosortingoptions='yes';
	$nosearchoptions='yes';	
			
switch ($submenuaction)
	{
		case "":
		break;


////////// CASE LIST AREAS

		case "listareas":

		$query = "select listareas.area AS \"abbreviation\", listareas.areafullname AS \"full name\"
				from fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";

		$pageidentifiername = "abbreviation";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listareas";
		$heading2 = "areas:";
		$text2 = "complete list";
		$savename="list data from listareas";
		$norecordtext="ERROR!!!<br><br> No entries for listareas exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		break;


////////// CASE LIST BAG CATEGORIES

		case "listbagcategories":

		$query = "select listbagcategories.bagcategory AS \"category\"
				from fielddata.listbagcategories WHERE listbagcategories.valid=true ORDER BY listbagcategories.bagcategory;";

		$pageidentifiername = "category";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listbagcategories";
		$heading2 = "bagcategories:";
		$text2 = "complete list";
		$savename="list data from listbagcategories";
		$norecordtext="ERROR!!!<br><br> No entries for listbagcategories exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 1;
		$outputcolumn[0]= 0;
		
		break;
		

////////// CASE LIST ENTITY TYPES

		case "listentitytypes":

		$query = "select listentitytypes.entitytype AS \"type\"
				from fielddata.listentitytypes WHERE listentitytypes.valid=true ORDER BY listentitytypes.entitytype;";

		$pageidentifiername = "type";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listentitytypes";
		$heading2 = "entitytypes:";
		$text2 = "complete list";
		$savename="list data from listentitytypes";
		$norecordtext="ERROR!!!<br><br> No entries for listentitytypes exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 1;
		$outputcolumn[0]= 0;
		
		break;


////////// CASE LIST EXCAVATORS

		case "listexcavators":

		$query = "select listexcavators.initials AS \"initials\", listexcavators.fullnames AS \"full name\"
				from fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";

		$pageidentifiername = "initials";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listexcavators";
		$heading2 = "excavators:";
		$text2 = "complete list";
		$savename="list data from listexcavators";
		$norecordtext="ERROR!!!<br><br> No entries for listexcavators exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		break;


////////// CASE LIST EXOITC MATERIAL CATEGORIES

		case "listexoticmaterialcategories":

		$query = "select listexoticmaterialcategories.materialcategory AS \"category\"
				from fielddata.listexoticmaterialcategories WHERE listexoticmaterialcategories.valid=true ORDER BY listexoticmaterialcategories.materialcategory;";

		$pageidentifiername = "category";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listexoticmaterialcategories";
		$heading2 = "materialcategories:";
		$text2 = "complete list";
		$savename="list data from listexoticmaterialcategories";
		$norecordtext="ERROR!!!<br><br> No entries for listexoticmaterialcategories exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 1;
		$outputcolumn[0]= 0;
		
		break;


////////// CASE LIST FEATURE TYPE GROUPS

		case "listfeaturetypegroups":

		$query = "select listfeaturetypegroups.featuretypegroup AS \"group\", listfeaturetypegroups.groupname AS \"name\"
				from fielddata.listfeaturetypegroups WHERE listfeaturetypegroups.valid=true ORDER BY listfeaturetypegroups.featuretypegroup;";

		$pageidentifiername = "group";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listfeaturetypegroups";
		$heading2 = "featuretypegroups:";
		$text2 = "complete list";
		$savename="list data from listfeaturetypegroups";
		$norecordtext="ERROR!!!<br><br> No entries for listfeaturetypegroups exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		break;


////////// CASE LIST FEATURE TYPES

		case "listfeaturetypes":

		$query = "select listfeaturetypes.featuretype AS \"type\", listfeaturetypes.featuretypegroup AS \"group\"
				from fielddata.listfeaturetypes WHERE listfeaturetypes.valid=true ORDER BY listfeaturetypes.featuretype;";

		$pageidentifiername = "type";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listfeaturetypes";
		$heading2 = "featuretypes:";
		$text2 = "complete list";
		$savename="list data from listfeaturetypes";
		$norecordtext="ERROR!!!<br><br> No entries for listfeaturetypes exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		break;


////////// CASE LIST SAMPLE TYPES

		case "listsampletypes":

		$query = "select listsampletypes.sampletype AS \"type\"
				from fielddata.listsampletypes WHERE listsampletypes.valid=true ORDER BY listsampletypes.sampletype;";

		$pageidentifiername = "type";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listsampletypes";
		$heading2 = "sampletypes:";
		$text2 = "complete list";
		$savename="list data from listsampletypes";
		$norecordtext="ERROR!!!<br><br> No entries for listsampletypes exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 1;
		$outputcolumn[0]= 0;
		
		break;



////////// CASE LIST SITE SEASONS

		case "listsiteseasons":

		$query = "select listsiteseasons.seasonname AS \"season name\", listsiteseasons.startdate AS \"start date\", listsiteseasons.enddate AS \"end date\"
				from fielddata.listsiteseasons WHERE listsiteseasons.valid=true ORDER BY listsiteseasons.seasonname;";

		$pageidentifiername = "season name";

		$title = "browse list data";
		$heading1 = "option:";
		$text1 = "listsiteseasons";
		$heading2 = "site seasons:";
		$text2 = "complete list";
		$savename="list data from listsiteseasons";
		$norecordtext="ERROR!!!<br><br> No entries for listsiteseasons exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		break;
	}



if ($submenuaction!='')
{
	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	else
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>