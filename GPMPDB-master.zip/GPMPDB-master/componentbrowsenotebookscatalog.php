<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";



////////// GENERAL VARIABLES

		$superquery = "select notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\"
			from fielddata.notebookscatalog where notebookscatalog.valid=true";

		$filedownloadheader="pdf file";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/notebooks";
		$filedownloadextension="pdf";
		$filedownloadcolumn=1;


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 10;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 8;
		$outputcolumn[2]= 9;
		$outputcolumn[3]= 10;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;
		$outputcolumn[8]= 6;
		$outputcolumn[9]= 7;

		$keynumberofcolumns = 3;
		$keycolumn[1] = "0";
		$keycolumn[2] = "0";
		$keycolumn[3] = "0";
		$keyquery[1] = "SELECT notebookscatalogareas.area AS \"area(s)\" FROM fielddata.notebookscatalogareas WHERE notebookscatalogareas.valid=true";
		$keyquery[2] = "SELECT notebookscatalogsquares.squarename AS \"square(s)\" FROM fielddata.notebookscatalogsquares WHERE notebookscatalogsquares.valid=true";
		$keyquery[3] = "SELECT notebookscatalogsupervisors.supervisor AS \"supervisor(s)\" FROM fielddata.notebookscatalogsupervisors WHERE notebookscatalogsupervisors.valid=true";
		$keysort[1] = "notebookscatalogareas.area";
		$keysort[2] = "notebookscatalogsquares.squarename";
		$keysort[3] = "notebookscatalogsupervisors.supervisor";


# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';



switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse notebookscatalog";
		$heading1 = "option:";
		$text1 = "complete catalog";
		$heading2 = "notebooks:";
		$text2 = "all";
		$savename="complete notebookscatalog";
		$norecordtext="ERROR!!!<br><br> No notebooks exist in database!";

		break;


////////// CASE BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "listexcavators.fullnames = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor =	"listexcavators.fullnames = '$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "select distinct notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\"
				from (fielddata.notebookscatalog left join fielddata.notebookscatalogsupervisors on notebookscatalog.notebookid = notebookscatalogsupervisors.notebookid) left join fielddata.listexcavators on notebookscatalogsupervisors.supervisor = listexcavators.initials
				where ($where_supervisor) and notebookscatalog.valid=true and notebookscatalogsupervisors.valid=true and listexcavators.valid=true
				$searchsql
				ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse notebooks catalog";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="notebooks from supervisor(s) $headingstring from notebooks catalog";
		$norecordtext="ERROR!!!<br><br> No notebooks exist for this supervisor in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "notebookscatalogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"notebookscatalogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\"
				from fielddata.notebookscatalog inner join fielddata.notebookscatalogsquares on notebookscatalog.notebookid = notebookscatalogsquares.notebookid
				where ($where_square) and notebookscatalog.valid=true and notebookscatalogsquares.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse notebooks catalog";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="notebooks from square(s) $headingstring from notebooks catalog";
		$norecordtext="ERROR!!!<br><br> No notebooks exist for this square in database!";

		break;


////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "notebookscatalogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"notebookscatalogareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\"
				from fielddata.notebookscatalog inner join fielddata.notebookscatalogareas on notebookscatalog.notebookid = notebookscatalogareas.notebookid
				where ($where_area) and notebookscatalog.valid=true and notebookscatalogareas.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse notebooks catalog";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="notebooks from area(s) $headingstring from notebooks catalog";
		$norecordtext="ERROR!!!<br><br> No notebooks exist for this area in database!";

		break;



////////// CASE NOTEBOOKS FOR AREA DEFINITION

		case "dsrnotebookscatalog":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "notebookscatalogsquares.squarename='".$squarename[$i]."'";
			}
			$sqlsquares = "AND (".implode(" OR ", $squarename).")";
			$wheresquares = "AND notebookscatalogsquares.valid=true";
		}

		if ($countsupervisors>0)
		{
			$supervisor = explode("<br>or ", $listsupervisors);
			for ($i=0; $i<$countsupervisors; $i++)
			{
				$supervisor[$i] = "notebookscatalogsupervisors.supervisor='".$supervisor[$i]."'";
			}
			$sqlsupervisors = "AND (".implode(" OR ", $supervisor).")";
			$wheresupervisors = "AND notebookscatalogsupervisors.valid=true";
		}

		if ($area!='')
		{
			$sqlarea = "AND notebookscatalogareas.area='$area'";
			$wherearea = "AND notebookscatalogareas.valid=true";
		}


		$query = "select distinct notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\",
						notebookscatalog.notebookname, notebookscatalog.datestarted, notebookscatalog.datecompleted, notebookscatalog.cdlocation, notebookscatalog.bindertype, notebookscatalog.arearecordbinderlocation
						from ((fielddata.notebookscatalog left join fielddata.notebookscatalogsquares on notebookscatalog.notebookid = notebookscatalogsquares.notebookid) left join fielddata.notebookscatalogsupervisors on notebookscatalog.notebookid = notebookscatalogsupervisors.notebookid) left join fielddata.notebookscatalogareas on notebookscatalog.notebookid = notebookscatalogareas.notebookid
						WHERE notebookscatalog.valid=true $wherearea $wheresquares $wheresupervisors
						$sqlarea $sqlsquares $sqlsupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "notebooks";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records notebookscatalog from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No notebook for this query exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 10;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 13;
		$outputcolumn[2]= 14;
		$outputcolumn[3]= 15;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;
		$outputcolumn[8]= 6;
		$outputcolumn[9]= 7;
		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>