<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


# general variables
		$superquery = "select photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
					from fielddata.photolog	where photolog.valid=true";

		$imagenumbercolumn = 1;


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 12;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 10;
		$outputcolumn[2]= 7;
		$outputcolumn[3]= 8;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;
		$outputcolumn[8]= 6;
		$outputcolumn[9]= 9;
		$outputcolumn[10]= 11;
		$outputcolumn[11]= 12;
		
		$keynumberofcolumns = 6;
		$keycolumn[1] = 0;
		$keyquery[1] = "select photologsquares.squarename AS \"square(s)\" from fielddata.photologsquares where photologsquares.valid=true";
		$keysort[1] = "photologsquares.squarename";
		$keycolumn[2] = 0;
		$keyquery[2] = "select photologfeatures.featurenumber AS \"feature(s)\" from fielddata.photologfeatures where photologfeatures.valid=true";
		$keysort[2] = "photologfeatures.featurenumber";
		$keycolumn[3] = 0;
		$keyquery[3] = "select (CASE WHEN photologspecialists.specialistcategory IS NULL THEN '' WHEN photologspecialists.specialistcategory IS NOT NULL THEN photologspecialists.specialistcategory END) || ': ' || (CASE WHEN photologspecialists.specialistid IS NULL THEN '' WHEN photologspecialists.specialistid IS NOT NULL THEN photologspecialists.specialistid END) AS \"specialist record(s)\" from fielddata.photologspecialists where photologspecialists.valid=true";
		$keysort[3] = "photologspecialists.specialistcategory";
		$keycolumn[4] = 0;
		$keyquery[4] = "select photologareas.area AS \"area(s)\" from fielddata.photologareas where photologareas.valid=true";
		$keysort[4] = "photologareas.area";
		$keycolumn[5] = 0;
		$keyquery[5] = "select photologindex.indexcode AS \"index code(s)\" from fielddata.photologindex where photologindex.valid=true";
		$keysort[5] = "photologindex.indexcode";
		$keycolumn[6] = 0;
		$keyquery[6] = "select photologrelatedphotos.imagenumber AS \"related images\" from fielddata.photologrelatedphotos where photologrelatedphotos.valid=true";
		$keysort[6] = "photologrelatedphotos.imagenumber";		

# add sort option
	
	include 'componentsortdata.php';
		

# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
	{
		case "":
		break;

		
		case "browsecompletelog":

		$query = "$superquery $searchsql order by $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "photos:";
		$text2 = "all";
		$savename="complete photolog";
		$norecordtext="ERROR!!!<br><br> No photos exist in database!";
		
		break;


		case "browsesinglephoto":

		$query = "$superquery AND photolog.imagenumber=$imagenumber
				$searchsql order by $sortsql;";

		$uservariables = "imagenumber=$imagenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by imagenumber";
		$heading2 = "photo:";
		$text2 = "$imagenumber";
		$savename="photo $imagenumber from photolog";
		$norecordtext="ERROR!!!<br><br> No photo with this imagenumber exists in database!";
		
		break;


		case "browsephotoseries":

		$query = "$superquery AND photolog.imagenumber>=$firstimagenumber AND photolog.imagenumber<=$lastimagenumber
				$searchsql order by $sortsql;";

		$uservariables = "firstimagenumber=$firstimagenumber&lastimagenumber=$lastimagenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by imagenumber series";
		$heading2 = "photos:";
		$text2 = "$firstimagenumber - $lastimagenumber";
		$savename="photos $firstimagenumber - $lastimagenumber from photolog";
		$norecordtext="ERROR!!!<br><br> No photos of this imagenumber series exists in database!";
		
		break;


		case "browsebyfeature":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "photologfeatures.featurenumber = '$filtervalues[$i]'";
			}
			$where_feature = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_feature = "photologfeatures.featurenumber='$featurenumber'";
			$headingstring = $featurenumber;
		}
		
		$query = "select distinct photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
				from fielddata.photolog	LEFT JOIN fielddata.photologfeatures ON photolog.photoid=photologfeatures.photoid
				where photolog.valid=true AND photologfeatures.valid=true AND ($where_feature)
				$searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by feature";
		$heading2 = "feature(s):";
		$text2 = $headingstring;
		$savename="photos of feature(s) $headingstring from photolog";
		$norecordtext="ERROR!!!<br><br> No photos of this feature number exist in database!";
		
		break;


		case "browsebyarea":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "photologareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area = "photologareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
				from fielddata.photolog	LEFT JOIN fielddata.photologareas ON photolog.photoid=photologareas.photoid
				where photolog.valid=true AND photologareas.valid=true AND ($where_area)
				$searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="photos of area(s) $headingstring from photolog";
		$norecordtext="ERROR!!!<br><br> No photo of this area exists in database!";
		
		break;


		case "browsebysquare":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "photologsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square = "photologsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
				from fielddata.photolog	LEFT JOIN fielddata.photologsquares ON photolog.photoid=photologsquares.photoid
				where photolog.valid=true AND photologsquares.valid=true AND ($where_square)
				$searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="photos of square(s) $headingstring from photolog";
		$norecordtext="ERROR!!!<br><br> No photos of this square exist in database!";
		
		break;

		
		case "browsebyindex":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "photologindex.indexcode='$filtervalues[$i]'";
			}
			$where_index = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_index = "photologindex.indexcode='$indexcode'";
			$headingstring = $indexcode;
		}

		$query = "select distinct photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
				from fielddata.photolog	LEFT JOIN fielddata.photologindex ON photolog.photoid=photologindex.photoid
				where photolog.valid=true AND photologindex.valid=true AND ($where_index)
				$searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&indexcode=$indexcode&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by index";
		$heading2 = "index code(s):";
		$text2 = $headingstring;
		$savename="photos of index code(s) $headingstring from photolog";
		$norecordtext="ERROR!!!<br><br> No photos of this index exist in database!";
		
		break;
		
		
		case "browsebyphotographer":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "photolog.photographer='$filtervalues[$i]'";
			}
			$where_photographer = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_photographer = "photolog.photographer='$photographer'";
			$headingstring = $photographer;
		}

		$query = "$superquery AND ($where_photographer) $searchsql order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&photographer=$photographer&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse photolog";
		$heading1 = "option:";
		$text1 = "by photographer";
		$heading2 = "photographer(s):";
		$text2 = $headingstring;
		$savename="photos of photographer(s) $headingstring from photolog";
		$norecordtext="ERROR!!!<br><br> No photo of this photographer exists in database!";
		
		break;



		case "browsebyspecialistinfo":

		if ($specialistid=='' and $specialistcategory!='')
		{

			$query = "select photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
					from fielddata.photolog	LEFT JOIN fielddata.photologspecialists ON photolog.photoid=photologspecialists.photoid
					where photolog.valid=true AND photologspecialists.valid=true AND photologspecialists.specialistcategory='$specialistcategory'
					$searchsql order by $sortsql;";

			$uservariables = "specialistcategory=$specialistcategory&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
			$title = "browse photolog";
			$heading1 = "option:";
			$text1 = "by specialist info";
			$heading2 = "specialist category:";
			$text2 = "$specialistcategory";
			$savename="photos of specialistcategory $specialistcategory from photolog";
			$norecordtext="ERROR!!!<br><br> No photos of this specialist category exist in database!";
		}
		elseif ($specialistid!='' and $specialistcategory!='')
		{
			$query = "select photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
					from fielddata.photolog	LEFT JOIN fielddata.photologspecialists ON photolog.photoid=photologspecialists.photoid
					where photolog.valid=true AND photologspecialists.valid=true AND photologspecialists.specialistcategory='$specialistcategory' AND photologspecialists.specialistid='$specialistid'
					$searchsql order by $sortsql;";

			$uservariables = "specialistid=$specialistid&specialistcategory=$specialistcategory&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
			$title = "browse photolog";
			$heading1 = "option:";
			$text1 = "by specialist info";
			$heading2 = "specialist category + id:";
			$text2 = "$specialistcategory + $specialistid";
			$savename="photos of specialistcategory $specialistcategory and id $specialistid from photolog";
			$norecordtext="ERROR!!!<br><br> No photos of this specialist category and id exist in database!";
		}
		elseif ($specialistid!='' and $specialistcategory=='')
		{
			$query = "select photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
					from fielddata.photolog	LEFT JOIN fielddata.photologspecialists ON photolog.photoid=photologspecialists.photoid
					where photolog.valid=true AND photologspecialists.valid=true AND photologspecialists.specialistid='$specialistid'
					$searchsql order by $sortsql;";

			$uservariables = "specialistid=$specialistid&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
			$title = "browse photolog";
			$heading1 = "option:";
			$text1 = "by specialist info";
			$heading2 = "specialist id:";
			$text2 = "$specialistid";
			$savename="photos of specialistid $specialistid from photolog";
			$norecordtext="ERROR!!!<br><br> No photos of this specialist id exist in database!";
		}
		
		break;


////////// CASE PHOTOLOG FOR AREA DEFINITION

		case "dsrphotolog":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "photologsquares.squarename='".$squarename[$i]."'";
			}
			$sqlsquares = "AND (".implode(" OR ", $squarename).")";
			$wheresquares = "AND photologsquares.valid=true";
		}

		if ($countsupervisors>0)
		{
			$supervisor = explode("<br>or ", $listsupervisors);
			for ($i=0; $i<$countsupervisors; $i++)
			{
				$supervisor[$i] = "photolog.photographer='".$supervisor[$i]."'";
			}
			$sqlsupervisors = "AND (".implode(" OR ", $supervisor).")";
		}
		
		if ($area!='')
		{
			$sqlarea = "AND photologareas.area='$area'";
			$wherearea = "AND photologareas.valid=true";
		}


		$query = "select distinct photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\",
						photolog.imagenumber, photolog.cdnumber
						from (fielddata.photolog left join fielddata.photologsquares on photolog.photoid = photologsquares.photoid) left join fielddata.photologareas on photolog.photoid = photologareas.photoid
						WHERE photolog.valid=true $wherearea $wheresquares
						$sqlarea $sqlsquares $sqlsupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "photolog";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records photolog from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No photo for this query exist in database!";
		

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 12;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 12;
		$outputcolumn[2]= 9;
		$outputcolumn[3]= 10;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;
		$outputcolumn[8]= 6;
		$outputcolumn[9]= 11;
		$outputcolumn[10]= 13;
		$outputcolumn[11]= 14;

		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>