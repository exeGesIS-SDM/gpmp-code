<?php

# switch sorting AND freetext searching options off (remove sorting bar in output)

	$nosortingoptions='yes';
	$nosearchoptions='yes';	
			
switch ($submenuaction)
	{
		case "":
		break;


////////// CASE CHECK FOR CHANGES

		case "checkforchanges":

		for ($i=1; $i<=count($rawtablelink); $i++)
		{
			$stat = pg_exec($dbh, "SELECT MAX(tstamp::date) FROM fielddata.".$rawtablelink[$i]." WHERE ".$rawtablelink[$i].".valid=true;");
			$data = pg_fetch_row($stat, 0);
			$tablechanged[$i]=$data[0];
		}

		
		echo'<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#000000">
		<TR><TD width="100%" height="100%" valign="top">';

		echo"<p class='dataentryheading'>
			changes of gpmp excavation database raw tables</p>

			<table width='45%'><tr>
			<td class='largetext' colspan='2'>
			the following dates indicate when the latest modifications where carried out (this does not apply to deletions).
			</td></tr>
			<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";

		for ($i=1; $i<=count($rawtablelink); $i++)
		{
			echo "<tr'><td bgcolor='#333333' class='largetext' width='75%'>".$rawtablename[$i].":</td>
				<td class='largetext' width=25% bgcolor='#1A1F2D' align='center'>".$tablechanged[$i]."</td></tr>";
	
			echo "<tr><td class='emptyline' height='5' colspan='2'>&nbsp;</td></tr>";
		}
		die;
		
		break;
		

////////// CASE DIRECT DOWNLOAD

		case "directdownload":

		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

		echo'
		  <table width="164" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  raw tables direct download</p></td>
		    </tr>';

   		$fullscreenlink = "component$menuaction.php";
				
		for	($i=1; $i<=count($rawtablename); $i++)
		{
			echo'
			<tr> 
			     <td width="14">&nbsp;</td>
			     <td width="140"><a class="menulink" href="'.$fullscreenlink.'?saveastxt=yes&nosessionvariables=yes&indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$rawtablelink[$i].'">
				 '.$rawtablename[$i].'</a></td>
			</tr>';
		}

		echo '</table>';
		die;
		break;


////////// CASE VIEW RAW TABLE BAGREGISTER

		case "bagregister":

		$query = "select bagregister.bagregisterid, bagregister.bagprefix, bagregister.bagnumber, bagregister.featurenumber, bagregister.date, bagregister.bagtype, bagregister.comments, bagregister.category
					FROM fielddata.bagregister
					WHERE bagregister.valid=true
					ORDER BY bagregister.bagregisterid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		
		$pageidentifiername = "bagregisterid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "bagregister";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table bagregister";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




////////// CASE VIEW RAW TABLE BAGREGISTERSQUARES

		case "bagregistersquares":

		$query = "select bagregistersquares.bagregisterid, bagregistersquares.squarename
					FROM fielddata.bagregistersquares
					WHERE bagregistersquares.valid=true
					ORDER BY bagregistersquares.bagregisterid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "bagregisterid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "bagregistersquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table bagregistersquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE BROADAREAS

		case "broadareas":

		$query = "select broadareas.broadareaid, broadareas.broadareacode, broadareas.broadareaname
					FROM fielddata.broadareas
					WHERE broadareas.valid=true
					ORDER BY broadareas.broadareaid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "broadareaid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "broadareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table broadareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE BROADAREASLOCALAREAS

		case "broadareaslocalareas":

		$query = "select broadareaslocalareas.broadareaid, broadareaslocalareas.localareacode
					FROM fielddata.broadareaslocalareas
					WHERE broadareaslocalareas.valid=true
					ORDER BY broadareaslocalareas.broadareaid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "broadareaid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "broadareaslocalareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table broadareaslocalareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;
	
		
////////// CASE VIEW RAW TABLE BURIAL FEATURES

		case "burialfeatures":

		$query = "select burialfeatures.burialnumber, burialfeatures.featurenumber, burialfeatures.burialtype
					FROM fielddata.burialfeatures
					WHERE burialfeatures.valid=true
					ORDER BY burialfeatures.burialnumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "burialnumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "burialfeatures";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table burialfeatures";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE CDINVENTORY

		case "cdinventory":

		$query = "select cdinventory.cdid, cdinventory.storagemedium, cdinventory.number, cdinventory.contents, cdinventory.giza, cdinventory.boston, cdinventory.newyork
					FROM fielddata.cdinventory
					WHERE cdinventory.valid=true
					ORDER BY cdinventory.cdid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		
		$pageidentifiername = "cdid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "cdinventory";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table cdinventory";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE DRAWINGLOG

		case "drawinglog":

		$query = "select drawinglog.drawingid, drawinglog.season, drawinglog.drawingnumber, drawinglog.area, drawinglog.date, drawinglog.drawinglabel, drawinglog.scale,
					drawinglog.checked, drawinglog.cd, drawinglog.drawingtype, drawinglog.portfolionumber, drawinglog.locationoriginal,
					drawinglog.copied, drawinglog.scanned, drawinglog.cropped, drawinglog.renamed, drawinglog.burnttocd, drawinglog.scanuploaded,
					drawinglog.drawingsenttoboston
					FROM fielddata.drawinglog
					WHERE drawinglog.valid=true
					ORDER BY drawinglog.drawingid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 18;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		$outputcolumn[8]= 8;
		$outputcolumn[9]= 9;
		$outputcolumn[10]= 10;
		$outputcolumn[11]= 11;
		$outputcolumn[12]= 12;
		$outputcolumn[13]= 13;
		$outputcolumn[14]= 14;
		$outputcolumn[15]= 15;
		$outputcolumn[16]= 16;
		$outputcolumn[17]= 17;
				
		$pageidentifiername = "drawingid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "drawinglog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table drawinglog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;

		

////////// CASE VIEW RAW TABLE DRAWINGLOGFEATURES

		case "drawinglogfeatures":

		$query = "select drawinglogfeatures.drawingid, drawinglogfeatures.featurenumber
					FROM fielddata.drawinglogfeatures
					WHERE drawinglogfeatures.valid=true
					ORDER BY drawinglogfeatures.drawingid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "drawingid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "drawinglogfeatures";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table drawinglogfeatures";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE DRAWINGLOGSQUARES

		case "drawinglogsquares":

		$query = "select drawinglogsquares.drawingid, drawinglogsquares.squarename
					FROM fielddata.drawinglogsquares
					WHERE drawinglogsquares.valid=true
					ORDER BY drawinglogsquares.drawingid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "drawingid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "drawinglogsquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table drawinglogsquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE DRAWINGLOGSUPERVISORS

		case "drawinglogsupervisors":

		$query = "select drawinglogsupervisors.drawingid, drawinglogsupervisors.supervisor
					FROM fielddata.drawinglogsupervisors
					WHERE drawinglogsupervisors.valid=true
					ORDER BY drawinglogsupervisors.drawingid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "drawingid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "drawinglogsupervisors";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table drawinglogsupervisors";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE ENTITYLOG

		case "entitylog":

		$query = "select entitylog.entitynumber, entitylog.entitytype, entitylog.entityname, entitylog.excavationarea, entitylog.date, entitylog.supervisor, entitylog.description
					FROM fielddata.entitylog
					WHERE entitylog.valid=true
					ORDER BY entitylog.entitynumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		
		$pageidentifiername = "entitynumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "entitylog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table entitylog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE ENTITYLOGCHANGES

		case "entitylogchanges":

		$query = "select entitylogchanges.entitynumber, entitylogchanges.date, entitylogchanges.supervisor, entitylogchanges.description
					FROM fielddata.entitylogchanges
					WHERE entitylogchanges.valid=true
					ORDER BY entitylogchanges.entitynumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 4;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		
		$pageidentifiername = "entitynumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "entitylogchanges";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table entitylogchanges";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE ENTITYLOGDEFINEDBYFEATURENUMBERS

		case "entitylogdefinedbyfeaturenumbers":

		$query = "select entitylogdefinedbyfeaturenumbers.entitynumber, entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber
					FROM fielddata.entitylogdefinedbyfeaturenumbers
					WHERE entitylogdefinedbyfeaturenumbers.valid=true
					ORDER BY entitylogdefinedbyfeaturenumbers.entitynumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "entitynumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "entitylogdefinedbyfeaturenumbers";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table entitylogdefinedbyfeaturenumbers";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE ENTITYLOGINCLUDESENTITYNUMBERS

		case "entitylogincludesentitynumbers":

		$query = "select entitylogincludesentitynumbers.entitynumber, entitylogincludesentitynumbers.inclentitynumber
					FROM fielddata.entitylogincludesentitynumbers
					WHERE entitylogincludesentitynumbers.valid=true
					ORDER BY entitylogincludesentitynumbers.entitynumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "entitynumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "entitylogincludesentitynumbers";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table entitylogincludesentitynumbers";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE ENTITYLOGINCLUDESFEATURENUMBERS

		case "entitylogincludesfeaturenumbers":

		$query = "select entitylogincludesfeaturenumbers.entitynumber, entitylogincludesfeaturenumbers.inclfeaturenumber
					FROM fielddata.entitylogincludesfeaturenumbers
					WHERE entitylogincludesfeaturenumbers.valid=true
					ORDER BY entitylogincludesfeaturenumbers.entitynumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "entitynumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "entitylogincludesfeaturenumbers";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table entitylogincludesfeaturenumbers";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE EXOTICMATERIALREGISTER

		case "exoticmaterialregister":

		$query = "select exoticmaterialregister.exoticmaterialregisterid, exoticmaterialregister.featurenumber, exoticmaterialregister.date, exoticmaterialregister.materialtype, exoticmaterialregister.count, exoticmaterialregister.weightprefix, exoticmaterialregister.weight, exoticmaterialregister.comments, exoticmaterialregister.materialcategory
					FROM fielddata.exoticmaterialregister
					WHERE exoticmaterialregister.valid=true
					ORDER BY exoticmaterialregister.exoticmaterialregisterid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 9;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		$outputcolumn[8]= 8;
		
		$pageidentifiername = "exoticmaterialregisterid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "exoticmaterialregister";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table exoticmaterialregister";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE EXOTICMATERIALREGISTERSQUARES

		case "exoticmaterialregistersquares":

		$query = "select exoticmaterialregistersquares.exoticmaterialregisterid, exoticmaterialregistersquares.squarename
					FROM fielddata.exoticmaterialregistersquares
					WHERE exoticmaterialregistersquares.valid=true
					ORDER BY exoticmaterialregistersquares.exoticmaterialregisterid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "exoticmaterialregisterid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "exoticmaterialregistersquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table exoticmaterialregistersquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE FEATURELOG

		case "featurelog":

		$query = "select featurelog.featurenumber, featurelog.date, featurelog.description
					FROM fielddata.featurelog
					WHERE featurelog.valid=true
					ORDER BY featurelog.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "featurelog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table featurelog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE FEATURELOGAREAS

		case "featurelogareas":

		$query = "select featurelogareas.featurenumber, featurelogareas.area
					FROM fielddata.featurelogareas
					WHERE featurelogareas.valid=true
					ORDER BY featurelogareas.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "featurelogareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table featurelogareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE FEATURELOGSQUARES

		case "featurelogsquares":

		$query = "select featurelogsquares.featurenumber, featurelogsquares.squarename
					FROM fielddata.featurelogsquares
					WHERE featurelogsquares.valid=true
					ORDER BY featurelogsquares.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "featurelogsquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table featurelogsquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE FEATURELOGSUPERVISORS

		case "featurelogsupervisors":

		$query = "select featurelogsupervisors.featurenumber, featurelogsupervisors.supervisor
					FROM fielddata.featurelogsupervisors
					WHERE featurelogsupervisors.valid=true
					ORDER BY featurelogsupervisors.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "featurelogsupervisors";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table featurelogsupervisors";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE LOCALAREAS

		case "localareas":

		$query = "select localareas.localareaid, localareas.localareacode, localareas.localareaname
					FROM fielddata.localareas
					WHERE localareas.valid=true
					ORDER BY localareas.localareaid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "localareaid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "localareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table localareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;
		


////////// CASE VIEW RAW TABLE LOCALAREASEXCAVATORS

		case "localareasexcavators":

		$query = "select localareasexcavators.localareaid, localareasexcavators.supervisor
					FROM fielddata.localareasexcavators
					WHERE localareasexcavators.valid=true
					ORDER BY localareasexcavators.localareaid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "localareaid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "localareasexcavators";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table localareasexcavators";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;	
		

////////// CASE VIEW RAW TABLE LOCALAREASSQUARES

		case "localareassquares":

		$query = "select localareassquares.localareaid, localareassquares.squarename
					FROM fielddata.localareassquares
					WHERE localareassquares.valid=true
					ORDER BY localareassquares.localareaid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "localareaid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "localareassquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table localareassquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;	

		
////////// CASE VIEW RAW TABLE NOTEBOOKSCATALOG

		case "notebookscatalog":

		$query = "select notebookscatalog.notebookid, notebookscatalog.notebookname, notebookscatalog.datestarted, notebookscatalog.datecompleted, notebookscatalog.cdlocation, notebookscatalog.arearecordbinderlocation, notebookscatalog.comments, notebookscatalog.bindertype
					FROM fielddata.notebookscatalog
					WHERE notebookscatalog.valid=true
					ORDER BY notebookscatalog.notebookid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		
		$pageidentifiername = "notebookid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "notebookscatalog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table notebookscatalog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE NOTEBOOKSCATALOGAREAS

		case "notebookscatalogareas":

		$query = "select notebookscatalogareas.notebookid, notebookscatalogareas.area
					FROM fielddata.notebookscatalogareas
					WHERE notebookscatalogareas.valid=true
					ORDER BY notebookscatalogareas.notebookid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "notebookid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "notebookscatalogareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table notebookscatalogareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE NOTEBOOKSCATALOGSQUARES

		case "notebookscatalogsquares":

		$query = "select notebookscatalogsquares.notebookid, notebookscatalogsquares.squarename
					FROM fielddata.notebookscatalogsquares
					WHERE notebookscatalogsquares.valid=true
					ORDER BY notebookscatalogsquares.notebookid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "notebookid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "notebookscatalogsquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table notebookscatalogsquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




////////// CASE VIEW RAW TABLE NOTEBOOKSCATALOGSUPERVISORS

		case "notebookscatalogsupervisors":

		$query = "select notebookscatalogsupervisors.notebookid, notebookscatalogsupervisors.supervisor
					FROM fielddata.notebookscatalogsupervisors
					WHERE notebookscatalogsupervisors.valid=true
					ORDER BY notebookscatalogsupervisors.notebookid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "notebookid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "notebookscatalogsupervisors";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table notebookscatalogsupervisors";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE PHOTOLOG

		case "photolog":

		$query = "select photolog.photoid, photolog.date, photolog.facing, photolog.description, photolog.imagenumber, photolog.cdnumber, photolog.photographer
					FROM fielddata.photolog
					WHERE photolog.valid=true
					ORDER BY photolog.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photolog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photolog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE PHOTOLOGFEATURES

		case "photologfeatures":

		$query = "select photologfeatures.photoid, photologfeatures.featurenumber
					FROM fielddata.photologfeatures
					WHERE photologfeatures.valid=true
					ORDER BY photologfeatures.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photologfeatures";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photologfeatures";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


////////// CASE VIEW RAW TABLE PHOTOLOGINDEX

		case "photologindex":

		$query = "select photologindex.photoid, photologindex.indexcode
					FROM fielddata.photologindex
					WHERE photologindex.valid=true
					ORDER BY photologindex.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photologindex";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photologindex";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;
		

////////// CASE VIEW RAW TABLE PHOTOLOGSEPCIALISTS

		case "photologspecialists":

		$query = "select photologspecialists.photoid, photologspecialists.specialistcategory, photologspecialists.specialistid
					FROM fielddata.photologspecialists
					WHERE photologspecialists.valid=true
					ORDER BY photologspecialists.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photologspecialists";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photologspecialists";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE PHOTOLOGSQUARES

		case "photologsquares":

		$query = "select photologsquares.photoid, photologsquares.squarename
					FROM fielddata.photologsquares
					WHERE photologsquares.valid=true
					ORDER BY photologsquares.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photologsquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photologsquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;


		
////////// CASE VIEW RAW TABLE PHOTOLOGAREAS

		case "photologareas":

		$query = "select photologareas.photoid, photologareas.area
					FROM fielddata.photologareas
					WHERE photologareas.valid=true
					ORDER BY photologareas.photoid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "photoid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "photologareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table photologareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;

		

////////// CASE VIEW RAW TABLE REASSIGNEDFEATURES

		case "reassignedfeatures":

		$query = "select reassignedfeatures.featurenumber, reassignedfeatures.oldfeaturenumber, reassignedfeatures.olddate
					FROM fielddata.reassignedfeatures
					WHERE reassignedfeatures.valid=true
					ORDER BY reassignedfeatures.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "reassignedfeatures";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table reassignedfeatures";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




////////// CASE VIEW RAW TABLE REPORTSCATALOG

		case "reportscatalog":

		$query = "select reportscatalog.reportid, reportscatalog.reportname, reportscatalog.date, reportscatalog.reporttype, reportscatalog.comments, reportscatalog.cd
					FROM fielddata.reportscatalog
					WHERE reportscatalog.valid=true
					ORDER BY reportscatalog.reportid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		
		$pageidentifiername = "reportid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "reportscatalog";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table reportscatalog";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE REPORTSCATALOGAREAS

		case "reportscatalogareas":

		$query = "select reportscatalogareas.reportid, reportscatalogareas.area
					FROM fielddata.reportscatalogareas
					WHERE reportscatalogareas.valid=true
					ORDER BY reportscatalogareas.reportid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "reportid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "reportscatalogareas";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table reportscatalogareas";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;



////////// CASE VIEW RAW TABLE REPORTSCATALOGSQUARES

		case "reportscatalogsquares":

		$query = "select reportscatalogsquares.reportid, reportscatalogsquares.squarename
					FROM fielddata.reportscatalogsquares
					WHERE reportscatalogsquares.valid=true
					ORDER BY reportscatalogsquares.reportid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "reportid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "reportscatalogsquares";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table reportscatalogsquares";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




////////// CASE VIEW RAW TABLE REPORTSCATALOGAUTHORS

		case "reportscatalogauthors":

		$query = "select reportscatalogauthors.reportid, reportscatalogauthors.author
					FROM fielddata.reportscatalogauthors
					WHERE reportscatalogauthors.valid=true
					ORDER BY reportscatalogauthors.reportid;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		
		$pageidentifiername = "reportid";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "reportscatalogauthors";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table reportscatalogauthors";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




///////// CASE VIEW RAW TABLE SAMPLEREGISTER

		case "sampleregister":

		$query = "select sampleregister.sampleprefix, sampleregister.samplenumber, sampleregister.date, sampleregister.sampletype, sampleregister.featurenumber, sampleregister.bagnumber, sampleregister.comments
					FROM fielddata.sampleregister
					WHERE sampleregister.valid=true
					ORDER BY sampleregister.samplenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		
		$pageidentifiername = "samplenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "sampleregister";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table sampleregister";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;




///////// CASE VIEW RAW TABLE SYNOPTICFEATUREFORM

		case "synopticfeatureform":

		$query = "select synopticfeatureform.featurenumber, synopticfeatureform.phase, synopticfeatureform.matrixgroupnumber, synopticfeatureform.featuretype, synopticfeatureform.int_ext, synopticfeatureform.contaminated, synopticfeatureform.insitu, synopticfeatureform.fullyexcavated, synopticfeatureform.entrycomplete
					FROM fielddata.synopticfeatureform
					WHERE synopticfeatureform.valid=true
					ORDER BY synopticfeatureform.featurenumber;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 9;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		$outputcolumn[8]= 8;
		
		$pageidentifiername = "featurenumber";

		$title = "browse raw tables";
		$heading1 = "option:";
		$text1 = "synopticfeatureform";
		$heading2 = "format:";
		$text2 = "raw";
		$savename="raw table synopticfeatureform";
		$norecordtext="ERROR!!!<br><br> No raw rows exist in database!";
		
		break;
	}


if ($submenuaction!='')
{
	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	else
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>