<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd
			from fielddata.reportscatalog where reportscatalog.valid=true";


		$filedownloadheader="downloadable file";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/reports";
		$filedownloadextensions=array("rtf", "pdf", "xls", "doc");
		$filedownloadcolumn=1;


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 6;
		$outputcolumn[2]= 7;
		$outputcolumn[3]= 8;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;

		$keynumberofcolumns = 3;
		$keycolumn[1] = 0;
		$keycolumn[2] = 0;
		$keycolumn[3] = 0;
		$keyquery[1] = "SELECT reportscatalogareas.area AS \"area(s)\" FROM fielddata.reportscatalogareas WHERE reportscatalogareas.valid=true";
		$keyquery[2] = "SELECT reportscatalogsquares.squarename AS \"square(s)\" FROM fielddata.reportscatalogsquares WHERE reportscatalogsquares.valid=true";
		$keyquery[3] = "SELECT reportscatalogauthors.author AS \"author(s)\" FROM fielddata.reportscatalogauthors WHERE reportscatalogauthors.valid=true";
		$keysort[1] = "reportscatalogareas.area";
		$keysort[2] = "reportscatalogsquares.squarename";
		$keysort[3] = "reportscatalogauthors.author";


# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';



switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompletelog":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse reportscatalog";
		$heading1 = "option:";
		$text1 = "complete catalog";
		$heading2 = "reports:";
		$text2 = "all";
		$savename="complete reportscatalog";
		$norecordtext="ERROR!!!<br><br> No reports exist in database!";

		break;



////////// CASE BY AUTHOR

		case "browsebyauthor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "listexcavators.fullnames = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor =	"listexcavators.fullnames = '$author'";
			$headingstring = $author;
		}

		$query = "select distinct reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd
				from (fielddata.reportscatalog left join fielddata.reportscatalogauthors on reportscatalog.reportid = reportscatalogauthors.reportid) left join fielddata.listexcavators on reportscatalogauthors.author = listexcavators.initials
				where ($where_supervisor) and reportscatalog.valid=true and reportscatalogauthors.valid=true and listexcavators.valid=true
				$searchsql
				ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&author=$author&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse reports catalog";
		$heading1 = "option:";
		$text1 = "by author";
		$heading2 = "author(s):";
		$text2 = $headingstring;
		$savename="reports from author(s) $headingstring from reports catalog";
		$norecordtext="ERROR!!!<br><br> No reports exist for this author in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "reportscatalogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"reportscatalogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd
				from fielddata.reportscatalog inner join fielddata.reportscatalogsquares on reportscatalog.reportid = reportscatalogsquares.reportid
				where ($where_square) and reportscatalog.valid=true and reportscatalogsquares.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse reports catalog";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="reports from square(s) $headingstring from reports catalog";
		$norecordtext="ERROR!!!<br><br> No reports exist for this square in database!";

		break;


////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "reportscatalogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"reportscatalogareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd
				from fielddata.reportscatalog inner join fielddata.reportscatalogareas on reportscatalog.reportid = reportscatalogareas.reportid
				where ($where_area) and reportscatalog.valid=true and reportscatalogareas.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse reports catalog";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="reports from area(s) $headingstring from reports catalog";
		$norecordtext="ERROR!!!<br><br> No reports exist for this area in database!";

		break;



////////// CASE REPORTS FOR AREA DEFINITION

		case "dsrreportscatalog":

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "reportscatalogsquares.squarename='".$squarename[$i]."'";
			}
			$sqlsquares = "AND (".implode(" OR ", $squarename).")";
			$wheresquares = "AND reportscatalogsquares.valid=true";
		}

		if ($countsupervisors>0)
		{
			$supervisor = explode("<br>or ", $listsupervisors);
			for ($i=0; $i<$countsupervisors; $i++)
			{
				$supervisor[$i] = "reportscatalogauthors.author='".$supervisor[$i]."'";
			}
			$sqlsupervisors = "AND (".implode(" OR ", $supervisor).")";
			$wheresupervisors = "AND reportscatalogauthors.valid=true";
		}

		if ($area!='')
		{
			$sqlarea = "AND reportscatalogareas.area='$area'";
			$wherearea = "AND reportscatalogareas.valid=true";
		}


		$query = "select distinct reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd,
						reportscatalog.reportname, reportscatalog.reporttype
						from ((fielddata.reportscatalog left join fielddata.reportscatalogsquares on reportscatalog.reportid = reportscatalogsquares.reportid) left join fielddata.reportscatalogauthors on reportscatalog.reportid = reportscatalogauthors.reportid) left join fielddata.reportscatalogareas on reportscatalog.reportid = reportscatalogareas.reportid
						WHERE reportscatalog.valid=true $wherearea $wheresquares $wheresupervisors
						$sqlarea $sqlsquares $sqlsupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "reports";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records reportscatalog from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No report for this query exist in database!";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 8;
		$outputcolumn[2]= 9;
		$outputcolumn[3]= 10;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 4;
		$outputcolumn[7]= 5;
		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>