<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";

  
  
////////// GENERAL VARIABLES

		$superquery = "select (CASE WHEN sampleregister.sampleprefix IS NULL THEN '' WHEN sampleregister.sampleprefix IS NOT NULL THEN sampleregister.sampleprefix END) || '-' || (CASE WHEN sampleregister.samplenumber IS NULL THEN '0' WHEN sampleregister.samplenumber IS NOT NULL THEN sampleregister.samplenumber END) AS \"sample number\", sampleregister.featurenumber AS \"feature\", sampleregister.bagnumber AS \"bag\", sampleregister.date, sampleregister.sampletype AS \"type\", sampleregister.comments from fielddata.sampleregister WHERE sampleregister.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		

# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE REGISTER

		case "browsecompleteregister":

		$query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse sample register";
		$heading1 = "option:";
		$text1 = "complete register";
		$heading2 = "samples:";
		$text2 = "all";
		$savename="complete sampleregister";
		$norecordtext="ERROR!!!<br><br> No samples exist in database!";

		break;



		
////////// CASE SINGLESAMPLE

		
		case "browsesinglesample":

		if	($featurenumber>0)
			{
				$query = "$superquery AND samplenumber=$samplenumber AND featurenumber=$featurenumber $searchsql ORDER BY $sortsql;";
				$uservariables = "samplenumber=$bagnumber&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse sample register";
				$heading1 = "option:";
				$text1 = "single sample";
				$heading2 = "sample:";
				$text2 = "sample $samplenumber of feature $featurenumber";
				$savename="sample $samplenumber of feature $featurenumber from sampleregister";
				
			}
			else
			{
				if	($year>0)
				{
					$query = "$superquery AND samplenumber=$samplenumber AND date_part('year', date)=$year $searchsql ORDER BY $sortsql;";
					$uservariables = "samplenumber=$samplenumber&year=$year&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse sample register";
					$heading1 = "option:";
					$text1 = "single sample";
					$heading2 = "sample:";
					$text2 = "sample $samplenumber of year $year";
					$savename="sample $samplenumber of year $year from sampleregister";
				}
				else
				{
					$query = "$superquery AND samplenumber=$samplenumber $searchsql ORDER BY $sortsql;";
					$uservariables = "samplenumber=$samplenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse sample register";
					$heading1 = "option:";
					$text1 = "single sample";
					$heading2 = "sample:";
					$text2 = "$samplenumber";
					$savename="sample $samplenumber from sampleregister";
				}
			}

		$norecordtext="ERROR!!!<br><br> Sample does not exist in database!";


		break;
		

////////// CASE BAG SERIES

		case "browsesampleseries":

		if	($featurenumber>0)
			{
				$query = "$superquery AND samplenumber>=$firstsamplenumber AND samplenumber<=$lastsamplenumber AND featurenumber=$featurenumber $searchsql ORDER BY $sortsql;";
				$uservariables = "firstsamplenumber=$firstsamplenumber&lastsamplenumber=$lastsamplenumber&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
				$title = "browse sample register";
				$heading1 = "option:";
				$text1 = "sample series";
				$heading2 = "samples:";
				$text2 = "sample $firstsamplenumber to $lastsamplenumber of feature $featurenumber";
				$savename="sample series $firstsamplenumber-$lastsamplenumber of feature $featurenumber from sampleregister";
				
			}
			else
			{
				if	($year>0)
				{
					$query = "$superquery AND samplenumber>=$firstsamplenumber AND samplenumber<=$lastsamplenumber AND date_part('year', date)=$year $searchsql ORDER BY $sortsql;";
					$uservariables = "firstsamplenumber=$firstsamplenumber&lastsamplenumber=$lastsamplenumber&year=$year&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse sample register";
					$heading1 = "option:";
					$text1 = "sample series";
					$heading2 = "samples:";
					$text2 = "sample $firstsamplenumber to $lastsamplenumber of year $year";
					$savename="sample series $firstsamplenumber-$lastsamplenumber of year $year from sampleregister";
				}
				else
				{
					$query = "$superquery AND samplenumber>=$firstsamplenumber AND samplenumber<=$lastsamplenumber $searchsql ORDER BY $sortsql;";
					$uservariables = "firstsamplenumber=$firstsamplenumber&lastsamplenumber=$lastsamplenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
					$title = "browse sample register";
					$heading1 = "option:";
					$text1 = "sample series";
					$heading2 = "samples:";
					$text2 = "sample $firstsamplenumber to $lastsamplenumber";
					$savename="sample series $firstsamplenumber-$lastsamplenumber from sampleregister";
				}
			}

		$norecordtext="ERROR!!!<br><br> Sample series does not exist in database!";
		

		break;


		
////////// CASE BY FEATURE

		case "browsebyfeature":
		
		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "featurenumber='$filtervalues[$i]'";
			}
			$where_feature = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_feature = "featurenumber='$featurenumber'";
			$headingstring = $featurenumber;
		}

		$query = "$superquery AND ($where_feature) $searchsql ORDER BY $sortsql;";
		$uservariables = "filtervaluesserial=$filtervaluesserial&featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "browse sample register";
		$heading1 = "option:";
		$text1 = "by feature";
		$heading2 = "samples:";
		$text2 = "of feature(s) $headingstring";
		$savename="all samples of feature(s) $headingstring from sampleregister";
		$norecordtext="ERROR!!!<br><br> No samples matching this feature exist in database!";

		break;


////////// CASE SAMPLES FOR AREA DEFINITION

		case "dsrsampleregister":

		$query = "SELECT DISTINCT (CASE WHEN sampleregister.sampleprefix IS NULL THEN '' WHEN sampleregister.sampleprefix IS NOT NULL THEN sampleregister.sampleprefix END) || '-' || (CASE WHEN sampleregister.samplenumber IS NULL THEN '0' WHEN sampleregister.samplenumber IS NOT NULL THEN sampleregister.samplenumber END) AS \"sample number\", sampleregister.featurenumber AS \"feature\", sampleregister.bagnumber AS \"bag\", sampleregister.date, sampleregister.sampletype AS \"type\", sampleregister.comments,
						sampleregister.sampleprefix, sampleregister.samplenumber, sampleregister.featurenumber, sampleregister.sampletype, sampleregister.bagnumber
						FROM ((fielddata.sampleregister left join fielddata.featurelogareas on sampleregister.featurenumber = featurelogareas.featurenumber) left join fielddata.featurelogsquares on sampleregister.featurenumber = featurelogsquares.featurenumber) left join fielddata.featurelogsupervisors on sampleregister.featurenumber = featurelogsupervisors.featurenumber
						WHERE sampleregister.valid=true
						$sqlarea $sqlsquares $sqlsupervisors $wherearea $wheresquares $wheresupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "sampleregister";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records sampleregister from area/squares/supervisors $area / $listsquares / $listsupervisors";
		$norecordtext="ERROR!!!<br><br> No samples for this query exist in database!";
		
		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>