<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select spacelog.spacenumber, spacelog.date, spacelog.description from fielddata.spacelog WHERE spacelog.valid=true";

		$filedownloadheader="pdf space forms";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/spaceforms";
		$filedownloadextension="pdf";
		$filedownloadcolumn=0;

	
		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 4;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 5;
		$outputcolumn[4]= 1;
		$outputcolumn[5]= 2;
		


		
		
# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';


		$keynumberofcolumns = 3;

		$keycolumn[1] = 0;
		$keyquery[1] = "SELECT spacelogsquares.squarename as \"square(s)\" FROM fielddata.spacelogsquares WHERE spacelogsquares.valid=true";
		$keysort[1] = "spacelogsquares.squarename";
		$keycolumn[2] = 0;
		$keyquery[2] = "SELECT spacelogareas.area as \"area(s)\" FROM fielddata.spacelogareas WHERE spacelogareas.valid=true";
		$keysort[2] = "spacelogareas.area";
		$keycolumn[3] = 0;
		$keyquery[3] = "SELECT spacelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.spacelogsupervisors WHERE spacelogsupervisors.valid=true";
		$keysort[3] = "spacelogsupervisors.supervisor";
		

switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE LOG

		case "browsecompletelog":

		echo $query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "spaces:";
		$text2 = "all";
		$savename="complete spacelog";
		$norecordtext="ERROR!!!<br><br> No spaces exist in database!";

		break;




////////// CASE SINGLEspace


		case "browsesinglespace":

		$query = "$superquery AND spacelog.spacenumber=$spacenumber $searchsql;";
		$uservariables = "spacenumber=$spacenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "single space";
		$heading2 = "space:";
		$text2 = "$spacenumber";
		$savename="space $spacenumber from spacelog";
		$norecordtext="ERROR!!!<br><br> space does not exist in database!";

		break;


////////// CASE spaceSERIES

		case "browsespaceseries":

		$query = "$superquery AND spacelog.spacenumber>=$firstspacenumber AND spacelog.spacenumber<=$lastspacenumber $searchsql ORDER BY $sortsql;";
		$uservariables = "firstspacenumber=$firstspacenumber&lastspacenumber=$lastspacenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "space series";
		$heading2 = "spaces:";
		$text2 = "$firstspacenumber - $lastspacenumber";
		$savename="space series $firstspacenumber-$lastspacenumber from spacelog";
		$norecordtext="ERROR!!!<br><br> None of the selected spaces in this series do exist in database!";

		break;



////////// CASE BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "listexcavators.fullnames = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor =	"listexcavators.fullnames = '$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "select distinct spacelog.spacenumber, spacelog.date, spacelog.description
				from (fielddata.spacelog left join fielddata.spacelogsupervisors on spacelog.spacenumber = spacelogsupervisors.spacenumber) left join fielddata.listexcavators on spacelogsupervisors.supervisor = listexcavators.initials
				where ($where_supervisor) and spacelog.valid=true and spacelogsupervisors.valid=true and listexcavators.valid=true
				$searchsql
				ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="spaces from supervisor(s) $headingstring from spacelog";
		$norecordtext="ERROR!!!<br><br> No spaces exist for this supervisor(s) in database!";

		break;



////////// CASE BY DATE


		case "browsebydate":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "spacelog.date = '$filtervalues[$i]'";
			}
			$where_date = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_date =	"spacelog.date = '$date'";
			$headingstring = $date;
		}

		$query = "$superquery AND ($where_date) $searchsql ORDER BY $sortsql";
		$uservariables = "filtervaluesserial=$filtervaluesserial&date=$date&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "by date";
		$heading2 = "date(s):";
		$text2 = $headingstring;
		$savename="spaces from date(s) $headingstring from spacelog";
		$norecordtext="ERROR!!!<br><br> No space exist for this date in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "spacelogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"spacelogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct spacelog.spacenumber, spacelog.date, spacelog.description
				from fielddata.spacelog inner join fielddata.spacelogsquares on spacelog.spacenumber = spacelogsquares.spacenumber
				where ($where_square) and spacelog.valid=true and spacelogsquares.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="spaces from square(s) $headingstring from spacelog";
		$norecordtext="ERROR!!!<br><br> No space exist for this square in database!";

		break;


		////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "spacelogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"spacelogareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct spacelog.spacenumber, spacelog.date, spacelog.description
				from fielddata.spacelog inner join fielddata.spacelogareas on spacelog.spacenumber = spacelogareas.spacenumber
				where ($where_area) and spacelog.valid=true and spacelogareas.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse space log";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="spaces from area(s) $headingstring from spacelog";
		$norecordtext="ERROR!!!<br><br> No space exist for this area in database!";

		break;


////////// CASE spaceLOG FOR AREA DEFINITION

		case "dsrspacelog":

		$query = "select distinct spacelog.spacenumber, spacelog.date, spacelog.description
						from ((fielddata.spacelog left join fielddata.spacelogareas on spacelog.spacenumber = spacelogareas.spacenumber) left join fielddata.spacelogsquares on spacelog.spacenumber = spacelogsquares.spacenumber) left join fielddata.spacelogsupervisors on spacelog.spacenumber = spacelogsupervisors.spacenumber
						WHERE spacelog.valid=true
						$sqlarea $sqlsquares $sqlsupervisors
						$wherearea $wheresquares $wheresupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "spacelog";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records spacelog from area/squares/supervisors";
		$norecordtext="ERROR!!!<br><br> No spaces for this query exist in database!";

		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>