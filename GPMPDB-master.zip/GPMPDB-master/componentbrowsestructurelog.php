<?php

# evaluate freetext filter values
  include "moduleevaluatefreetextvalues.php";


////////// GENERAL VARIABLES

		$superquery = "select structurelog.structurenumber, structurelog.date, structurelog.description from fielddata.structurelog WHERE structurelog.valid=true";

		$filedownloadheader="pdf structure forms";
		$filedownloadlink="http://gpmpfiles.esdm.co.uk/structureforms";
		$filedownloadextension="pdf";
		$filedownloadcolumn=0;

	
		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 4;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 5;
		$outputcolumn[4]= 1;
		$outputcolumn[5]= 2;
		


		
		
# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';


		$keynumberofcolumns = 3;

		$keycolumn[1] = 0;
		$keyquery[1] = "SELECT structurelogsquares.squarename as \"square(s)\" FROM fielddata.structurelogsquares WHERE structurelogsquares.valid=true";
		$keysort[1] = "structurelogsquares.squarename";
		$keycolumn[2] = 0;
		$keyquery[2] = "SELECT structurelogareas.area as \"area(s)\" FROM fielddata.structurelogareas WHERE structurelogareas.valid=true";
		$keysort[2] = "structurelogareas.area";
		$keycolumn[3] = 0;
		$keyquery[3] = "SELECT structurelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.structurelogsupervisors WHERE structurelogsupervisors.valid=true";
		$keysort[3] = "structurelogsupervisors.supervisor";
		

switch ($submenuaction)
	{
		case "":
		break;


////////// CASE COMPLETE LOG

		case "browsecompletelog":

		echo $query = "$superquery $searchsql ORDER BY $sortsql;";
		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "complete log";
		$heading2 = "structures:";
		$text2 = "all";
		$savename="complete structurelog";
		$norecordtext="ERROR!!!<br><br> No structures exist in database!";

		break;




////////// CASE SINGLEstructure


		case "browsesinglestructure":

		$query = "$superquery AND structurelog.structurenumber=$structurenumber $searchsql;";
		$uservariables = "structurenumber=$structurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "single structure";
		$heading2 = "structure:";
		$text2 = "$structurenumber";
		$savename="structure $structurenumber from structurelog";
		$norecordtext="ERROR!!!<br><br> structure does not exist in database!";

		break;


////////// CASE structureSERIES

		case "browsestructureseries":

		$query = "$superquery AND structurelog.structurenumber>=$firststructurenumber AND structurelog.structurenumber<=$laststructurenumber $searchsql ORDER BY $sortsql;";
		$uservariables = "firststructurenumber=$firststructurenumber&laststructurenumber=$laststructurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "structure series";
		$heading2 = "structures:";
		$text2 = "$firststructurenumber - $laststructurenumber";
		$savename="structure series $firststructurenumber-$laststructurenumber from structurelog";
		$norecordtext="ERROR!!!<br><br> None of the selected structures in this series do exist in database!";

		break;



////////// CASE BY SUPERVISOR

		case "browsebysupervisor":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "listexcavators.fullnames = '$filtervalues[$i]'";
			}
			$where_supervisor = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_supervisor =	"listexcavators.fullnames = '$supervisor'";
			$headingstring = $supervisor;
		}

		$query = "select distinct structurelog.structurenumber, structurelog.date, structurelog.description
				from (fielddata.structurelog left join fielddata.structurelogsupervisors on structurelog.structurenumber = structurelogsupervisors.structurenumber) left join fielddata.listexcavators on structurelogsupervisors.supervisor = listexcavators.initials
				where ($where_supervisor) and structurelog.valid=true and structurelogsupervisors.valid=true and listexcavators.valid=true
				$searchsql
				ORDER BY $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&supervisor=$supervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "by supervisor";
		$heading2 = "supervisor(s):";
		$text2 = $headingstring;
		$savename="structures from supervisor(s) $headingstring from structurelog";
		$norecordtext="ERROR!!!<br><br> No structures exist for this supervisor(s) in database!";

		break;



////////// CASE BY DATE


		case "browsebydate":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "structurelog.date = '$filtervalues[$i]'";
			}
			$where_date = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_date =	"structurelog.date = '$date'";
			$headingstring = $date;
		}

		$query = "$superquery AND ($where_date) $searchsql ORDER BY $sortsql";
		$uservariables = "filtervaluesserial=$filtervaluesserial&date=$date&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "by date";
		$heading2 = "date(s):";
		$text2 = $headingstring;
		$savename="structures from date(s) $headingstring from structurelog";
		$norecordtext="ERROR!!!<br><br> No structure exist for this date in database!";

		break;



////////// CASE BY SQUARE

		case "browsebysquare":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "structurelogsquares.squarename='$filtervalues[$i]'";
			}
			$where_square = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_square =	"structurelogsquares.squarename='$squarename'";
			$headingstring = $squarename;
		}

		$query = "select distinct structurelog.structurenumber, structurelog.date, structurelog.description
				from fielddata.structurelog inner join fielddata.structurelogsquares on structurelog.structurenumber = structurelogsquares.structurenumber
				where ($where_square) and structurelog.valid=true and structurelogsquares.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square(s):";
		$text2 = $headingstring;
		$savename="structures from square(s) $headingstring from structurelog";
		$norecordtext="ERROR!!!<br><br> No structure exist for this square in database!";

		break;


		////////// CASE BY AREA

		case "browsebyarea":

		if ($filtervaluesserial != '')
		{
			$filtervalues = explode(", ", $filtervaluesserial);
			for ($i=0; $i<count($filtervalues); $i++)
			{
				$filtervalues[$i] = "structurelogareas.area='$filtervalues[$i]'";
			}
			$where_area = implode(" OR ", $filtervalues);
			$headingstring = $filtervaluesserial;
		}
		else
		{
			$where_area =	"structurelogareas.area='$area'";
			$headingstring = $area;
		}

		$query = "select distinct structurelog.structurenumber, structurelog.date, structurelog.description
				from fielddata.structurelog inner join fielddata.structurelogareas on structurelog.structurenumber = structurelogareas.structurenumber
				where ($where_area) and structurelog.valid=true and structurelogareas.valid=true
				$searchsql
				order by $sortsql;";

		$uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse structure log";
		$heading1 = "option:";
		$text1 = "by area";
		$heading2 = "area(s):";
		$text2 = $headingstring;
		$savename="structures from area(s) $headingstring from structurelog";
		$norecordtext="ERROR!!!<br><br> No structure exist for this area in database!";

		break;


////////// CASE structureLOG FOR AREA DEFINITION

		case "dsrstructurelog":

		$query = "select distinct structurelog.structurenumber, structurelog.date, structurelog.description
						from ((fielddata.structurelog left join fielddata.structurelogareas on structurelog.structurenumber = structurelogareas.structurenumber) left join fielddata.structurelogsquares on structurelog.structurenumber = structurelogsquares.structurenumber) left join fielddata.structurelogsupervisors on structurelog.structurenumber = structurelogsupervisors.structurenumber
						WHERE structurelog.valid=true
						$sqlarea $sqlsquares $sqlsupervisors
						$wherearea $wheresquares $wheresupervisors
						$searchsql
						ORDER BY $sortsql;";

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "compiled area records";
		$heading1 = "option:";
		$text1 = "structurelog";
		$heading2 = "area / squares / supervisors:";
		$text2 = "$area / $listsquares / $listsupervisors";
		$savename="compiled area records structurelog from area/squares/supervisors";
		$norecordtext="ERROR!!!<br><br> No structures for this query exist in database!";

		break;
	}



if ($submenuaction!='')
{
	# create appropriate save name if freetext search was performed
	if ($searchcolumn!='' and $searchkeywords!='')
	{
		$savename = "!filtered! $savename";
	}

	if ($saveastxt=='yes')
	{
		include 'modulesavequeryastxt.php';
	}
	elseif ($dsrdatacheck!='yes')
	{
		include 'modulebrowsequeryresults.php';
	}
}
?>