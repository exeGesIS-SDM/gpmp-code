<?php

# evaluate freetext filter values
include "moduleevaluatefreetextvalues.php";


/*
  How to change to output data for view.
  1. define sql what you need.
  2. map columns. left number is table series. right number is sql result series.
  3. sub query need key($keycolumn) that specify sql index.
  4. main result is appended sub results.
  5. specify some variables. $outputcolumns is all output count. $keynumberofcolumns is sub query count.
 */
////////// GENERAL VARIABLES

$superquery = <<<SQL_END
SELECT
  synopticfeatureform.featurenumber AS feature,
--  '' as "identical to", -- feature is related --new
--  '' as "area",
--  '' as "square",
  synopticfeatureform.featurecategory as "D/C/A/F", --new
  synopticfeatureform.featuretype as "feature type",
  synopticfeatureform.matrixgroupnumber as "matrix group number",
  synopticfeatureform.groupnumberclosed as "group number closed", --new
--  , -- phase
  synopticfeatureform.roomdesignations as "room designations",
  synopticfeatureform.spacenumber as "space number", --new
  synopticfeatureform.structurenumber as "structure number", --new
  synopticfeatureform.extendedfeaturedescription as "extended feature description", --new
  synopticfeatureform.orientation as "orientation", --new
  synopticfeatureform.maxlengthqualifier || maxlength as "max length (m)", --new
  synopticfeatureform.maxwidthqualifier || maxwidth as "max width (m)", --new
  synopticfeatureform.maxvdqualifier || synopticfeatureform.maxvd as "max vd (m)", --new
  synopticfeatureform.fullextentvisibleinplan as "full extend visible in plan?", --new
  synopticfeatureform.leveltop as "level top", --new
  synopticfeatureform.levelbottom as "level bottom", --new
--  '' as "above", -- feature is related
--  '' as "below", -- feature is related
--  '' as "same as", -- feature is related
--  '' as "fill of", -- feature is cutfill
--  '' as "filled by", -- feature is cutfill
--  '' as "abutting", -- feature is related
--  '' as "abbuted by", -- feature is related
--  '' as "contiguous with", -- feature is related
  synopticfeatureform.int_ext as "internal/<br/>external/<br/>structural/<br/>other",
  synopticfeatureform.excavated as "excavated", --new
  synopticfeatureform.fullyexcavated as "fully excavated",
  synopticfeatureform.contaminated as "risk of contamination (high/ moderate/ low/ none)",
--  , -- drawing number
--  , -- photo number
  synopticfeatureform.lastmodified as "last modified", --new
  synopticfeatureform.excavationnote as "excavation notes", --new
  synopticfeatureform.featurenumber -- this is foreign key for query below that is $keyquery, and those join modulecreatedbtable.php: 138

SQL_END;

# Define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
/* temporary index */
$idx = 0;
$outputcolumn[$idx++] = 0;
$outputcolumn[$idx++] = 34;
$outputcolumn[$idx++] = 23;
$outputcolumn[$idx++] = 24;
$outputcolumn[$idx++] = 1;
$outputcolumn[$idx++] = 2;
$outputcolumn[$idx++] = 3;
$outputcolumn[$idx++] = 4;
$outputcolumn[$idx++] = 25;
$outputcolumn[$idx++] = 5;
$outputcolumn[$idx++] = 6;
$outputcolumn[$idx++] = 7;
$outputcolumn[$idx++] = 8;
$outputcolumn[$idx++] = 9;
$outputcolumn[$idx++] = 10;
$outputcolumn[$idx++] = 11;
$outputcolumn[$idx++] = 12;
$outputcolumn[$idx++] = 13;
$outputcolumn[$idx++] = 14;
$outputcolumn[$idx++] = 15;
$outputcolumn[$idx++] = 26;
$outputcolumn[$idx++] = 27;
$outputcolumn[$idx++] = 28;
$outputcolumn[$idx++] = 31;
$outputcolumn[$idx++] = 32;
$outputcolumn[$idx++] = 33;
$outputcolumn[$idx++] = 29;
$outputcolumn[$idx++] = 30;
$outputcolumn[$idx++] = 16;
$outputcolumn[$idx++] = 17;
$outputcolumn[$idx++] = 18;
$outputcolumn[$idx++] = 19;
$outputcolumn[$idx++] = 35;
$outputcolumn[$idx++] = 36;
$outputcolumn[$idx++] = 20;
$outputcolumn[$idx++] = 21;
/* store columns count */
$outputcolumns = $idx;

$key_featurenumber = 22;

/* temporary index */
$idx = 0;
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  area as "area(s)"
from
  fielddata.featurelogareas
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'area';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  squarename as "square(s)"
from
  fielddata.featurelogsquares
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'squarename';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  seasonname || ': ' || phase as "phases"
from
  fielddata.synopticfeatureformphases
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'seasonname';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is above..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'above'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is below..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'below'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is the same as..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'same as'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this deposit is the the fill of..."
from
  fielddata.synopticfeatureformcutfillrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'fill of'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this deposit is the the filled by..."
from
  fielddata.synopticfeatureformcutfillrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'filled by'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is abutting..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'abutting'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is abutted by..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'abutted by'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is contiguous with..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'contiguous with'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "identical to..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'identical'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keytargetfield[$idx] = 'df.featurenumber';
$keyquery[$idx] = <<<SQL_END
select
  case
    when length(trim(d.season)) > 0 then d.season || '-' || d.drawingnumber
    else '' || d.drawingnumber
  end as "drawing number"
from
  fielddata.drawinglog d,
  fielddata.drawinglogfeatures df
where
  d.valid = true
  and df.valid = true
  and d.idfalse = 0
  and df.idfalse = 0
  and d.drawingid = df.drawingid
SQL_END;
$keysort[$idx] = 'd.drawingnumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keytargetfield[$idx] = 'pf.featurenumber';
$keyquery[$idx] = <<<SQL_END
select
  p.imagenumber as "photo number"
from
  fielddata.photolog p,
  fielddata.photologfeatures pf
where
  p.valid = true
  and pf.valid = true
  and p.idfalse = 0
  and pf.idfalse = 0
  and p.photoid = pf.photoid
SQL_END;
$keysort[$idx] = 'p.imagenumber';
/* end of repeat */
/* store columns count */
$keynumberofcolumns = $idx;


# add sort option

include 'componentsortdata.php';


# add freetext search option

include 'modulefreetextsearch.php';

switch ($submenuaction)
  {
  case "":
    break;


    ////////// CASE COMPLETE LOG

  case "browsecompletelog":

    $query = "$superquery FROM fielddata.synopticfeatureform WHERE valid = true and idfalse = 0 $searchsql ORDER BY $sortsql;";
    $uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "complete log";
    $heading2 = "features:";
    $text2 = "all";
    $savename="complete synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> No features exist in database!";

    break;




    ////////// CASE SINGLEFEATURE


  case "browsesinglefeature":

    $query = "$superquery FROM fielddata.synopticfeatureform WHERE valid = true and idfalse = 0 AND featurenumber=$featurenumber $searchsql ORDER BY $sortsql;";
    $uservariables = "featurenumber=$featurenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "single feature";
    $heading2 = "feature:";
    $text2 = "$featurenumber";
    $savename="feature $featurenumber from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> Feature does not exist in database!";

    break;


    ////////// CASE FEATURESERIES

  case "browsefeatureseries":

    $query = "$superquery FROM fielddata.synopticfeatureform WHERE valid = true and idfalse = 0 AND featurenumber>=$firstfeaturenumber AND featurenumber<=$lastfeaturenumber $searchsql ORDER BY $sortsql;";
    $uservariables = "firstfeaturenumber=$firstfeaturenumber&lastfeaturenumber=$lastfeaturenumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "feature series";
    $heading2 = "features:";
    $text2 = "$firstfeaturenumber - $lastfeaturenumber";
    $savename="feature series $firstfeaturenumber-$lastfeaturenumber from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> None of the selected features in this series do exist in database!";

    break;



    ////////// CASE BY DSR SUPERVISOR


  case "browsebydsrsupervisor":

    $query = "$superquery FROM fielddata.synopticfeatureform WHERE valid = true and idfalse = 0 AND dsrsupervisor='$dsrsupervisor' $searchsql ORDER BY $sortsql;";
    $uservariables = "dsrsupervisor=$dsrsupervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "by dsr supervisor";
    $heading2 = "supervisor:";
    $text2 = "$dsrsupervisor";
    $savename="features from dsrsupervisor $dsrsupervisor from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> No feature exist for this dsr supervisor in database!";

    break;



    ////////// CASE BY AREA


  case "browsebyarea":

    if ($filtervaluesserial != '')
      {
	$filtervalues = explode(", ", $filtervaluesserial);
	for ($i=0; $i<count($filtervalues); $i++)
	  {
	    $filtervalues[$i] = "featurelogareas.area='$filtervalues[$i]'";
	  }
	$where_area = implode(" OR ", $filtervalues);
	$headingstring = $filtervaluesserial;
      }
    else
      {
	$where_area =	"featurelogareas.area='$area'";
	$headingstring = $area;
      }

    $query = "$superquery FROM fielddata.synopticfeatureform left join fielddata.featurelogareas on synopticfeatureform.featurenumber = featurelogareas.featurenumber
					where ($where_area) and synopticfeatureform.valid=true and featurelogareas.valid=true
					$searchsql
					ORDER BY $sortsql;";

    $uservariables = "filtervaluesserial=$filtervaluesserial&area=$area&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "by area";
    $heading2 = "area(s):";
    $text2 = $headingstring;
    $savename="features from area(s) $headingstring from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> No feature exist for this area in database!";

    break;



    ////////// CASE BY MATRIXGROUPNUMBER


  case "browsebymatrixgroupnumber":

    if ($filtervaluesserial != '')
      {
	$filtervalues = explode(", ", $filtervaluesserial);
	for ($i=0; $i<count($filtervalues); $i++)
	  {
	    $filtervalues[$i] = "matrixgroupnumber='$filtervalues[$i]'";
	  }
	$where_matrixgroup = implode(" OR ", $filtervalues);
	$headingstring = $filtervaluesserial;
      }
    else
      {
	$where_matrixgroup = "matrixgroupnumber='$matrixgroupnumber'";
	$headingstring = $matrixgroupnumber;
      }

    $query = "$superquery FROM fielddata.synopticfeatureform WHERE valid = true and idfalse = 0 AND ($where_matrixgroup) $searchsql ORDER BY $sortsql;";
    $uservariables = "filtervaluesserial=$filtervaluesserial&matrixgroupnumber=$matrixgroupnumber&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "by matrixgrpno";
    $heading2 = "matrixgrpno(s):";
    $text2 = $headingstring;
    $savename="features from matrixgroupnumber(s) $headingstring from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> No feature exist for this matrixgroupnumber in database!";

    break;



    ////////// CASE BY SQUARE


  case "browsebysquare":

    if ($filtervaluesserial != '')
      {
	$filtervalues = explode(", ", $filtervaluesserial);
	for ($i=0; $i<count($filtervalues); $i++)
	  {
	    $filtervalues[$i] = "featurelogsquares.squarename='$filtervalues[$i]'";
	  }
	$where_square = implode(" OR ", $filtervalues);
	$headingstring = $filtervaluesserial;
      }
    else
      {
	$where_square = "featurelogsquares.squarename='$squarename'";
	$headingstring = $squarename;
      }

    $query = "$superquery FROM fielddata.synopticfeatureform left join fielddata.featurelogsquares on synopticfeatureform.featurenumber = featurelogsquares.featurenumber
					where ($where_square) and synopticfeatureform.valid=true and featurelogsquares.valid=true
					$searchsql
					ORDER BY $sortsql;";

    $uservariables = "filtervaluesserial=$filtervaluesserial&squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "browse synoptic feature form";
    $heading1 = "option:";
    $text1 = "by square";
    $heading2 = "square(s):";
    $text2 = $headingstring;
    $savename="features from square(s) $headingstring from synopticfeatureform";
    $norecordtext="ERROR!!!<br><br> No feature exist for this square in database!";

    break;


    ////////// CASE SYNOPTICS FOR AREA DEFINITION

  case "dsrsynopticfeatureform":

    $query = "$superquery FROM fielddata.synopticfeatureform left join fielddata.featurelogareas on synopticfeatureform.featurenumber = featurelogareas.featurenumber left join fielddata.featurelogsquares on synopticfeatureform.featurenumber = featurelogsquares.featurenumber left join fielddata.featurelogsupervisors on synopticfeatureform.featurenumber = featurelogsupervisors.featurenumber
					WHERE synopticfeatureform.valid=true
					$sqlarea $sqlsquares $sqlsupervisors
					AND synopticfeatureform.featurenumber NOT LIKE 7600 AND synopticfeatureform.featurenumber NOT LIKE 8176 $wherearea $wheresquares $wheresupervisors
					$searchsql
					ORDER BY $sortsql;";

    $uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

    $title = "compiled area records";
    $heading1 = "option:";
    $text1 = "synopticfeatureform";
    $heading2 = "area / squares / supervisors:";
    $text2 = "$area / $listsquares / $listsupervisors";
    $savename="compiled area records synopticfeatureform from area/squares/supervisors $area / $listsquares / $listsupervisors";
    $norecordtext="ERROR!!!<br><br> No synoptics for this query exist in database!";

    break;
  }


if ($submenuaction!='')
  {
# create appropriate save name if freetext search was performed
    if ($searchcolumn!='' and $searchkeywords!='')
      {
	$savename = "!filtered! $savename";
      }

    if ($saveastxt=='yes')
      {
	include 'modulesavequeryastxt.php';
      }
    elseif ($dsrdatacheck!='yes')
      {
	include 'modulebrowsequeryresults.php';
      }
  }
?>