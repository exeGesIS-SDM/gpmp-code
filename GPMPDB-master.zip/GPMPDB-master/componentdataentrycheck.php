<?php

if (!$edit)
{

	switch ($submenuaction)
	{
		case "":
		break;


////////// CASE EVALUATE DATA BAGREGISTER

		case "bagregister":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='bagprefix')
			{
				if ($newcolumndata[$i-1]=='' and $newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}
			elseif ($columnnames[$i]=='bagnumber')
			{
				if (isinteger($newcolumndata[$i-1])==false and isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}
			elseif ($columnnames[$i]=='featurenumber')
			{
				if (isinteger($newcolumndata[$i-1])==false and isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}
		}

		if (!$update)
		{
			#check if entries already exist in DB
			for ($i=1; $i<=$columns; $i++)
			{
				if ($columnnames[$i]=='bagprefix')
				{
					$column1=$columnnames[$i];
					$value1=$newcolumndata[$i-1];
				}
				if ($columnnames[$i]=='bagnumber')
				{
					$column2=$columnnames[$i];
					$value2=$newcolumndata[$i-1];
				}
			}
			if ($value1!='' and $value2!='' and combirecordexists($dbh, $tablename, $column1, $column2, $value1, $value2)==true)
			{
				echo "<SCRIPT LANGUAGE='JavaScript'>
				alert('Data validation error! The value of column \"$column1+$column2\" has to be unique and exists already in the database!')
				</SCRIPT>";
				unset ($entrycount);
				unset ($update);
			}
		}
				
		break;




////////// CASE EVALUATE DATA BURIALFEATURES

		case "burialfeatures":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='burialnumber')
			{
				if (isinteger($newcolumndata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
			elseif ($columnnames[$i]=='featurenumber')
			{
				if (isinteger($newcolumndata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		}
		if (!$update)
		{
			#check if entries already exist in DB
			for ($i=1; $i<=$columns; $i++)
			{
				if ($columnnames[$i]=='burialnumber')
				{
					$column1=$columnnames[$i];
					$value1=$newcolumndata[$i-1];
				}
				elseif ($columnnames[$i]=='featurenumber')
				{
						$column2=$columnnames[$i];
					$value2=$newcolumndata[$i-1];
				}
			}
			if ($value1!='' and $value2!='' and combirecordexists($dbh, $tablename, $column1, $column2, $value1, $value2)==true)
			{
				echo "<SCRIPT LANGUAGE='JavaScript'>
				alert('Data validation error! The value of column \"$column1+$column2\" has to be unique and exists already in the database!')
				</SCRIPT>";
				unset ($entrycount);
				unset ($update);
			}
		}
		break;


////////// CASE EVALUATE DATA BROAD AREAS

		case "broadareas":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='broadareacode')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
				#check if entries already exist in DB
				if (!$editline)
				{
					if (recordexists($dbh, $tablename, $columnnames[$i], $newtoplinedata[$i-1])==true)
					{
						echo "<SCRIPT LANGUAGE='JavaScript'>
						alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
						</SCRIPT>";
						unset ($entrycount);
						unset ($update);
					}
				}
			}
		}
		
		break;
		
		
////////// CASE EVALUATE DATA CDINVENTORY

		case "cdinventory":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='number')
			{
				if (isinteger($newcolumndata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
		#check if entries already exist in DB
				elseif (!$update and recordexists($dbh, $tablename, $columnnames[$i], $newcolumndata[$i-1])==true)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		}
		
		break;





////////// CASE EVALUATE DATA DRAWINGLOG

		case "drawinglog":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='season')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}
			elseif ($columnnames[$i]=='drawingnumber')
			{
				if (isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}

			if ($columnnames[$i]=='portfolionumber')
			{
				if (isinteger($newtoplinedata[$i-1])==false and $newtoplinedata[$i-1]!=NULL)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}
		}

		#check if entries already exist in DB
		if (!$editline)
		{
			for ($i=1; $i<=$columns; $i++)
			{
				if ($columnnames[$i]=='season')
				{
					$column1=$columnnames[$i];
					$value1=$newtoplinedata[$i-1];
				}
				elseif ($columnnames[$i]=='drawingnumber')
				{
					$column2=$columnnames[$i];
					$value2=$newtoplinedata[$i-1];
				}
			}
			if ($value1!='' and $value2!='' and combirecordexists($dbh, $tablename, $column1, $column2, $value1, $value2)==true)
			{
				echo "<SCRIPT LANGUAGE='JavaScript'>
				alert('Data validation error! The value of column \"$column1+$column2\" has to be unique and exists already in the database!')
				</SCRIPT>";
				unset ($entrycount);
				unset ($update);
			}
		}
				
		break;





////////// CASE EVALUATE DATA EXOTICMATERIALREGISTER

		case "exoticmaterialregister":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='featurenumber')
			{
				if (isinteger($newcolumndata[$i-1])==false and isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		}


			
		break;




////////// CASE EVALUATE DATA FEATURE LOG

		case "featurelog":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='featurenumber')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			
				elseif (isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}

			#check if entries already exist in DB
				if (!$editline)
				{
					if (recordexists($dbh, $tablename, $columnnames[$i], $newtoplinedata[$i-1])==true)
					{
						echo "<SCRIPT LANGUAGE='JavaScript'>
						alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
						</SCRIPT>";
						unset ($entrycount);
						unset ($update);
					}
				}
			}
		}

				
		break;


////////// CASE EVALUATE DATA LOCAL AREAS

		case "localareas":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='localareacode')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
				#check if entries already exist in DB
				if (!$editline)
				{
					if (recordexists($dbh, $tablename, $columnnames[$i], $newtoplinedata[$i-1])==true)
					{
						echo "<SCRIPT LANGUAGE='JavaScript'>
						alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
						</SCRIPT>";
						unset ($entrycount);
						unset ($update);
					}
				}
			}
		}
		
		break;
		
////////// CASE EVALUATE DATA PHOTO LOG

		case "photolog":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='imagenumber')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			
				elseif (isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}

			#check if entries already exist in DB
				if (!$editline)
				{
					if (recordexists($dbh, $tablename, $columnnames[$i], $newtoplinedata[$i-1])==true)
					{
						echo "<SCRIPT LANGUAGE='JavaScript'>
						alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
						</SCRIPT>";
						unset ($entrycount);
						unset ($update);
					}
				}
			}

			if ($columnnames[$i]=='cdnumber')
			{
				if (isinteger($newtoplinedata[$i-1])==false and $newtoplinedata[$i-1]!=NULL)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}

		}

				
		break;




////////// CASE EVALUATE DATA SAMPLEREGISTER

		case "sampleregister":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='samplenumber')
			{
				if (isinteger($newcolumndata[$i-1])==false and $newcolumndata[$i-1]!='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
			elseif ($columnnames[$i]=='featurenumber')
			{
				if (isinteger($newcolumndata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
			elseif ($columnnames[$i]=='bagnumber')
			{
				if (isinteger($newcolumndata[$i-1])==false and $newcolumndata[$i-1]!='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		}
		
		break;



////////// CASE EVALUATE DATA SYNOPTICFEATUREFORM

		case "synopticfeatureform":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='featurenumber')
			{
				if ($newtoplinedata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			
				elseif (isinteger($newtoplinedata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}

			if ($columnnames[$i]=='matrixgroupnumber' or $columnnames[$i]=='spacenumber' or $columnnames[$i]=='structurenumber')
			{
				if (isinteger($newtoplinedata[$i-1])==false and $newtoplinedata[$i-1]!=NULL)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer!')
					</SCRIPT>";
					unset ($entrycount);
				}
			}

		}

				
		break;



////////// CASE EVALUATE DATA AUTHENTICATION

		case "authentication":

		#check if entries have correct format
		for ($i=1; $i<=$columns; $i++)
		{
			if ($columnnames[$i]=='name')
			{
				if ($newcolumndata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! Column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
		#check if entries already exist in DB
				elseif (!$update and recordexists($dbh, $tablename, $columnnames[$i], $newcolumndata[$i-1])==true)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be unique and exists already in the database!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		#check if entries have correct format
			if ($columnnames[$i]=='passwd')
			{
				if ($newcolumndata[$i-1]=='')
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! Column \"$columnheader[$i]\" cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
			elseif ($columnnames[$i]=='groupid')
			{
				if (isinteger($newcolumndata[$i-1])==false)
				{
					echo "<SCRIPT LANGUAGE='JavaScript'>
					alert('Data validation error! The value of column \"$columnheader[$i]\" has to be an integer and cannot be empty!')
					</SCRIPT>";
					unset ($entrycount);
					unset ($update);
				}
			}
		}
		
		break;
	}
}
?>