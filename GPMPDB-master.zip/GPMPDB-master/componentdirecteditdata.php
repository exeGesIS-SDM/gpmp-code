<?php

if ($menuaction=='directeditgeneralrecords')
{
	switch ($submenuaction)
	{
		case "":
		break;

		
////////// CASE DIRECT EDIT DATA BAGREGISTER

		case "bagregister":
	
			$sql = "select bagregister.oid
					FROM fielddata.bagregister
					WHERE bagregister.valid=true AND bagregister.bagprefix='$bagprefix' AND bagregister.bagnumber=$bagnumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='bagregister';
			$edit='yes';
			$editline=$line[0];
		break;


////////// CASE DIRECT EDIT DATA DRAWINGLOG

		case "drawinglog":
	
			$sql = "select drawinglog.oid
					FROM fielddata.drawinglog
					WHERE drawinglog.valid=true AND drawinglog.season='$season' AND drawinglog.drawingnumber=$drawingnumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='drawinglog';
			$edit='yes';
			$editline=$line[0];
		break;


////////// CASE DIRECT EDIT DATA ENTITYLOG

		case "entitylog":
	
			$sql = "select entitylog.oid
					FROM fielddata.entitylog
					WHERE entitylog.valid=true AND entitylog.entitynumber=$entitynumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='entitylog';
			$edit='yes';
			$editline=$line[0];
		break;

		
////////// CASE DIRECT EDIT DATA FEATURELOG

		case "featurelog":
	
			$sql = "select featurelog.oid
					FROM fielddata.featurelog
					WHERE featurelog.valid=true AND featurelog.featurenumber=$featurenumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='featurelog';
			$edit='yes';
			$editline=$line[0];
		break;

////////// CASE DIRECT EDIT DATA GROUPLOG

		case "grouplog":
	
			$sql = "select grouplog.oid
					FROM fielddata.grouplog
					WHERE grouplog.valid=true AND grouplog.groupnumber=$groupnumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='grouplog';
			$edit='yes';
			$editline=$line[0];
		break;
		
		
////////// CASE DIRECT EDIT DATA SPACELOG

		case "spacelog":
	
			$sql = "select spacelog.oid
					FROM fielddata.spacelog
					WHERE spacelog.valid=true AND spacelog.spacenumber=$spacenumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='spacelog';
			$edit='yes';
			$editline=$line[0];
		break;
		
		
////////// CASE DIRECT EDIT DATA STRUCTURELOG

		case "structurelog":
	
			$sql = "select structurelog.oid
					FROM fielddata.structurelog
					WHERE structurelog.valid=true AND structurelog.structurenumber=$structurenumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='structurelog';
			$edit='yes';
			$editline=$line[0];
		break;
		
////////// CASE DIRECT EDIT DATA SYNOPTIC FEATURE FORM

		case "synopticfeatureform":
	
			$sql = "select synopticfeatureform.oid
					FROM fielddata.synopticfeatureform
					WHERE synopticfeatureform.valid=true AND synopticfeatureform.featurenumber=$featurenumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='synopticfeatureform';
			$edit='yes';
			$editline=$line[0];
		break;

////////// CASE DIRECT EDIT DATA FEATURELOG

		case "photolog":
	
			$sql = "select photolog.oid
					FROM fielddata.photolog
					WHERE photolog.valid=true AND photolog.imagenumber=$imagenumber;";
			@$ret = pg_exec($dbh, $sql);
			@$line = pg_fetch_row($ret, 0);

			$directedit='yes';
			$indexaction='editdelete';
			$menuaction='editdeletedata';
			$submenuaction='photolog';
			$edit='yes';
			$editline=$line[0];
		break;
	}

	if(!$line[0])
	{
		$directedit='';
		$indexaction='editdelete';
		$menuaction='directeditgeneralrecords';
		$submenuaction='';

		include 'menudirecteditdata.php';
		die;
	}
}


?>