<?php

# direct edit support

	include 'componentdirecteditdata.php';


# add sort option

	include 'componentsortdata.php';


# add freetext search option

	include 'modulefreetextsearch.php';


# add view recent entries sql options

	include 'componentrecententries.php';




##### !!!!!!!!!!!! create headers at the bottom of the page!!!!!!!!


switch ($submenuaction)
	{
		case "":
		break;


////////// CASE EDIT DATA BAGREGISTER

		case "bagregister":

		# variables controlling the data edit

		$tablename = "fielddata.bagregister";
		$keyidname = "bagregister.bagregisterid";
		$columns = "7";
		$columnnames[1] = "bagprefix";
			$columnheader[1] = "season prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "6";
			$fieldcolumnwidth[1] = "80";
			$defaultvalue[1] = date('Y');
		$columnnames[2] = "bagnumber";
			$columnheader[2] = "bag number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "3";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "featurenumber";
			$columnheader[3] = "feature";
			$fieldtype[3] = "text";
			$fieldlength[3] = "5";
			$fieldsize[3] = "5";
			$fieldcolumnwidth[3] = "80";
		$columnnames[4] = "date";
			$columnheader[4] = "date";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "80";
		$columnnames[5] = "category";
			$columnheader[5] = "category";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listbagcategories.bagcategory FROM fielddata.listbagcategories WHERE listbagcategories.valid=true ORDER BY listbagcategories.bagcategory;";
			$fieldlength[5] = "10";
			$fieldcolumnwidth[5] = "80";
		$columnnames[6] = "comments";
			$columnheader[6] = "comments";
			$fieldtype[6] = "text";
			$fieldlength[6] = "255";
			$fieldsize[6] = "40";
			$fieldcolumnwidth[6] = "200";
		// hidden fields have to be at the end of the list because of javascript fields!
		$columnnames[7] = "bagregisterid";
			$fieldtype[7] = "hidden";

		$subtables = "1";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.bagregistersquares";
		$subkeyidname[1] = "bagregisterid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldsize[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "100";


		$query = "SELECT bagregister.oid, bagregister.bagprefix || '-' || bagregister.bagnumber AS bag, bagregister.featurenumber AS feature, bagregister.date, bagregister.category, bagregister.comments, bagregister.bagregisterid
				FROM fielddata.bagregister WHERE bagregister.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 7;

		// editquery has to match the columnnames list above - hidden fields have to be at the end!
		$editquery = "SELECT bagregister.bagprefix, bagregister.bagnumber, bagregister.featurenumber, bagregister.date, bagregister.category, bagregister.comments, bagregister.bagregisterid FROM fielddata.bagregister WHERE bagregister.valid=true";
		$keyeditcolumn[1] = 6;
		$keynumberofcolumns = 1;
		$keycolumn[1] = 6;
		$keyquery[1] = "SELECT bagregistersquares.squarename AS \"square(s)\" FROM fielddata.bagregistersquares WHERE bagregistersquares.valid='t'";
		$keysort[1] = "bagregistersquares.squarename";

		break;




////////// CASE EDIT DATA BURIALFEATURES

		case "burialfeatures":

		# variables controlling the data input

		$tablename = "fielddata.burialfeatures";
		$columns = "3";
		$columnnames[1] = "burialnumber";
			$columnheader[1] = "burial";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "featurenumber";
			$columnheader[2] = "feature";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "5";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "burialtype";
			$columnheader[3] = "burial type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listburialtypes.burialtype FROM fielddata.listburialtypes WHERE listburialtypes.valid=true ORDER BY listburialtypes.burialtype;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "80";

		# variables to view recent entries

		$query = "select burialfeatures.oid, burialfeatures.burialnumber AS \"burial\", burialfeatures.featurenumber AS \"feature\", burialfeatures.burialtype AS \"burial type\"
				from fielddata.burialfeatures WHERE burialfeatures.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		break;


////////// CASE EDIT DATA BROADAREAS

		case "broadareas":

		# variables controlling the data input
		$tablename = "fielddata.broadareas";
		$keyidname = "broadareas.broadareaid";
		$tablewidth = 800;
		$columns = "2";
		$columnnames[1] = "broadareacode";
			$columnheader[1] = "broad area code";
			$fieldtype[1] = "text";
			$fieldlength[1] = 5;
			$fieldsize[1] = 6;
			$fieldcolumnwidth[1] = 80;
		$columnnames[2] = "broadareaname";
			$columnheader[2] = "broad area name";
			$fieldtype[2] = "text";
			$fieldlength[2] = 50;
			$fieldsize[2] = 50;
			$fieldcolumnwidth[2] = 160;

		$subtables = 1;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.broadareaslocalareas";
		$subkeyidname[1] = "broadareaid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "localareacode";
			$subcolumnheader[1][1] = "local area code(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT localareas.localareacode FROM fielddata.localareas WHERE localareas.valid=true ORDER BY localareas.localareacode;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "80";

		$query = "select broadareas.oid, broadareas.broadareaid, broadareas.broadareacode AS \"broad area code\", broadareas.broadareaname AS \"broad area name\"
			from fielddata.broadareas where broadareas.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 4;

		$editquery = "select broadareas.broadareacode AS \"broad area code\", broadareas.broadareaname AS \"broad area name\", broadareas.broadareaid
			from fielddata.broadareas where broadareas.valid=true";


		$keynumberofcolumns = 1;
		$keycolumn[1] = 1;
		$keyeditcolumn[1] = 2;
		$keyquery[1] = "SELECT broadareaslocalareas.localareacode AS \"local area code(s)\" FROM fielddata.broadareaslocalareas WHERE broadareaslocalareas.valid=true";
		$keysort[1] = "broadareaslocalareas.localareacode";

		break;




////////// CASE EDIT DATA CD INVENTORY

		case "cdinventory":

		# variables controlling the data input

		$tablename = "fielddata.cdinventory";
		$columns = "6";
		$columnnames[1] = "storagemedium";
			$columnheader[1] = "storage medium";
			$fieldtype[1] = "dropdown";
			$dropdownsql[1] = "SELECT DISTINCT liststoragemediums.storagemedium FROM fielddata.liststoragemediums WHERE liststoragemediums.valid=true ORDER BY liststoragemediums.storagemedium;";
			$fieldlength[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "number";
			$columnheader[2] = "number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "4";
			$fieldsize[2] = "4";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "contents";
			$columnheader[3] = "contents";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "80";
			$fieldcolumnwidth[3] = "400";
		$columnnames[4] = "giza";
			$columnheader[4] = "in Giza";
			$fieldtype[4] = "checkbox";
			$fieldcolumnwidth[4] = "30";
		$columnnames[5] = "boston";
			$columnheader[5] = "in Boston";
			$fieldtype[5] = "checkbox";
			$fieldcolumnwidth[5] = "30";
		$columnnames[6] = "newyork";
			$columnheader[6] = "in New York";
			$fieldtype[6] = "checkbox";
			$fieldcolumnwidth[6] = "30";

		# variables to view recent entries

		$query = "select cdinventory.oid, cdinventory.storagemedium AS \"storage medium\", cdinventory.number, cdinventory.contents,
					CASE WHEN cdinventory.giza='t' THEN 'yes' WHEN cdinventory.giza='f' THEN 'no' END AS \"in Giza\",
					CASE WHEN cdinventory.boston='t' THEN 'yes' WHEN cdinventory.boston='f' THEN 'no' END AS \"in Boston\",
					CASE WHEN cdinventory.newyork='t' THEN 'yes' WHEN cdinventory.newyork='f' THEN 'no' END AS \"in New York\"
					from fielddata.cdinventory WHERE cdinventory.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		break;



////////// CASE EDIT DATA DRAWING LOG

		case "drawinglog":

		# variables controlling the data input

		$tablename = "fielddata.drawinglog";
		$keyidname = "drawinglog.drawingid";
		$tablewidth = 800;
		$columns = 19;
		$columnnames[1] = "season";
			$columnheader[1] = "season";
			$fieldtype[1] = "dropdown";
			$dropdownsql[1] = "SELECT DISTINCT listdrawingseasons.seasonyear FROM fielddata.listdrawingseasons WHERE listdrawingseasons.valid=true ORDER BY listdrawingseasons.seasonyear;";
			$fieldlength[1] = "5";
			$fieldcolumnwidth[1] = "60";
			$defaultvalue[1] = date('Y');
		$columnnames[2] = "drawingnumber";
			$columnheader[2] = "drawing number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "5";
			$fieldcolumnwidth[2] = "60";
		$columnnames[3] = "area";
			$columnheader[3] = "area";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "date";
			$columnheader[4] = "date";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "70";
		$columnnames[5] = "drawinglabel";
			$columnheader[5] = "description";
			$fieldtype[5] = "text";
			$fieldlength[5] = "255";
			$fieldsize[5] = "25";
			$fieldcolumnwidth[5] = "150";
		$columnnames[6] = "scale";
			$columnheader[6] = "scale (1:X)";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listscales.scale FROM fielddata.listscales WHERE listscales.valid=true ORDER BY listscales.scale;";
			$fieldlength[6] = "4";
			$fieldcolumnwidth[6] = "50";
		$columnnames[7] = "checked";
			$columnheader[7] = "checked?";
			$fieldtype[7] = "dropdown";
			$dropdownsql[7] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[7] = "4";
			$fieldcolumnwidth[7] = "30";
			$defaultvalue[7] = "no";
		$columnnames[8] = "cd";
			$columnheader[8] = "cd/dvd storage";
			$fieldtype[8] = "dropdown";
			$dropdownsql[8] = "SELECT DISTINCT cdinventory.number FROM fielddata.cdinventory WHERE cdinventory.valid=true ORDER BY cdinventory.number;";
			$fieldlength[8] = "4";
			$fieldcolumnwidth[8] = "30";
		$columnnames[9] = "drawingtype";
			$columnheader[9] = "drawing type";
			$fieldtype[9] = "dropdown";
			$dropdownsql[9] = "SELECT DISTINCT listdrawingtypes.drawingtype FROM fielddata.listdrawingtypes WHERE listdrawingtypes.valid=true ORDER BY listdrawingtypes.drawingtype;";
			$fieldlength[9] = "8";
			$fieldcolumnwidth[9] = "70";
			$defaultvalue[9] = "field";
		$columnnames[10] = "portfolionumber";
			$columnheader[10] = "portfolio number";
			$fieldtype[10] = "dropdown";
			$dropdownsql[10] = "SELECT DISTINCT listportfolios.portfolionumber FROM fielddata.listportfolios WHERE listportfolios.valid=true ORDER BY listportfolios.portfolionumber;";
			$fieldlength[10] = "4";
			$fieldcolumnwidth[10] = "30";
		$columnnames[11] = "locationoriginal";
			$columnheader[11] = "location of original";
			$dropdownsql[11] = "SELECT DISTINCT listlocations.location FROM fielddata.listlocations WHERE listlocations.valid=true ORDER BY listlocations.location;";
			$fieldlength[11] = "8";
			$fieldcolumnwidth[11] = "80";
			$startnewline[11] = "yes";
		$columnnames[12] = "copied";
			$columnheader[12] = "copied?";
			$fieldtype[12] = "dropdown";
			$dropdownsql[12] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[12] = "4";
			$fieldcolumnwidth[12] = "30";
			$defaultvalue[12] = "no";
		$columnnames[13] = "scanned";
			$columnheader[13] = "scanned?";
			$fieldtype[13] = "dropdown";
			$dropdownsql[13] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[13] = "4";
			$fieldcolumnwidth[13] = "30";
			$defaultvalue[13] = "no";
		$columnnames[14] = "cropped";
			$columnheader[14] = "cropped?";
			$fieldtype[14] = "dropdown";
			$dropdownsql[14] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[14] = "4";
			$fieldcolumnwidth[14] = "30";
			$defaultvalue[14] = "no";
		$columnnames[15] = "renamed";
			$columnheader[15] = "renamed?";
			$fieldtype[15] = "dropdown";
			$dropdownsql[15] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[15] = "4";
			$fieldcolumnwidth[15] = "30";
			$defaultvalue[15] = "no";
		$columnnames[16] = "burnttocd";
			$columnheader[16] = "burnt to CD?";
			$fieldtype[16] = "dropdown";
			$dropdownsql[16] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[16] = "4";
			$fieldcolumnwidth[16] = "60";
			$defaultvalue[16] = "no";
		$columnnames[17] = "scanuploaded";
			$columnheader[17] = "scan uploaded?";
			$fieldtype[17] = "dropdown";
			$dropdownsql[17] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[17] = "4";
			$fieldcolumnwidth[17] = "60";
			$defaultvalue[17] = "no";
		$columnnames[18] = "drawingsenttoboston";
			$columnheader[18] = "date drawing sent to boston";
			$fieldtype[18] = "text";
			$fieldlength[18] = "10";
			$fieldsize[18] = "10";
			$fieldcolumnwidth[18] = "120";

		// hidden fields have to be at the end of the list because of javascript fields!
		$columnnames[19] = "drawingid";
			$fieldtype[19] = "hidden";

		$subtables = "3";

		$subtables = 3;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:250px; width:220px; height:150px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.drawinglogsupervisors";
		$subkeyidname[1] = "drawingid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "supervisor";
			$subcolumnheader[1][1] = "artist(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "80";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:250px; width:200px; height:300px; z-index:3; overflow: auto";
		$subtablename[2] = "fielddata.drawinglogsquares";
		$subkeyidname[2] = "drawingid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:500px; top:250px; width:200px; height:300px; z-index:4; overflow: auto";
		$subtablename[3] = "fielddata.drawinglogfeatures";
		$subkeyidname[3] = "drawingid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "featurenumber";
			$subcolumnheader[3][1] = "feature(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[3][1] = "6";
			$subfieldcolumnwidth[3][1] = "100";


		# variables to view recent entries

		$query = "SELECT drawinglog.oid, drawinglog.drawingid, drawinglog.season || '-' || drawinglog.drawingnumber AS drawing, drawinglog.area, drawinglog.date, drawinglog.drawinglabel AS description, '1:' || drawinglog.scale AS scale,
					drawinglog.checked AS \"checked?\", drawinglog.cd AS \"cd/dvd storage\", drawinglog.drawingtype AS \"drawing type\", drawinglog.portfolionumber AS \"portfolio number\", drawinglog.locationoriginal AS \"location of original\",
					drawinglog.copied AS \"copied?\", drawinglog.scanned AS \"scanned?\", drawinglog.cropped AS \"cropped?\", drawinglog.renamed AS \"renamed?\", drawinglog.burnttocd AS \"burnt to CD?\", drawinglog.scanuploaded AS \"scan uploaded?\",
					drawinglog.drawingsenttoboston AS \"date drawing sent to boston\"
					FROM fielddata.drawinglog where drawinglog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 20;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 19;
		$outputcolumn[3]= 20;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 21;
		$outputcolumn[8]= 7;
		$outputcolumn[9]= 8;
		$outputcolumn[10]= 9;
		$outputcolumn[11]= 10;
		$outputcolumn[12]= 11;
		$outputcolumn[13]= 12;
		$outputcolumn[14]= 13;
		$outputcolumn[15]= 14;
		$outputcolumn[16]= 15;
		$outputcolumn[17]= 16;
		$outputcolumn[18]= 17;
		$outputcolumn[19]= 18;

		$editquery = "SELECT drawinglog.season, drawinglog.drawingnumber, drawinglog.area, drawinglog.date, drawinglog.drawinglabel, drawinglog.scale, drawinglog.checked, drawinglog.cd, drawinglog.drawingtype, drawinglog.portfolionumber,
					drawinglog.locationoriginal,drawinglog.copied, drawinglog.scanned, drawinglog.cropped, drawinglog.renamed, drawinglog.burnttocd, drawinglog.scanuploaded, drawinglog.drawingsenttoboston, drawinglog.drawingid
					FROM fielddata.drawinglog where drawinglog.valid=true";

		$keynumberofcolumns = 3;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keycolumn[3] = 1;
		$keyeditcolumn[1] = 18;
		$keyeditcolumn[2] = 18;
		$keyeditcolumn[3] = 18;
		$keyquery[1] = "SELECT drawinglogsupervisors.supervisor AS \"artist(s)\" FROM fielddata.drawinglogsupervisors WHERE drawinglogsupervisors.valid=true";
		$keyquery[2] = "SELECT drawinglogsquares.squarename AS \"square(s)\" FROM fielddata.drawinglogsquares WHERE drawinglogsquares.valid=true";
		$keyquery[3] = "SELECT drawinglogfeatures.featurenumber AS \"feature(s)\" FROM fielddata.drawinglogfeatures WHERE drawinglogfeatures.valid=true";
		$keysort[1] = "drawinglogsupervisors.supervisor";
		$keysort[2] = "drawinglogsquares.squarename";
		$keysort[3] = "drawinglogfeatures.featurenumber";


		break;



////////// CASE ADD DATA ENTITY LOG

		case "entitylog":

		# variables controlling the data input

		$tablename = "fielddata.entitylog";
		$keyidname = "entitylog.entitynumber";
		$tablewidth = 760;
		$columns = "7";
		$columnnames[1] = "entitynumber";
			$columnheader[1] = "entity";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "entitytype";
			$columnheader[2] = "type";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "SELECT DISTINCT listentitytypes.entitytype FROM fielddata.listentitytypes WHERE listentitytypes.valid=true ORDER BY listentitytypes.entitytype;";
			$fieldlength[2] = "10";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "entityname";
			$columnheader[3] = "name";
			$fieldtype[3] = "text";
			$fieldlength[3] = "100";
			$fieldsize[3] = "15";
			$fieldcolumnwidth[3] = "80";
		$columnnames[4] = "excavationarea";
			$columnheader[4] = "area";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$fieldlength[4] = "10";
			$fieldcolumnwidth[4] = "80";
		$columnnames[5] = "date";
			$columnheader[5] = "date";
			$fieldtype[5] = "text";
			$fieldlength[5] = "10";
			$fieldsize[5] = "8";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "supervisor";
			$columnheader[6] = "creator";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[6] = "5";
			$fieldcolumnwidth[6] = "80";
		$columnnames[7] = "description";
			$columnheader[7] = "description";
			$fieldtype[7] = "text";
			$fieldlength[7] = "255";
			$fieldsize[7] = "10";
			$fieldcolumnwidth[7] = "50";

		$subtables = "4";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:240px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.entitylogdefinedbyfeaturenumbers";
		$subkeyidname[1] = "entitynumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "definedbyfeaturenumber";
			$subcolumnheader[1][1] = "defined by feature(s)";
			$subfieldtype[1][1] = "text";
			$subfieldlength[1][1] = "5";
			$subfieldsize[1][1] = "4";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:180px; width:220px; height:160px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.entitylogincludesentitynumbers";
		$subkeyidname[2] = "entitynumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "inclentitynumber";
			$subcolumnheader[2][1] = "includes entity / entities";
			$subfieldtype[2][1] = "text";
			$subfieldlength[2][1] = "5";
			$subfieldsize[2][1] = "3";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:160px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.entitylogincludesfeaturenumbers";
		$subkeyidname[3] = "entitynumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "inclfeaturenumber";
			$subcolumnheader[3][1] = "includes feature(s)";
			$subfieldtype[3][1] = "text";
			$subfieldlength[3][1] = "5";
			$subfieldsize[3][1] = "4";
			$subfieldcolumnwidth[3][1] = "100";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:360px; width:370px; height:140px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.entitylogchanges";
		$subkeyidname[4] = "entitynumber";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "3";
		$subcolumnnames[4][1] = "date";
			$subcolumnheader[4][1] = "modifications (date)";
			$subfieldtype[4][1] = "text";
			$subfieldlength[4][1] = "10";
			$subfieldsize[4][1] = "8";
			$subfieldcolumnwidth[4][1] = "50";
		$subcolumnnames[4][2] = "supervisor";
			$subcolumnheader[4][2] = "modifications (creator)";
			$subfieldtype[4][2] = "dropdown";
			$subdropdownsql[4][2] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[4][2] = "5";
			$subfieldcolumnwidth[4][2] = "50";
		$subcolumnnames[4][3] = "description";
			$subcolumnheader[4][3] = "modifications (description)";
			$subfieldtype[4][3] = "text";
			$subfieldlength[4][3] = "200";
			$subfieldsize[4][3] = "20";
			$subfieldcolumnwidth[4][3] = "100";

		# variables to view recent entries

		$query = "select entitylog.oid, entitylog.entitynumber AS \"entity\", entitylog.entitytype AS \"type\", entitylog.entityname AS \"name\", entitylog.excavationarea AS \"area\", entitylog.date, entitylog.supervisor AS \"creator\", entitylog.description,
					entitylog.entitynumber
					from fielddata.entitylog where entitylog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 11;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 6;
		$outputcolumn[6]= 7;
		$outputcolumn[7]= 9;
		$outputcolumn[8]= 10;
		$outputcolumn[9]= 11;
		$outputcolumn[10]= 12;

		$editquery = "select entitylog.entitynumber, entitylog.entitytype, entitylog.entityname, entitylog.excavationarea, entitylog.date, entitylog.supervisor, entitylog.description
					from fielddata.entitylog where entitylog.valid=true";

		$keynumberofcolumns = 4;
		$keycolumn[1] = 8;
		$keycolumn[2] = 8;
		$keycolumn[3] = 8;
		$keycolumn[4] = 8;

		$keyquery[1] = "SELECT entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber AS \"defined by feature(s)\" FROM fielddata.entitylogdefinedbyfeaturenumbers WHERE entitylogdefinedbyfeaturenumbers.valid=true";
		$keyquery[2] = "SELECT entitylogincludesentitynumbers.inclentitynumber AS \"includes entity / entities\" FROM fielddata.entitylogincludesentitynumbers WHERE entitylogincludesentitynumbers.valid=true";
		$keyquery[3] = "SELECT entitylogincludesfeaturenumbers.inclfeaturenumber AS \"includes feature(s)\" FROM fielddata.entitylogincludesfeaturenumbers WHERE entitylogincludesfeaturenumbers.valid=true";
		$keyquery[4] = "SELECT '[' || entitylogchanges.date || ' ' || entitylogchanges.supervisor || '] ' || entitylogchanges.description AS \"modification(s)\" FROM fielddata.entitylogchanges WHERE entitylogchanges.valid=true";

		$keysort[1] = "entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber";
		$keysort[2] = "entitylogincludesentitynumbers.inclentitynumber";
		$keysort[3] = "entitylogincludesfeaturenumbers.inclfeaturenumber";
		$keysort[4] = "entitylogchanges.date";

		$keyeditnumberofcolumns = 4;
		$keyeditcolumn[1] = 0;
		$keyeditcolumn[2] = 0;
		$keyeditcolumn[3] = 0;
		$keyeditcolumn[4] = 0;
		$keyeditquery[1] = "SELECT entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber FROM fielddata.entitylogdefinedbyfeaturenumbers WHERE entitylogdefinedbyfeaturenumbers.valid=true";
		$keyeditquery[2] = "SELECT entitylogincludesentitynumbers.inclentitynumber FROM fielddata.entitylogincludesentitynumbers WHERE entitylogincludesentitynumbers.valid=true";
		$keyeditquery[3] = "SELECT entitylogincludesfeaturenumbers.inclfeaturenumber FROM fielddata.entitylogincludesfeaturenumbers WHERE entitylogincludesfeaturenumbers.valid=true";
		$keyeditquery[4] = "SELECT entitylogchanges.date, entitylogchanges.supervisor, entitylogchanges.description FROM fielddata.entitylogchanges WHERE entitylogchanges.valid=true";

		break;



////////// CASE EDIT DATA EXOTICMATERIALREGISTER

		case "exoticmaterialregister":

		# variables controlling the data input

		$tablename = "fielddata.exoticmaterialregister";
		$keyidname = "exoticmaterialregister.exoticmaterialregisterid";
		$columns = "8";
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "materialcategory";
			$columnheader[3] = "category";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listexoticmaterialcategories.materialcategory FROM fielddata.listexoticmaterialcategories WHERE listexoticmaterialcategories.valid=true ORDER BY listexoticmaterialcategories.materialcategory;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "count";
			$columnheader[4] = "count";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "3";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "weightprefix";
			$columnheader[5] = "weight prefix";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listweightprefix.weightprefix FROM fielddata.listweightprefix WHERE listweightprefix.valid=true ORDER BY listweightprefix.weightprefix;";
			$fieldlength[5] = "4";
			$fieldcolumnwidth[5] = "40";
		$columnnames[6] = "weight";
			$columnheader[6] = "weight (g)";
			$fieldtype[6] = "text";
			$fieldlength[6] = "10";
			$fieldsize[6] = "8";
			$fieldcolumnwidth[6] = "40";
		$columnnames[7] = "comments";
			$columnheader[7] = "comments";
			$fieldtype[7] = "text";
			$fieldlength[7] = "100";
			$fieldsize[7] = "40";
			$fieldcolumnwidth[7] = "200";
		// hidden fields have to be at the end of the list because of javascript fields!
		$columnnames[8] = "exoticmaterialregisterid";
			$fieldtype[8] = "hidden";


		$subtables = "1";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.exoticmaterialregistersquares";
		$subkeyidname[1] = "exoticmaterialregisterid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldsize[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "100";


		# variables to view recent entries

		$query = "select exoticmaterialregister.oid, exoticmaterialregister.exoticmaterialregisterid, exoticmaterialregister.featurenumber AS \"feature\", exoticmaterialregister.date, exoticmaterialregister.materialcategory AS \"category\", exoticmaterialregister.count, (CASE WHEN exoticmaterialregister.weightprefix IS NULL THEN '' WHEN exoticmaterialregister.weightprefix IS NOT NULL THEN exoticmaterialregister.weightprefix END) || exoticmaterialregister.weight as \"weight (g)\", exoticmaterialregister.comments
				from fielddata.exoticmaterialregister WHERE exoticmaterialregister.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 5;
		$outputcolumn[4]= 6;
		$outputcolumn[5]= 7;
		$outputcolumn[6]= 8;

		$editquery = "select exoticmaterialregister.featurenumber, exoticmaterialregister.date, exoticmaterialregister.materialcategory, exoticmaterialregister.count, exoticmaterialregister.weightprefix, exoticmaterialregister.weight, exoticmaterialregister.comments, exoticmaterialregister.exoticmaterialregisterid
				from fielddata.exoticmaterialregister WHERE exoticmaterialregister.valid=true";

		$keynumberofcolumns = 1;
		$keycolumn[1] = "1";
		$keyeditcolumn[1] = "7";
		$keyquery[1] = "SELECT exoticmaterialregistersquares.squarename as \"square(s)\" FROM fielddata.exoticmaterialregistersquares WHERE exoticmaterialregistersquares.valid=true";
		$keysort[1] = "exoticmaterialregistersquares.squarename";

		break;




////////// CASE EDIT DATA FEATURELOG

		case "featurelog":

		# variables controlling the data edit

		$tablename = "fielddata.featurelog";
		$keyidname = "featurelog.featurenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "145";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "4";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.featurelogsquares";
		$subkeyidname[1] = "featurenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.featurelogareas";
		$subkeyidname[2] = "featurenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.featurelogsupervisors";
		$subkeyidname[3] = "featurenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:350px; width:300px; height:100px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.reassignedfeatures";
		$subkeyidname[4] = "featurenumber";
		$subtablewidth[4] = 250;
		$subcolumns[4] = "2";
		$subcolumnnames[4][1] = "oldfeaturenumber";
			$subcolumnheader[4][1] = "old feature number";
			$subfieldtype[4][1] = "text";
			$subfieldlength[4][1] = "25";
			$subfieldsize[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "100";
		$subcolumnnames[4][2] = "olddate";
			$subcolumnheader[4][2] = "old date";
			$subfieldtype[4][2] = "text";
			$subfieldlength[4][2] = "10";
			$subfieldsize[4][2] = "8";
			$subfieldcolumnwidth[4][2] = "80";

		$query = "SELECT featurelog.oid, featurelog.featurenumber as feature, featurelog.date, featurelog.description, featurelog.featurenumber
					FROM fielddata.featurelog WHERE featurelog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		$editquery = "SELECT featurelog.featurenumber, featurelog.date, featurelog.description FROM fielddata.featurelog WHERE featurelog.valid=true";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 5;
		$outputcolumn[3]= 6;
		$outputcolumn[4]= 7;
		$outputcolumn[5]= 3;
		$outputcolumn[6]= 8;
		$outputcolumn[7]= 9;


		$keynumberofcolumns = 5;

		$keycolumn[1] = 4;
		$keyquery[1] = "SELECT featurelogsquares.squarename as \"square(s)\" FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keysort[1] = "featurelogsquares.squarename";
		$keycolumn[2] = 4;
		$keyquery[2] = "SELECT featurelogareas.area as \"area(s)\" FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keysort[2] = "featurelogareas.area";
		$keycolumn[3] = 4;
		$keyquery[3] = "SELECT featurelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.featurelogsupervisors WHERE featurelogsupervisors.valid=true";
		$keysort[3] = "featurelogsupervisors.supervisor";
		$keycolumn[4] = 4;
		$keyquery[4] = "SELECT reassignedfeatures.oldfeaturenumber as \"old feature number\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[4] = "reassignedfeatures.oldfeaturenumber";
		$keycolumn[5] = 4;
		$keyquery[5] = "SELECT reassignedfeatures.olddate as \"old date\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[5] = "reassignedfeatures.oldfeaturenumber";


		$keyeditnumberofcolumns = 4;
		$keyeditcolumn[1] = 0;
		$keyeditcolumn[2] = 0;
		$keyeditcolumn[3] = 0;
		$keyeditcolumn[4] = 0;
		$keyeditquery[1] = "SELECT featurelogsquares.squarename FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keyeditquery[2] = "SELECT featurelogareas.area FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keyeditquery[3] = "SELECT featurelogsupervisors.supervisor FROM fielddata.featurelogsupervisors WHERE featurelogsupervisors.valid=true";
		$keyeditquery[4] = "SELECT reassignedfeatures.oldfeaturenumber, reassignedfeatures.olddate FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";


		break;


////////// CASE EDIT DATA GROUPLOG

		case "grouplog":

		# variables controlling the data edit

		$tablename = "fielddata.grouplog";
		$keyidname = "grouplog.groupnumber";
		$tablewidth = 760;
		$columns = "4";
		$columnnames[1] = "groupnumber";
			$columnheader[1] = "group no.";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";
		$columnnames[4] = "phase";
			$columnheader[4] = "phase";
			$fieldtype[4] = "text";
			$fieldlength[4] = "10";
			$fieldsize[4] = "8";
			$fieldcolumnwidth[4] = "80";


		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left: 0px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[1] = "fielddata.grouplogareas";
		$subkeyidname[1] = "groupnumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left: 230px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[2] = "fielddata.grouplogsupervisors";
		$subkeyidname[2] = "groupnumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "supervisor";
			$subcolumnheader[2][1] = "supervisor(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[2][1] = "5";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left: 500px; top:180px; width:300px; height:260px; z-index:6; overflow: auto";
		$subtablename[3] = "fielddata.grouplogfeatures";
		$subkeyidname[3] = "groupnumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "featurenumber";
			$subcolumnheader[3][1] = "feature(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[3][1] = "6";
			$subfieldcolumnwidth[3][1] = "100";



		$query = "SELECT grouplog.oid, grouplog.groupnumber, grouplog.date, grouplog.description, grouplog.phase
					FROM fielddata.grouplog WHERE grouplog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		$editquery = "SELECT grouplog.groupnumber, grouplog.date, grouplog.description, grouplog.phase FROM fielddata.grouplog WHERE grouplog.valid=true";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 5;
		$outputcolumn[2]= 6;
		$outputcolumn[3]= 2;
		$outputcolumn[4]= 3;
		$outputcolumn[5]= 7;
		$outputcolumn[6]= 4;


		$keynumberofcolumns = 3;

		$keycolumn[1] = 1;
		$keyquery[1] = "SELECT grouplogareas.area as \"area(s)\" FROM fielddata.grouplogareas WHERE grouplogareas.valid=true";
		$keysort[1] = "grouplogareas.area";
		$keycolumn[2] = 1;
		$keyquery[2] = "SELECT grouplogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.grouplogsupervisors WHERE grouplogsupervisors.valid=true";
		$keysort[2] = "grouplogsupervisors.supervisor";
		$keycolumn[3] = 1;
		$keyquery[3] = "SELECT grouplogfeatures.featurenumber as \"feature(s)\" FROM fielddata.grouplogfeatures WHERE grouplogfeatures.valid=true";
		$keysort[3] = "grouplogfeatures.featurenumber";

		$keyeditnumberofcolumns = 3;
		$keyeditcolumn[1] = 0;
		$keyeditcolumn[2] = 0;
		$keyeditcolumn[3] = 0;


		$keyeditquery[1] = "SELECT grouplogareas.area FROM fielddata.grouplogareas WHERE grouplogareas.valid=true";
		$keyeditquery[2] = "SELECT grouplogsupervisors.supervisor FROM fielddata.grouplogsupervisors WHERE grouplogsupervisors.valid=true";
		$keyeditquery[3] = "SELECT grouplogfeatures.featurenumber FROM fielddata.grouplogfeatures WHERE grouplogfeatures.valid=true";



		break;

////////// CASE EDIT DATA IMAGE COLLECTION

		case "imagecollection":

		# variables controlling the data input

		$tablename = "fielddata.imagecollection";
		$keyidname = "imagecollection.photoid";
		$tablewidth = 760;
		$columns = 15;
		$columnnames[1] = "imagenumber";
			$columnheader[1] = "number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "6";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "40";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "facing";
			$columnheader[4] = "facing";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listdirections.direction FROM fielddata.listdirections WHERE listdirections.valid=true ORDER BY listdirections.direction;";
			$fieldlength[4] = "7";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "photographer";
			$columnheader[5] = "photographer";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[5] = "5";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "cdnumber";
			$columnheader[6] = "cd number";
			$fieldtype[6] = "text";
			$fieldlength[6] = "3";
			$fieldsize[6] = "2";
			$fieldcolumnwidth[6] = "50";
		$columnnames[7] = "slideboxnumber";
			$columnheader[7] = "slide box no";
			$fieldtype[7] = "text";
			$fieldlength[7] = "3";
			$fieldsize[7] = "2";
			$fieldcolumnwidth[7] = "50";
		$columnnames[8] = "slideprimaryheading";
			$columnheader[8] = "primary heading";
			$fieldtype[8] = "text";
			$fieldlength[8] = "255";
			$fieldsize[8] = "140";
			$fieldcolumnwidth[8] = "150";
			$startnewline[8] = "yes";
		$columnnames[9] = "slidesecondaryheading";
			$columnheader[9] = "secondary heading";
			$fieldtype[9] = "text";
			$fieldlength[9] = "255";
			$fieldsize[9] = "140";
			$fieldcolumnwidth[9] = "150";
			$startnewline[9] = "yes";
		$columnnames[10] = "slidetertiaryheading";
			$columnheader[10] = "tertiary heading";
			$fieldtype[10] = "text";
			$fieldlength[10] = "255";
			$fieldsize[10] = "140";
			$fieldcolumnwidth[10] = "150";
			$startnewline[10] = "yes";
		$columnnames[11] = "lectureslide";
			$columnheader[11] = "lecture slide";
			$fieldtype[11] = "dropdown";
			$dropdownsql[11] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[11] = "4";
			$fieldcolumnwidth[11] = "30";
			$defaultvalue[11] = "no";
			$startnewline[11] = "yes";
		$columnnames[12] = "year";
			$columnheader[12] = "year";
			$fieldtype[12] = "text";
			$fieldlength[12] = "5";
			$fieldsize[12] = "4";
			$fieldcolumnwidth[12] = "50";
		$columnnames[13] = "photoregister";
			$columnheader[13] = "photo register";
			$fieldtype[13] = "text";
			$fieldlength[13] = "20";
			$fieldsize[13] = "20";
			$fieldcolumnwidth[13] = "80";
		$columnnames[14] = "phototype";
			$columnheader[14] = "phototype";
			$fieldtype[14] = "text";
			$fieldlength[14] = "20";
			$fieldsize[14] = "15";
			$fieldcolumnwidth[14] = "80";
		$columnnames[15] = "notes";
			$columnheader[15] = "notes";
			$fieldtype[15] = "text";
			$fieldlength[15] = "255";
			$fieldsize[15] = "60";
			$fieldcolumnwidth[15] = "110";

		$subtables = "5";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:250px; top:460px; width:220px; height:120px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.photologsquares";
		$subkeyidname[1] = "photoid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:500px; top:460px; width:220px; height:120px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.photologfeatures";
		$subkeyidname[2] = "photoid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "featurenumber";
			$subcolumnheader[2][1] = "feature(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[2][1] = "6";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:0px; top:600px; width:280px; height:120px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.photologspecialists";
		$subkeyidname[3] = "photoid";
		$subtablewidth[3] = 220;
		$subcolumns[3] = "2";
		$subcolumnnames[3][1] = "specialistcategory";
			$subcolumnheader[3][1] = "specialist category";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listspecialistcategories.specialistcategory FROM fielddata.listspecialistcategories WHERE listspecialistcategories.valid=true ORDER BY listspecialistcategories.specialistcategory;";
			$subfieldlength[3][1] = "7";
			$subfieldcolumnwidth[3][1] = "80";
		$subcolumnnames[3][2] = "specialistid";
			$subcolumnheader[3][2] = "specialist id";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = "20";
			$subfieldsize[3][2] = "14";
			$subfieldcolumnwidth[3][2] = "110";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:460px; width:220px; height:120px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.photologareas";
		$subkeyidname[4] = "photoid";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "1";
		$subcolumnnames[4][1] = "area";
			$subcolumnheader[4][1] = "area(s)";
			$subfieldtype[4][1] = "dropdown";
			$subdropdownsql[4][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "80";

		$subdivid[5] = "layer7";
		$subdivstyle[5] = "position:absolute; left:300px; top:600px; width:250px; height:120px; z-index:6; overflow: auto";
		$subtablename[5] = "fielddata.imagecollectionsources";
		$subkeyidname[5] = "photoid";
		$subtablewidth[5] = 250;
		$subcolumns[5] = "1";
		$subcolumnnames[5][1] = "sourcetitle";
			$subcolumnheader[5][1] = "source title";
			$subfieldtype[5][1] = "dropdown";
			$subdropdownsql[5][1] = "SELECT DISTINCT listsources.sourcetitle FROM fielddata.listsources WHERE listsources.valid=true ORDER BY listsources.sourcetitle;";
			$subfieldlength[5][1] = "15";
			$subfieldcolumnwidth[5][1] = "120";


		# variables to view recent entries

		$query = "select imagecollection.oid, imagecollection.photoid, imagecollection.imagenumber AS \"number\", imagecollection.date, imagecollection.description, imagecollection.facing, imagecollection.photographer, imagecollection.cdnumber AS \"cd number\", imagecollection.slideboxnumber AS \"slide box no\", imagecollection.slideprimaryheading AS \"primary heading\", imagecollection.slidesecondaryheading AS \"secondary heading\", imagecollection.slidetertiaryheading AS \"tertiary heading\", imagecollection.lectureslide AS \"lecture slide\", imagecollection.photoregister AS \"photo register\", imagecollection.year, imagecollection.notes, imagecollection.phototype
			from fielddata.imagecollection where imagecollection.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 20;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 20;
		$outputcolumn[2]= 17;
		$outputcolumn[3]= 18;
		$outputcolumn[4]= 3;
		$outputcolumn[5]= 4;
		$outputcolumn[6]= 5;
		$outputcolumn[7]= 6;
		$outputcolumn[8]= 7;
		$outputcolumn[9]= 19;
		$outputcolumn[10]= 8;
		$outputcolumn[11]= 9;
		$outputcolumn[12]= 10;
		$outputcolumn[13]= 11;
		$outputcolumn[14]= 12;
		$outputcolumn[15]= 13;
		$outputcolumn[16]= 14;
		$outputcolumn[17]= 15;
		$outputcolumn[18]= 16;
		$outputcolumn[19]= 21;


		$editquery = "select imagecollection.imagenumber, imagecollection.date, imagecollection.description, imagecollection.facing, imagecollection.photographer, imagecollection.cdnumber, imagecollection.slideboxnumber, imagecollection.slideprimaryheading, imagecollection.slidesecondaryheading, imagecollection.slidetertiaryheading, imagecollection.lectureslide, imagecollection.year, imagecollection.photoregister, imagecollection.phototype, imagecollection.notes, imagecollection.photoid
			from fielddata.imagecollection where imagecollection.valid=true";

		$keynumberofcolumns = 5;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keycolumn[3] = 1;
		$keycolumn[4] = 1;
		$keycolumn[5] = 1;
		$keyquery[1] = "select photologsquares.squarename AS \"square(s)\" from fielddata.photologsquares where photologsquares.valid=true";
		$keyquery[2] = "select photologfeatures.featurenumber AS \"feature(s)\" from fielddata.photologfeatures where photologfeatures.valid=true";
		$keyquery[3] = "select (CASE WHEN photologspecialists.specialistcategory IS NULL THEN '' WHEN photologspecialists.specialistcategory IS NOT NULL THEN photologspecialists.specialistcategory END) || ': ' || (CASE WHEN photologspecialists.specialistid IS NULL THEN '' WHEN photologspecialists.specialistid IS NOT NULL THEN photologspecialists.specialistid END) AS \"specialist record(s)\" from fielddata.photologspecialists where photologspecialists.valid=true";
		$keyquery[4] = "select photologareas.area AS \"area(s)\" from fielddata.photologareas where photologareas.valid=true";
		$keyquery[5] = "select imagecollectionsources.sourcetitle AS \"source title(s)\" from fielddata.imagecollectionsources where imagecollectionsources.valid=true";
		$keysort[1] = "photologsquares.squarename";
		$keysort[2] = "photologfeatures.featurenumber";
		$keysort[3] = "photologspecialists.specialistcategory";
		$keysort[4] = "photologareas.area";
		$keysort[5] = "imagecollectionsources.sourcetitle";

		$keyeditnumberofcolumns = 5;
		$keyeditcolumn[1] = 15;
		$keyeditcolumn[2] = 15;
		$keyeditcolumn[3] = 15;
		$keyeditcolumn[4] = 15;
		$keyeditcolumn[5] = 15;
		$keyeditquery[1] = "select photologsquares.squarename from fielddata.photologsquares where photologsquares.valid=true";
		$keyeditquery[2] = "select photologfeatures.featurenumber from fielddata.photologfeatures where photologfeatures.valid=true";
		$keyeditquery[3] = "select photologspecialists.specialistcategory, photologspecialists.specialistid from fielddata.photologspecialists where photologspecialists.valid=true";
		$keyeditquery[4] = "select photologareas.area from fielddata.photologareas where photologareas.valid=true";
		$keyeditquery[5] = "select imagecollectionsources.sourcetitle from fielddata.imagecollectionsources where imagecollectionsources.valid=true";

		if ($editline)
		{
			# add button for viewing photo of edit

			@$imagestat = pg_exec($dbh, "SELECT imagecollection.imagenumber FROM fielddata.imagecollection WHERE imagecollection.oid=$editline;");
			@$imagedata = pg_fetch_row($imagestat, 0);
			$imagenumberedit=$imagedata[0];

			if ($imagenumberedit!='')
			{
				$custombutton='yes';
				$custombuttonform='<form name="viewimageform" action="moduleviewdigitals.php?imagenumber='.$imagenumberedit.'" method="POST" target="_blank"><td align="center">
								<input type="submit" class="submitbutton" name="viewimage" value="view image">
								<input type="hidden" name="0" value="0"></td></form>';
			}
		}
		break;


////////// CASE EDIT DATA LOCALAREAS

		case "localareas":

		# variables controlling the data input
		$tablename = "fielddata.localareas";
		$keyidname = "localareas.localareaid";
		$tablewidth = 800;
		$columns = "2";
		$columnnames[1] = "localareacode";
			$columnheader[1] = "local area code";
			$fieldtype[1] = "text";
			$fieldlength[1] = 5;
			$fieldsize[1] = 6;
			$fieldcolumnwidth[1] = 80;
		$columnnames[2] = "localareaname";
			$columnheader[2] = "local area name";
			$fieldtype[2] = "text";
			$fieldlength[2] = 50;
			$fieldsize[2] = 50;
			$fieldcolumnwidth[2] = 160;

		$subtables = 2;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.localareasexcavators";
		$subkeyidname[1] = "localareaid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = 1;
		$subcolumnnames[1][1] = "supervisor";
			$subcolumnheader[1][1] = "supervisor(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[1][1] = "5";
			$subfieldcolumnwidth[1][1] = "100";
		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:250px; top:180px; width:220px; height:260px; z-index:6; overflow: auto";
		$subtablename[2] = "fielddata.localareassquares";
		$subkeyidname[2] = "localareaid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = 1;
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";


		$query = "select localareas.oid, localareas.localareaid, localareas.localareacode AS \"local area code\", localareas.localareaname AS \"local area name\"
			from fielddata.localareas where localareas.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 4;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 5;

		$editquery = "select localareas.localareacode AS \"local area code\", localareas.localareaname AS \"local area name\", localareas.localareaid
			from fielddata.localareas where localareas.valid=true";


		$keynumberofcolumns = 2;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keyeditcolumn[1] = 2;
		$keyeditcolumn[2] = 2;
		$keyquery[1] = "SELECT localareasexcavators.supervisor AS \"supervisor(s)\" FROM fielddata.localareasexcavators WHERE localareasexcavators.valid=true";
		$keyquery[2] = "SELECT localareassquares.squarename AS \"square(s)\" FROM fielddata.localareassquares WHERE localareassquares.valid=true";
		$keysort[1] = "localareasexcavators.supervisor";
		$keysort[2] = "localareassquares.squarename";

		break;



////////// CASE EDIT DATA NOTEBOOKSCATALOG

		case "notebookscatalog":

		# variables controlling the data input

		$tablename = "fielddata.notebookscatalog";
		$keyidname = "notebookscatalog.notebookid";
		$tablewidth = 760;
		$columns = 7;
		$columnnames[1] = "notebookname";
			$columnheader[1] = "notebook name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "15";
			$fieldcolumnwidth[1] = "100";
		$columnnames[2] = "datestarted";
			$columnheader[2] = "date started";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "6";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "datecompleted";
			$columnheader[3] = "date completed";
			$fieldtype[3] = "text";
			$fieldlength[3] = "10";
			$fieldsize[3] = "6";
			$fieldcolumnwidth[3] = "50";
		$columnnames[4] = "comments";
			$columnheader[4] = "comments";
			$fieldtype[4] = "text";
			$fieldlength[4] = "80";
			$fieldsize[4] = "60";
			$fieldcolumnwidth[4] = "300";
		$columnnames[5] = "cdlocation";
			$columnheader[5] = "cd";
			$fieldtype[5] = "text";
			$fieldlength[5] = "4";
			$fieldsize[5] = "2";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "bindertype";
			$columnheader[6] = "binder type";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listbinders.bindertype FROM fielddata.listbinders WHERE listbinders.valid=true ORDER BY listbinders.bindertype;";
			$fieldlength[6] = "4";
			$fieldcolumnwidth[6] = "30";
		$columnnames[7] = "arearecordbinderlocation";
			$columnheader[7] = "binder number";
			$fieldtype[7] = "text";
			$fieldlength[7] = "4";
			$fieldsize[7] = "2";
			$fieldcolumnwidth[7] = "30";

		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.notebookscatalogareas";
		$subkeyidname[1] = "notebookid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.notebookscatalogsquares";
		$subkeyidname[2] = "notebookid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:460px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.notebookscatalogsupervisors";
		$subkeyidname[3] = "notebookid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";


		$query = "select notebookscatalog.oid, notebookscatalog.notebookid, notebookscatalog.notebookname AS \"notebook name\", notebookscatalog.datestarted AS \"date started\", notebookscatalog.datecompleted AS \"date completed\", notebookscatalog.comments, notebookscatalog.cdlocation AS \"cd\", notebookscatalog.bindertype AS \"binder type\", notebookscatalog.arearecordbinderlocation AS \"binder number\"
			from fielddata.notebookscatalog where notebookscatalog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 10;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 9;
		$outputcolumn[2]= 10;
		$outputcolumn[3]= 11;
		$outputcolumn[4]= 3;
		$outputcolumn[5]= 4;
		$outputcolumn[6]= 5;
		$outputcolumn[7]= 6;
		$outputcolumn[8]= 7;
		$outputcolumn[9]= 8;

		$editquery = "select notebookscatalog.notebookname, notebookscatalog.datestarted, notebookscatalog.datecompleted, notebookscatalog.comments, notebookscatalog.cdlocation, notebookscatalog.bindertype, notebookscatalog.arearecordbinderlocation, notebookscatalog.notebookid
			from fielddata.notebookscatalog where notebookscatalog.valid=true";

		$keynumberofcolumns = 3;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keycolumn[3] = 1;
		$keyeditcolumn[1] = 7;
		$keyeditcolumn[2] = 7;
		$keyeditcolumn[3] = 7;
		$keyquery[1] = "SELECT notebookscatalogareas.area AS \"area(s)\" FROM fielddata.notebookscatalogareas WHERE notebookscatalogareas.valid=true";
		$keyquery[2] = "SELECT notebookscatalogsquares.squarename AS \"square(s)\" FROM fielddata.notebookscatalogsquares WHERE notebookscatalogsquares.valid=true";
		$keyquery[3] = "SELECT notebookscatalogsupervisors.supervisor AS \"supervisor(s)\" FROM fielddata.notebookscatalogsupervisors WHERE notebookscatalogsupervisors.valid=true";
		$keysort[1] = "notebookscatalogareas.area";
		$keysort[2] = "notebookscatalogsquares.squarename";
		$keysort[3] = "notebookscatalogsupervisors.supervisor";

		break;




////////// CASE EDIT DATA PHOTOLOG

		case "photolog":

		# variables controlling the data input

		$tablename = "fielddata.photolog";
		$keyidname = "photolog.photoid";
		$tablewidth = 760;
		$columns = 6;
		$columnnames[1] = "imagenumber";
			$columnheader[1] = "number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "6";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "150";
			$fieldsize[3] = "40";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "facing";
			$columnheader[4] = "facing";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT DISTINCT listdirections.direction FROM fielddata.listdirections WHERE listdirections.valid=true ORDER BY listdirections.direction;";
			$fieldlength[4] = "7";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "photographer";
			$columnheader[5] = "photographer";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[5] = "5";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "cdnumber";
			$columnheader[6] = "cd number";
			$fieldtype[6] = "text";
			$fieldlength[6] = "3";
			$fieldsize[6] = "2";
			$fieldcolumnwidth[6] = "50";

		$subtables = 6;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:250px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.photologsquares";
		$subkeyidname[1] = "photoid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.photologfeatures";
		$subkeyidname[2] = "photoid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "featurenumber";
			$subcolumnheader[2][1] = "feature(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE featurelog.valid=true ORDER BY featurelog.featurenumber;";
			$subfieldlength[2][1] = "6";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:0px; top:360px; width:300px; height:160px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.photologspecialists";
		$subkeyidname[3] = "photoid";
		$subtablewidth[3] = 220;
		$subcolumns[3] = "2";
		$subcolumnnames[3][1] = "specialistcategory";
			$subcolumnheader[3][1] = "specialist category";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listspecialistcategories.specialistcategory FROM fielddata.listspecialistcategories WHERE listspecialistcategories.valid=true ORDER BY listspecialistcategories.specialistcategory;";
			$subfieldlength[3][1] = "7";
			$subfieldcolumnwidth[3][1] = "80";
		$subcolumnnames[3][2] = "specialistid";
			$subcolumnheader[3][2] = "specialist id";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = "20";
			$subfieldsize[3][2] = "14";
			$subfieldcolumnwidth[3][2] = "110";

		$subdivid[4] = "layer6";
		$subdivstyle[4] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:6; overflow: auto";
		$subtablename[4] = "fielddata.photologareas";
		$subkeyidname[4] = "photoid";
		$subtablewidth[4] = 160;
		$subcolumns[4] = "1";
		$subcolumnnames[4][1] = "area";
			$subcolumnheader[4][1] = "area(s)";
			$subfieldtype[4][1] = "dropdown";
			$subdropdownsql[4][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[4][1] = "10";
			$subfieldcolumnwidth[4][1] = "80";

		$subdivid[5] = "layer7";
		$subdivstyle[5] = "position:absolute; left:340px; top:360px; width:220px; height:160px; z-index:7; overflow: auto";
		$subtablename[5] = "fielddata.photologindex";
		$subkeyidname[5] = "photoid";
		$subtablewidth[5] = 160;
		$subcolumns[5] = "1";
		$subcolumnnames[5][1] = "indexcode";
			$subcolumnheader[5][1] = "index code";
			$subfieldtype[5][1] = "dropdown";
			$subdropdownsql[5][1] = "SELECT DISTINCT listphotoindex.indexcode FROM fielddata.listphotoindex WHERE listphotoindex.valid=true ORDER BY listphotoindex.indexcode;";
			$subfieldlength[5][1] = "10";
			$subfieldcolumnwidth[5][1] = "80";

		$subdivid[6] = "layer8";
		$subdivstyle[6] = "position:absolute; left:580px; top:360px; width:220px; height:160px; z-index:7; overflow: auto";
		$subtablename[6] = "fielddata.photologrelatedphotos";
		$subkeyidname[6] = "photoid";
		$subtablewidth[6] = 160;
		$subcolumns[6] = "1";
		$subcolumnnames[6][1] = "imagenumber";
			$subcolumnheader[6][1] = "image number";
			$subfieldtype[6][1] = "dropdown";
			$subdropdownsql[6][1] = "SELECT DISTINCT photolog.imagenumber FROM fielddata.photolog WHERE photolog.valid=true ORDER BY photolog.imagenumber;";
			$subfieldlength[6][1] = "8";
			$subfieldcolumnwidth[6][1] = "40";

		# variables to view recent entries

		$query = "select photolog.oid, photolog.photoid, photolog.imagenumber AS \"number\", photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber AS \"cd number\"
			from fielddata.photolog where photolog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 12;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 11;
		$outputcolumn[2]= 8;
		$outputcolumn[3]= 9;
		$outputcolumn[4]= 3;
		$outputcolumn[5]= 4;
		$outputcolumn[6]= 5;
		$outputcolumn[7]= 6;
		$outputcolumn[8]= 7;
		$outputcolumn[9]= 10;
		$outputcolumn[10]= 12;
		$outputcolumn[11]= 13;

		$editquery = "select photolog.imagenumber, photolog.date, photolog.description, photolog.facing, photolog.photographer, photolog.cdnumber, photolog.photoid
			from fielddata.photolog where photolog.valid=true";

		$keynumberofcolumns = 6;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keycolumn[3] = 1;
		$keycolumn[4] = 1;
		$keycolumn[5] = 1;
		$keycolumn[6] = 1;
		$keyquery[1] = "select photologsquares.squarename AS \"square(s)\" from fielddata.photologsquares where photologsquares.valid=true";
		$keyquery[2] = "select photologfeatures.featurenumber AS \"feature(s)\" from fielddata.photologfeatures where photologfeatures.valid=true";
		$keyquery[3] = "select (CASE WHEN photologspecialists.specialistcategory IS NULL THEN '' WHEN photologspecialists.specialistcategory IS NOT NULL THEN photologspecialists.specialistcategory END) || ': ' || (CASE WHEN photologspecialists.specialistid IS NULL THEN '' WHEN photologspecialists.specialistid IS NOT NULL THEN photologspecialists.specialistid END) AS \"specialist record(s)\" from fielddata.photologspecialists where photologspecialists.valid=true";
		$keyquery[4] = "select photologareas.area AS \"area(s)\" from fielddata.photologareas where photologareas.valid=true";
		$keyquery[5] = "select photologindex.indexcode AS \"index code(s)\" from fielddata.photologindex where photologindex.valid=true";
		$keyquery[6] = "select photologrelatedphotos.imagenumber AS \"related images\" from fielddata.photologrelatedphotos where photologrelatedphotos.valid=true";
		$keysort[1] = "photologsquares.squarename";
		$keysort[2] = "photologfeatures.featurenumber";
		$keysort[3] = "photologspecialists.specialistcategory";
		$keysort[4] = "photologareas.area";
		$keysort[5] = "photologindex.indexcode";
		$keysort[6] = "photologrelatedphotos.imagenumber";


		$keyeditnumberofcolumns = 6;
		$keyeditcolumn[1] = 6;
		$keyeditcolumn[2] = 6;
		$keyeditcolumn[3] = 6;
		$keyeditcolumn[4] = 6;
		$keyeditcolumn[5] = 6;
		$keyeditcolumn[6] = 6;
		$keyeditquery[1] = "select photologsquares.squarename from fielddata.photologsquares where photologsquares.valid=true";
		$keyeditquery[2] = "select photologfeatures.featurenumber from fielddata.photologfeatures where photologfeatures.valid=true";
		$keyeditquery[3] = "select photologspecialists.specialistcategory, photologspecialists.specialistid from fielddata.photologspecialists where photologspecialists.valid=true";
		$keyeditquery[4] = "select photologareas.area from fielddata.photologareas where photologareas.valid=true";
		$keyeditquery[5] = "select photologindex.indexcode from fielddata.photologindex where photologindex.valid=true";
		$keyeditquery[6] = "select photologrelatedphotos.imagenumber from fielddata.photologrelatedphotos where photologrelatedphotos.valid=true";

		if ($editline)
		{
			# add button for viewing photo of edit

			@$imagestat = pg_exec($dbh, "SELECT photolog.imagenumber FROM fielddata.photolog WHERE photolog.oid=$editline;");
			@$imagedata = pg_fetch_row($imagestat, 0);
			$imagenumberedit=$imagedata[0];

			if ($imagenumberedit!='')
			{
				$custombutton='yes';
				$custombuttonform='<form name="viewimageform" action="moduleviewdigitals.php?imagenumber='.$imagenumberedit.'" method="POST" target="_blank"><td align="center">
								<input type="submit" class="submitbutton" name="viewimage" value="view image">
								<input type="hidden" name="0" value="0"></td></form>';
			}
		}
		break;




////////// CASE EDIT DATA REASSIGNED FEATURES

		case "reassignedfeatures":

		# variables controlling the data input

		$tablename = "fielddata.reassignedfeatures";
		$columns = "3";
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "oldfeaturenumber";
			$columnheader[2] = "sample number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "25";
			$fieldsize[2] = "20";
			$fieldcolumnwidth[2] = "200";
		$columnnames[3] = "olddate";
			$columnheader[3] = "old date";
			$fieldtype[3] = "text";
			$fieldlength[3] = "10";
			$fieldsize[3] = "8";
			$fieldcolumnwidth[3] = "80";


		# variables to view recent entries

		$query = "select reassignedfeatures.oid, reassignedfeatures.featurenumber AS \"feature\", reassignedfeatures.oldfeaturenumber AS \"old feature number\", reassignedfeatures.olddate AS \"old date\"
				from fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		break;




////////// CASE EDIT DATA REPORTSCATALOG

		case "reportscatalog":

		# variables controlling the data input

		$tablename = "fielddata.reportscatalog";
		$keyidname = "reportscatalog.reportid";
		$tablewidth = 760;
		$columns = 5;
		$columnnames[1] = "reportname";
			$columnheader[1] = "report name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "42";
			$fieldcolumnwidth[1] = "240";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "6";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "reporttype";
			$columnheader[3] = "report type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listreporttypes.reporttype FROM fielddata.listreporttypes WHERE listreporttypes.valid=true ORDER BY listreporttypes.reporttype;";
			$fieldlength[3] = "10";
			$fieldcolumnwidth[3] = "100";
		$columnnames[4] = "comments";
			$columnheader[4] = "comments";
			$fieldtype[4] = "text";
			$fieldlength[4] = "80";
			$fieldsize[4] = "55";
			$fieldcolumnwidth[4] = "260";
		$columnnames[5] = "cd";
			$columnheader[5] = "CD";
			$fieldtype[5] = "text";
			$fieldlength[5] = "5";
			$fieldsize[5] = "2";
			$fieldcolumnwidth[5] = "30";

		$subtables = "3";

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.reportscatalogareas";
		$subkeyidname[1] = "reportid";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.reportscatalogsquares";
		$subkeyidname[2] = "reportid";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "squarename";
			$subcolumnheader[2][1] = "square(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[2][1] = "8";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:460px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.reportscatalogauthors";
		$subkeyidname[3] = "reportid";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "author";
			$subcolumnheader[3][1] = "author(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";


		$query = "select reportscatalog.oid, reportscatalog.reportid, reportscatalog.reportname AS \"report name\", reportscatalog.date, reportscatalog.reporttype AS \"report type\", reportscatalog.comments, reportscatalog.cd
			from fielddata.reportscatalog where reportscatalog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 8;
		$outputcolumn[0]= 2;
		$outputcolumn[1]= 7;
		$outputcolumn[2]= 8;
		$outputcolumn[3]= 9;
		$outputcolumn[4]= 3;
		$outputcolumn[5]= 4;
		$outputcolumn[6]= 5;
		$outputcolumn[7]= 6;


		$editquery = "select reportscatalog.reportname, reportscatalog.date, reportscatalog.reporttype, reportscatalog.comments, reportscatalog.cd, reportscatalog.reportid
			from fielddata.reportscatalog where reportscatalog.valid=true";

		$keynumberofcolumns = 3;
		$keycolumn[1] = 1;
		$keycolumn[2] = 1;
		$keycolumn[3] = 1;
		$keyeditcolumn[1] = 5;
		$keyeditcolumn[2] = 5;
		$keyeditcolumn[3] = 5;
		$keyquery[1] = "SELECT reportscatalogareas.area AS \"area(s)\" FROM fielddata.reportscatalogareas WHERE reportscatalogareas.valid=true";
		$keyquery[2] = "SELECT reportscatalogsquares.squarename AS \"square(s)\" FROM fielddata.reportscatalogsquares WHERE reportscatalogsquares.valid=true";
		$keyquery[3] = "SELECT reportscatalogauthors.author AS \"author(s)\" FROM fielddata.reportscatalogauthors WHERE reportscatalogauthors.valid=true";
		$keysort[1] = "reportscatalogareas.area";
		$keysort[2] = "reportscatalogsquares.squarename";
		$keysort[3] = "reportscatalogauthors.author";

		break;




////////// CASE EDIT DATA SAMPLEREGISTER

		case "sampleregister":

		# variables controlling the data input

		$tablename = "fielddata.sampleregister";
		$columns = "7";
		$columnnames[1] = "sampleprefix";
			$columnheader[1] = "season prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "6";
			$fieldcolumnwidth[1] = "80";
			$defaultvalue[1] = date('Y');
		$columnnames[2] = "samplenumber";
			$columnheader[2] = "sample number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "5";
			$fieldsize[2] = "3";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "featurenumber";
			$columnheader[3] = "feature";
			$fieldtype[3] = "text";
			$fieldlength[3] = "5";
			$fieldsize[3] = "5";
			$fieldcolumnwidth[3] = "50";
		$columnnames[4] = "bagnumber";
			$columnheader[4] = "bag";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "3";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "date";
			$columnheader[5] = "date";
			$fieldtype[5] = "text";
			$fieldlength[5] = "10";
			$fieldsize[5] = "8";
			$fieldcolumnwidth[5] = "50";
		$columnnames[6] = "sampletype";
			$columnheader[6] = "type";
			$fieldtype[6] = "dropdown";
			$dropdownsql[6] = "SELECT DISTINCT listsampletypes.sampletype FROM fielddata.listsampletypes WHERE listsampletypes.valid=true ORDER BY listsampletypes.sampletype;";
			$fieldlength[6] = "10";
			$fieldcolumnwidth[6] = "80";
		$columnnames[7] = "comments";
			$columnheader[7] = "comments";
			$fieldtype[7] = "text";
			$fieldlength[7] = "255";
			$fieldsize[7] = "40";
			$fieldcolumnwidth[7] = "200";


		# variables to view recent entries

		$query = "select sampleregister.oid, sampleregister.sampleprefix, sampleregister.samplenumber, sampleregister.featurenumber AS \"feature\", sampleregister.bagnumber AS \"bag\", sampleregister.date, sampleregister.sampletype AS \"type\", sampleregister.comments
				from fielddata.sampleregister WHERE sampleregister.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		break;



////////// CASE EDIT DATA SPACELOG

		case "spacelog":

		# variables controlling the data edit

		$tablename = "fielddata.spacelog";
		$keyidname = "spacelog.spacenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "spacenumber";
			$columnheader[1] = "space";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "3";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.spacelogsquares";
		$subkeyidname[1] = "spacenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.spacelogareas";
		$subkeyidname[2] = "spacenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.spacelogsupervisors";
		$subkeyidname[3] = "spacenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";


		$query = "SELECT spacelog.oid, spacelog.spacenumber, spacelog.date, spacelog.description
					FROM fielddata.spacelog WHERE spacelog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		$editquery = "SELECT spacelog.spacenumber, spacelog.date, spacelog.description FROM fielddata.spacelog WHERE spacelog.valid=true";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 5;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 6;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;


		$keynumberofcolumns = 3;

		$keycolumn[1] = 1;
		$keyquery[1] = "SELECT spacelogsquares.squarename as \"square(s)\" FROM fielddata.spacelogsquares WHERE spacelogsquares.valid=true";
		$keysort[1] = "spacelogsquares.squarename";
		$keycolumn[2] = 1;
		$keyquery[2] = "SELECT spacelogareas.area as \"area(s)\" FROM fielddata.spacelogareas WHERE spacelogareas.valid=true";
		$keysort[2] = "spacelogareas.area";
		$keycolumn[3] = 1;
		$keyquery[3] = "SELECT spacelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.spacelogsupervisors WHERE spacelogsupervisors.valid=true";
		$keysort[3] = "spacelogsupervisors.supervisor";


		$keyeditnumberofcolumns = 3;
		$keyeditcolumn[1] = 0;
		$keyeditcolumn[2] = 0;
		$keyeditcolumn[3] = 0;
		$keyeditquery[1] = "SELECT spacelogsquares.squarename FROM fielddata.spacelogsquares WHERE spacelogsquares.valid=true";
		$keyeditquery[2] = "SELECT spacelogareas.area FROM fielddata.spacelogareas WHERE spacelogareas.valid=true";
		$keyeditquery[3] = "SELECT spacelogsupervisors.supervisor FROM fielddata.spacelogsupervisors WHERE spacelogsupervisors.valid=true";


		break;


////////// CASE EDIT DATA structureLOG

		case "structurelog":

		# variables controlling the data edit

		$tablename = "fielddata.structurelog";
		$keyidname = "structurelog.structurenumber";
		$tablewidth = 760;
		$columns = "3";
		$columnnames[1] = "structurenumber";
			$columnheader[1] = "structure";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "date";
			$columnheader[2] = "date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "8";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "description";
			$columnheader[3] = "description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1000";
			$fieldsize[3] = "100";
			$fieldcolumnwidth[3] = "400";


		$subtables = "3";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:160px; z-index:3; overflow: auto";
		$subtablename[1] = "fielddata.structurelogsquares";
		$subkeyidname[1] = "structurenumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "squarename";
			$subcolumnheader[1][1] = "square(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdataentrysquares.squarename FROM fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true ORDER BY listdataentrysquares.squarename;";
			$subfieldlength[1][1] = "8";
			$subfieldcolumnwidth[1][1] = "100";

		$subdivid[2] = "layer5";
		$subdivstyle[2] = "position:absolute; left:230px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[2] = "fielddata.structurelogareas";
		$subkeyidname[2] = "structurenumber";
		$subtablewidth[2] = 160;
		$subcolumns[2] = "1";
		$subcolumnnames[2][1] = "area";
			$subcolumnheader[2][1] = "area(s)";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[2][1] = "10";
			$subfieldcolumnwidth[2][1] = "100";

		$subdivid[3] = "layer3";
		$subdivstyle[3] = "position:absolute; left:500px; top:180px; width:220px; height:260px; z-index:5; overflow: auto";
		$subtablename[3] = "fielddata.structurelogsupervisors";
		$subkeyidname[3] = "structurenumber";
		$subtablewidth[3] = 160;
		$subcolumns[3] = "1";
		$subcolumnnames[3][1] = "supervisor";
			$subcolumnheader[3][1] = "supervisor(s)";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$subfieldlength[3][1] = "5";
			$subfieldcolumnwidth[3][1] = "100";


		$query = "SELECT structurelog.oid, structurelog.structurenumber, structurelog.date, structurelog.description
					FROM fielddata.structurelog WHERE structurelog.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";


		$editquery = "SELECT structurelog.structurenumber, structurelog.date, structurelog.description FROM fielddata.structurelog WHERE structurelog.valid=true";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 5;
		$outputcolumn[2]= 4;
		$outputcolumn[3]= 6;
		$outputcolumn[4]= 2;
		$outputcolumn[5]= 3;


		$keynumberofcolumns = 3;

		$keycolumn[1] = 1;
		$keyquery[1] = "SELECT structurelogsquares.squarename as \"square(s)\" FROM fielddata.structurelogsquares WHERE structurelogsquares.valid=true";
		$keysort[1] = "structurelogsquares.squarename";
		$keycolumn[2] = 1;
		$keyquery[2] = "SELECT structurelogareas.area as \"area(s)\" FROM fielddata.structurelogareas WHERE structurelogareas.valid=true";
		$keysort[2] = "structurelogareas.area";
		$keycolumn[3] = 1;
		$keyquery[3] = "SELECT structurelogsupervisors.supervisor as \"supervisor(s)\" FROM fielddata.structurelogsupervisors WHERE structurelogsupervisors.valid=true";
		$keysort[3] = "structurelogsupervisors.supervisor";


		$keyeditnumberofcolumns = 3;
		$keyeditcolumn[1] = 0;
		$keyeditcolumn[2] = 0;
		$keyeditcolumn[3] = 0;
		$keyeditquery[1] = "SELECT structurelogsquares.squarename FROM fielddata.structurelogsquares WHERE structurelogsquares.valid=true";
		$keyeditquery[2] = "SELECT structurelogareas.area FROM fielddata.structurelogareas WHERE structurelogareas.valid=true";
		$keyeditquery[3] = "SELECT structurelogsupervisors.supervisor FROM fielddata.structurelogsupervisors WHERE structurelogsupervisors.valid=true";


		break;

////////// CASE EDIT DATA SYNOPTIC FEATURE FORM

		case "synopticfeatureform":

		$tablename = "fielddata.synopticfeatureform";
		$keyidname = "synopticfeatureform.featurenumber";
		$tablewidth = 760;
		$columns = 25;
		$columnnames[1] = "featurenumber";
			$columnheader[1] = "feature number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "featurecategory";
			$columnheader[2] = "D/C/A/F";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "SELECT DISTINCT listfeaturecategory.featurecategory FROM fielddata.listfeaturecategory WHERE listfeaturecategory.valid=true ORDER BY listfeaturecategory.featurecategory;";
			$fieldlength[2] = "8";
			$fieldcolumnwidth[2] = "120";
		$columnnames[3] = "featuretype";
			$columnheader[3] = "feature type";
			$fieldtype[3] = "dropdown";
			$dropdownsql[3] = "SELECT DISTINCT listfeaturetypes.featuretype FROM fielddata.listfeaturetypes WHERE listfeaturetypes.valid=true ORDER BY listfeaturetypes.featuretype;";
			$fieldlength[3] = "13";
			$fieldcolumnwidth[3] = "160";
		$columnnames[4] = "matrixgroupnumber";
			$columnheader[4] = "matrix group number";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "5";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "groupnumberclosed";
			$columnheader[5] = "group number closed";
			$fieldtype[5] = "dropdown";
			$dropdownsql[5] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[5] = "4";
			$fieldcolumnwidth[5] = "30";
		$columnnames[6] = "roomdesignations";
			$columnheader[6] = "room designations";
			$fieldtype[6] = "text";
			$fieldlength[6] = "50";
			$fieldsize[6] = "10";
			$fieldcolumnwidth[6] = "100";
		$columnnames[7] = "spacenumber";
			$columnheader[7] = "space number";
			$fieldtype[7] = "text";
			$fieldlength[7] = "5";
			$fieldsize[7] = "5";
			$fieldcolumnwidth[7] = "50";
		$columnnames[8] = "structurenumber";
			$columnheader[8] = "structure number";
			$fieldtype[8] = "text";
			$fieldlength[8] = "5";
			$fieldsize[8] = "5";
			$fieldcolumnwidth[8] = "50";

		$columnnames[9] = "extendedfeaturedescription";
			$columnheader[9] = "extended feature description";
			$fieldtype[9]= "text";
			$fieldlength[9]= "500";
			$fieldsize[9]= "140";
			$fieldcolumnwidth[9]= "500";
			$startnewline[9] = "yes";

		$columnnames[10] = "orientation";
			$columnheader[10] = "orientation";
			$fieldtype[10] = "dropdown";
			$dropdownsql[10] = "SELECT DISTINCT listorientation.orientation FROM fielddata.listorientation WHERE listorientation.valid=true ORDER BY listorientation.orientation;";
			$fieldlength[10] = "7";
			$fieldcolumnwidth[10] = "20";
			$startnewline[10] = "yes";
		$columnnames[11] = "maxlengthqualifier";
			$columnheader[11] = "max length qualifier";
			$fieldtype[11]= "text";
			$fieldlength[11]= "1";
			$fieldsize[11]= "1";
			$fieldcolumnwidth[11]= "70";
		$columnnames[12] = "maxlength";
			$columnheader[12] = "max length (m)";
			$fieldtype[12]= "text";
			$fieldlength[12]= "5";
			$fieldsize[12]= "5";
			$fieldcolumnwidth[12]= "70";
		$columnnames[13] = "maxwidthqualifier";
			$columnheader[13] = "max width qualifier";
			$fieldtype[13]= "text";
			$fieldlength[13]= "1";
			$fieldsize[13]= "1";
			$fieldcolumnwidth[13]= "70";
		$columnnames[14] = "maxwidth";
			$columnheader[14] = "max width (m)";
			$fieldtype[14]= "text";
			$fieldlength[14]= "5";
			$fieldsize[14]= "5";
			$fieldcolumnwidth[14]= "70";
		$columnnames[15] = "maxvdqualifier";
			$columnheader[15] = "max vd qualifier";
			$fieldtype[15]= "text";
			$fieldlength[15]= "1";
			$fieldsize[15]= "1";
			$fieldcolumnwidth[15]= "70";
		$columnnames[16] = "maxvd";
			$columnheader[16] = "max vd (m)";
			$fieldtype[16]= "text";
			$fieldlength[16]= "5";
			$fieldsize[16]= "5";
			$fieldcolumnwidth[16]= "70";
		$columnnames[17] = "fullextentvisibleinplan";
			$columnheader[17] = "full extent visible in plan";
			$fieldtype[17] = "dropdown";
			$dropdownsql[17] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[17] = "4";
			$fieldcolumnwidth[17] = "60";
		$columnnames[18] = "leveltop";
			$columnheader[18] = "level top (m)";
			$fieldtype[18]= "text";
			$fieldlength[18]= "5";
			$fieldsize[18]= "5";
			$fieldcolumnwidth[18]= "50";
		$columnnames[19] = "levelbottom";
			$columnheader[19] = "level bottom (m)";
			$fieldtype[19]= "text";
			$fieldlength[19]= "5";
			$fieldsize[19]= "5";
			$fieldcolumnwidth[19]= "50";

		$columnnames[20] = "int_ext";
			$columnheader[20] = "int/ext/structural";
			$fieldtype[20] = "dropdown";
			$dropdownsql[20] = "SELECT DISTINCT listint_ext.int_ext FROM fielddata.listint_ext WHERE listint_ext.valid=true ORDER BY listint_ext.int_ext;";
			$fieldlength[20] = "8";
			$fieldcolumnwidth[20] = "50";
			$startnewline[20] = "yes";
		$columnnames[21] = "excavated";
			$columnheader[21] = "excavated";
			$fieldtype[21] = "dropdown";
			$dropdownsql[21] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[21] = "4";
			$fieldcolumnwidth[21] = "30";
		$columnnames[22] = "fullyexcavated";
			$columnheader[22] = "100% excavated";
			$fieldtype[22] = "dropdown";
			$dropdownsql[22] = "SELECT DISTINCT listyesno.yesno FROM fielddata.listyesno WHERE listyesno.valid=true ORDER BY listyesno.yesno;";
			$fieldlength[22] = "4";
			$fieldcolumnwidth[22] = "30";
		$columnnames[23] = "contaminated";
			$columnheader[23] = "risk of contamination";
			$fieldtype[23] = "dropdown";
			$dropdownsql[23] = "SELECT DISTINCT listcontamination.contamination FROM fielddata.listcontamination WHERE listcontamination.valid=true ORDER BY listcontamination.contamination;";
			$fieldlength[23] = "8";
			$fieldcolumnwidth[23] = "50";
		$columnnames[24] = "lastmodified";
			$columnheader[24] = "last modified";
			$fieldtype[24] = "text";
			$fieldlength[24] = "10";
			$fieldsize[24] = "8";
			$fieldcolumnwidth[24] = "80";
		$columnnames[25] = "excavationnote";
			$columnheader[25] = "excavation notes";
			$fieldtype[25] = "text";
			$fieldlength[25] = "500";
			$fieldsize[25] = "50";
			$fieldcolumnwidth[25] = "200";


		$subtables = 3;

		$subdivid[1] = "layer3";
		$subdivstyle[1] = "position:absolute; left:0px; top:370px; width:280px; height:200px; z-index:5; overflow: auto";
		$subtablename[1] = "fielddata.synopticfeatureformphases";
		$subkeyidname[1] = "featurenumber";
		$subtablewidth[1] = 220;
		$subcolumns[1] = 2;
		$subcolumnnames[1][1] = "seasonname";
			$subcolumnheader[1][1] = "phase season";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listdrawingseasons.seasonyear FROM fielddata.listdrawingseasons WHERE listdrawingseasons.valid=true ORDER BY listdrawingseasons.seasonyear;";
			$subfieldlength[1][1] = 7;
			$subfieldcolumnwidth[1][1] = 40;
		$subcolumnnames[1][2] = "phase";
			$subcolumnheader[1][2] = "phase number";
			$subfieldtype[1][2] = "text";
			$subfieldlength[1][2] = 6;
			$subfieldsize[1][2] = 7;
			$subfieldcolumnwidth[1][2] = 50;

		$subdivid[2] = "layer4";
		$subdivstyle[2] = "position:absolute; left:290px; top:370px; width:280px; height:200px; z-index:6; overflow: auto";
		$subtablename[2] = "fielddata.synopticfeatureformrelationships";
		$subkeyidname[2] = "featurenumber";
		$subtablewidth[2] = 220;
		$subcolumns[2] = 2;
		$subcolumnnames[2][1] = "relationshiptype";
			$subcolumnheader[2][1] = "relationship type";
			$subfieldtype[2][1] = "dropdown";
			$subdropdownsql[2][1] = "SELECT DISTINCT listrelationshiptype.relationshiptype FROM fielddata.listrelationshiptype WHERE listrelationshiptype.valid=true ORDER BY listrelationshiptype.relationshiptype;";
			$subfieldlength[2][1] = 7;
			$subfieldcolumnwidth[2][1] = 40;
		$subcolumnnames[2][2] = "relatedfeaturenumber";
			$subcolumnheader[2][2] = "feature number";
			$subfieldtype[2][2] = "text";
			$subfieldlength[2][2] = 5;
			$subfieldsize[2][2] = 7;
			$subfieldcolumnwidth[2][2] = 50;

		$subdivid[3] = "layer5";
		$subdivstyle[3] = "position:absolute; left:580px; top:370px; width:280px; height:200px; z-index:6; overflow: auto";
		$subtablename[3] = "fielddata.synopticfeatureformcutfillrelationships";
		$subkeyidname[3] = "featurenumber";
		$subtablewidth[3] = 220;
		$subcolumns[3] = 2;
		$subcolumnnames[3][1] = "relationshiptype";
			$subcolumnheader[3][1] = "cut/fill relationship type";
			$subfieldtype[3][1] = "dropdown";
			$subdropdownsql[3][1] = "SELECT DISTINCT listcutfillrelationshiptype.relationshiptype FROM fielddata.listcutfillrelationshiptype WHERE listcutfillrelationshiptype.valid=true ORDER BY listcutfillrelationshiptype.relationshiptype;";
			$subfieldlength[3][1] = 7;
			$subfieldcolumnwidth[3][1] = 40;
		$subcolumnnames[3][2] = "relatedfeaturenumber";
			$subcolumnheader[3][2] = "cut/fill feature number";
			$subfieldtype[3][2] = "text";
			$subfieldlength[3][2] = 5;
			$subfieldsize[3][2] = 7;
			$subfieldcolumnwidth[3][2] = 50;


		# variables to view recent entries
		$query ="SELECT
  oid,
  featurenumber AS feature,
  featurecategory as \"D/C/A/F\",
  featuretype as \"feature type\",
  matrixgroupnumber as \"matrix group number\",
  groupnumberclosed as \"group number closed\",
  roomdesignations as \"room designations\",
  spacenumber as \"space number\",
  structurenumber as \"structure number\",
  extendedfeaturedescription as \"extended feature description\",
  orientation as \"orientation\",
  maxlengthqualifier || maxlength as \"max length (m)\",
  maxwidthqualifier || maxwidth as \"max width (m)\",
  maxvdqualifier || maxvd as \"max vd (m)\",
  fullextentvisibleinplan as \"full extend visible in plan?\",
  leveltop as \"level top\",
  levelbottom as \"level bottom\",
  int_ext as \"internal/<br/>external/<br/>structural/<br/>other\",
  excavated as \"excavated\",
  fullyexcavated as \"fully excavated\",
  contaminated as \"risk of contamination (high/ moderate/ low/ none)\",
  lastmodified as \"last modified\",
  excavationnote as \"excavation notes\",
  featurenumber
FROM
  fielddata.synopticfeatureform
WHERE
  synopticfeatureform.valid = true
  $searchsql ORDER BY $sortsql;";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

# Define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
/* temporary index */
$idx = 0;
$outputcolumn[$idx++] = 1;
$outputcolumn[$idx++] = 35;
$outputcolumn[$idx++] = 24;
$outputcolumn[$idx++] = 25;
$outputcolumn[$idx++] = 2;
$outputcolumn[$idx++] = 3;
$outputcolumn[$idx++] = 4;
$outputcolumn[$idx++] = 5;
$outputcolumn[$idx++] = 26;
$outputcolumn[$idx++] = 6;
$outputcolumn[$idx++] = 7;
$outputcolumn[$idx++] = 8;
$outputcolumn[$idx++] = 9;
$outputcolumn[$idx++] = 10;
$outputcolumn[$idx++] = 11;
$outputcolumn[$idx++] = 12;
$outputcolumn[$idx++] = 13;
$outputcolumn[$idx++] = 14;
$outputcolumn[$idx++] = 15;
$outputcolumn[$idx++] = 16;
$outputcolumn[$idx++] = 27;
$outputcolumn[$idx++] = 28;
$outputcolumn[$idx++] = 29;
$outputcolumn[$idx++] = 32;
$outputcolumn[$idx++] = 33;
$outputcolumn[$idx++] = 34;
$outputcolumn[$idx++] = 30;
$outputcolumn[$idx++] = 31;
$outputcolumn[$idx++] = 17;
$outputcolumn[$idx++] = 18;
$outputcolumn[$idx++] = 19;
$outputcolumn[$idx++] = 20;
$outputcolumn[$idx++] = 36;
$outputcolumn[$idx++] = 37;
$outputcolumn[$idx++] = 21;
$outputcolumn[$idx++] = 22;
/* store columns count */
$outputcolumns = $idx;


$key_featurenumber = 23;

/* temporary index */
$idx = 0;
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  area as "area(s)"
from
  fielddata.featurelogareas
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'area';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  squarename as "square(s)"
from
  fielddata.featurelogsquares
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'squarename';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  seasonname || ': ' || phase as "phases"
from
  fielddata.synopticfeatureformphases
where
  valid = true
  and idfalse = 0
SQL_END;
$keysort[$idx] = 'seasonname';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is above..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'above'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is below..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'below'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is the same as..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'same as'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this deposit is the the fill of..."
from
  fielddata.synopticfeatureformcutfillrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'fill of'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this deposit is the the filled by..."
from
  fielddata.synopticfeatureformcutfillrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'filled by'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is abutting..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'abutting'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is abutted by..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'abutted by'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "this feature is contiguous with..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'contiguous with'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keyquery[$idx] = <<<SQL_END
select
  relatedfeaturenumber as "identical to..."
from
  fielddata.synopticfeatureformrelationships
where
  valid = true
  and idfalse = 0
  and relationshiptype = 'identical'
SQL_END;
$keysort[$idx] = 'relatedfeaturenumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keytargetfield[$idx] = 'df.featurenumber';
$keyquery[$idx] = <<<SQL_END
select
  case
    when length(trim(d.season)) > 0 then d.season || '-' || d.drawingnumber
    else '' || d.drawingnumber
  end as "drawing number"
from
  fielddata.drawinglog d,
  fielddata.drawinglogfeatures df
where
  d.valid = true
  and df.valid = true
  and d.idfalse = 0
  and df.idfalse = 0
  and d.drawingid = df.drawingid
SQL_END;
$keysort[$idx] = 'd.drawingnumber';
/* end of repeat */
/* repeat */
++$idx;
$keycolumn[$idx] = $key_featurenumber;
$keytargetfield[$idx] = 'pf.featurenumber';
$keyquery[$idx] = <<<SQL_END
select
  p.imagenumber as "photo number"
from
  fielddata.photolog p,
  fielddata.photologfeatures pf
where
  p.valid = true
  and pf.valid = true
  and p.idfalse = 0
  and pf.idfalse = 0
  and p.photoid = pf.photoid
SQL_END;
$keysort[$idx] = 'p.imagenumber';
/* end of repeat */
/* store columns count */
$keynumberofcolumns = $idx;



  $editquery ="SELECT
  featurenumber,
  featurecategory,
  featuretype,
  matrixgroupnumber,
  groupnumberclosed,
  roomdesignations,
  spacenumber,
  structurenumber,
  extendedfeaturedescription,
  orientation,
  maxlengthqualifier,
  maxlength,
  maxwidthqualifier,
  maxwidth,
  maxvdqualifier,
  maxvd,
  fullextentvisibleinplan,
  leveltop,
  levelbottom,
  int_ext,
  excavated,
  fullyexcavated,
  contaminated,
  lastmodified,
  excavationnote,
  featurenumber
FROM
  fielddata.synopticfeatureform
WHERE
  synopticfeatureform.valid = true";


		$keyeditnumberofcolumns = 3;
		$keyeditcolumn[1] = 25;
		$keyeditcolumn[2] = 25;
		$keyeditcolumn[3] = 25;
		$keyeditquery[1] = "select synopticfeatureformphases.seasonname, synopticfeatureformphases.phase from fielddata.synopticfeatureformphases where synopticfeatureformphases.valid=true";
		$keyeditquery[2] = "select synopticfeatureformrelationships.relationshiptype, synopticfeatureformrelationships.relatedfeaturenumber from fielddata.synopticfeatureformrelationships where synopticfeatureformrelationships.valid=true";
		$keyeditquery[3] = "select synopticfeatureformcutfillrelationships.relationshiptype, synopticfeatureformcutfillrelationships.relatedfeaturenumber from fielddata.synopticfeatureformcutfillrelationships where synopticfeatureformcutfillrelationships.valid=true";
		$keyeditsort[1] = "synopticfeatureformphases.seasonname, synopticfeatureformphases.phase";
		$keyeditsort[2] = "synopticfeatureformrelationships.relationshiptype, synopticfeatureformrelationships.relatedfeaturenumber";
		$keyeditsort[3] = "synopticfeatureformcutfillrelationships.relationshiptype, synopticfeatureformcutfillrelationships.relatedfeaturenumber";

		break;




////////// CASE EDIT DATA LISTAREAS

		case "listareas":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listareas";
		$columns = "2";
		$columnnames[1] = "area";
			$columnheader[1] = "abbreviation";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "areafullname";
			$columnheader[2] = "complete name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "50";
			$fieldsize[2] = "30";
			$fieldcolumnwidth[2] = "200";

		# variables to view recent entries

		$query = "select listareas.oid, listareas.area AS \"abbreviation\", listareas.areafullname AS \"full name\"
				from fielddata.listareas WHERE listareas.valid=true $searchsql ORDER BY listareas.area;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "area";

		break;



////////// CASE EDIT DATA LISTBAGCATEGORIES

		case "listbagcategories":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listbagcategories";
		$columns = "1";
		$columnnames[1] = "bagcategory";
			$columnheader[1] = "category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "18";
			$fieldsize[1] = "18";
			$fieldcolumnwidth[1] = "80";


		# variables to view recent entries

		$query = "select listbagcategories.oid, listbagcategories.bagcategory AS \"category\"
				from fielddata.listbagcategories WHERE listbagcategories.valid=true $searchsql ORDER BY listbagcategories.bagcategory;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "bagcategory";

		break;



////////// CASE EDIT DATA LISTBAGSEASONS

		case "listbagseasons":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listbagseasons";
		$columns = "1";
		$columnnames[1] = "season";
			$columnheader[1] = "season";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";


		# variables to view recent entries

		$query = "select listbagseasons.oid, listbagseasons.season AS \"season\"
				from fielddata.listbagseasons WHERE listbagseasons.valid=true $searchsql ORDER BY listbagseasons.season;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "season";

		break;



////////// CASE EDIT DATA LISTBINDERS

		case "listbinders":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listbinders";
		$columns = "3";
		$columnnames[1] = "bindertype";
			$columnheader[1] = "binder type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "50";
		$columnnames[2] = "bindernumber";
			$columnheader[2] = "binder number";
			$fieldtype[2] = "text";
			$fieldlength[2] = "4";
			$fieldsize[2] = "5";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "binderdescription";
			$columnheader[3] = "binder description";
			$fieldtype[3] = "text";
			$fieldlength[3] = "255";
			$fieldsize[3] = "50";
			$fieldcolumnwidth[3] = "200";

		# variables to view recent entries

		$query = "select listbinders.oid, listbinders.bindertype AS \"binder type\", listbinders.bindernumber AS \"binder number\", listbinders.binderdescription AS \"binder description\"
				from fielddata.listbinders WHERE listbinders.valid=true $searchsql ORDER BY listbinders.bindertype, listbinders.bindernumber;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "binder type";

		break;



////////// CASE EDIT DATA LISTBURIALTYPES

		case "listburialtypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listburialtypes";
		$columns = "1";
		$columnnames[1] = "burialtype";
			$columnheader[1] = "burial type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";


		# variables to view recent entries

		$query = "select listburialtypes.oid, listburialtypes.burialtype AS \"burial type\"
				from fielddata.listburialtypes WHERE listburialtypes.valid=true $searchsql ORDER BY listburialtypes.burialtype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "burial type";

		break;



////////// CASE EDIT DATA LISTDATAENTRYSQUARES

		case "listdataentrysquares":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listdataentrysquares";
		$columns = "1";
		$columnnames[1] = "squarename";
			$columnheader[1] = "square(s)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listdataentrysquares.oid, listdataentrysquares.squarename AS \"square(s)\"
				from fielddata.listdataentrysquares WHERE listdataentrysquares.valid=true $searchsql ORDER BY listdataentrysquares.squarename;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "square";

		break;


////////// CASE EDIT DATA LISTDIRECTIONS

		case "listdirections":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listdirections";
		$columns = "1";
		$columnnames[1] = "direction";
			$columnheader[1] = "direction";
			$fieldtype[1] = "text";
			$fieldlength[1] = "9";
			$fieldsize[1] = "9";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listdirections.oid, listdirections.direction AS \"direction\"
				from fielddata.listdirections WHERE listdirections.valid=true $searchsql ORDER BY listdirections.direction;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "direction";

		break;


////////// CASE EDIT DATA LISTDRAWINGSEASONS

		case "listdrawingseasons":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listdrawingseasons";
		$columns = "1";
		$columnnames[1] = "seasonyear";
			$columnheader[1] = "season";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listdrawingseasons.oid, listdrawingseasons.seasonyear AS \"season\"
				from fielddata.listdrawingseasons WHERE listdrawingseasons.valid=true $searchsql ORDER BY listdrawingseasons.seasonyear;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "season";

		break;


////////// CASE EDIT DATA LISTDRAWINGSEASONS

		case "listdrawingtypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listdrawingtypes";
		$columns = "1";
		$columnnames[1] = "drawingtype";
			$columnheader[1] = "drawing type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "20";
			$fieldsize[1] = "20";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listdrawingtypes.oid, listdrawingtypes.drawingtype AS \"drawing type\"
				from fielddata.listdrawingtypes WHERE listdrawingtypes.valid=true $searchsql ORDER BY listdrawingtypes.drawingtype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "drawingtype";

		break;


////////// CASE EDIT DATA LISTENTITYTYPES

		case "listentitytypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listentitytypes";
		$columns = "1";
		$columnnames[1] = "entitytype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "25";
			$fieldsize[1] = "25";
			$fieldcolumnwidth[1] = "80";


		# variables to view recent entries

		$query = "select listentitytypes.oid, listentitytypes.entitytype AS \"type\"
				from fielddata.listentitytypes WHERE listentitytypes.valid=true $searchsql ORDER BY listentitytypes.entitytype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "entitytype";

		break;



////////// CASE EDIT DATA LISTEXCAVATORS

		case "listexcavators":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listexcavators";
		$columns = "2";
		$columnnames[1] = "initials";
			$columnheader[1] = "initials";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "fullnames";
			$columnheader[2] = "full name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "54";
			$fieldsize[2] = "54";
			$fieldcolumnwidth[2] = "80";

		# variables to view recent entries

		$query = "select listexcavators.oid, listexcavators.initials AS \"initials\", listexcavators.fullnames AS \"full name\"
				from fielddata.listexcavators WHERE listexcavators.valid=true $searchsql ORDER BY listexcavators.initials, listexcavators.fullnames;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "initials";

		break;



////////// CASE EDIT DATA LISTEXOTICMATERIALCATEGORIES

		case "listexoticmaterialcategories":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listexoticmaterialcategories";
		$columns = "1";
		$columnnames[1] = "materialcategory";
			$columnheader[1] = "category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "25";
			$fieldsize[1] = "15";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listexoticmaterialcategories.oid, listexoticmaterialcategories.materialcategory AS \"category\"
				from fielddata.listexoticmaterialcategories WHERE listexoticmaterialcategories.valid=true $searchsql ORDER BY listexoticmaterialcategories.materialcategory;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "materialcategory";

		break;



////////// CASE EDIT DATA LISTFEATURETYPEGROUPS

		case "listfeaturetypegroups":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listfeaturetypegroups";
		$columns = "2";
		$columnnames[1] = "featuretypegroup";
			$columnheader[1] = "group";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "groupname";
			$columnheader[2] = "name";
			$fieldtype[2] = "text";
			$fieldlength[2] = "25";
			$fieldsize[2] = "25";
			$fieldcolumnwidth[2] = "80";

		# variables to view recent entries

		$query = "select listfeaturetypegroups.oid, listfeaturetypegroups.featuretypegroup AS \"group\", listfeaturetypegroups.groupname AS \"name\"
				from fielddata.listfeaturetypegroups WHERE listfeaturetypegroups.valid=true $searchsql ORDER BY listfeaturetypegroups.featuretypegroup, listfeaturetypegroups.groupname;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "featuretypegroup";

		break;



////////// CASE EDIT DATA LISTFEATURETYPES

		case "listfeaturetypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listfeaturetypes";
		$columns = "2";
		$columnnames[1] = "featuretype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "featuretypegroup";
			$columnheader[2] = "group";
			$fieldtype[2] = "dropdown";
			$dropdownsql[2] = "select listfeaturetypegroups.featuretypegroup from fielddata.listfeaturetypegroups
							where listfeaturetypegroups.valid=true order by listfeaturetypegroups.featuretypegroup;";
			$fieldlength[2] = "5";
			$fieldcolumnwidth[2] = "80";

		# variables to view recent entries

		$query = "select listfeaturetypes.oid, listfeaturetypes.featuretype AS \"type\", listfeaturetypes.featuretypegroup AS \"group\"
				from fielddata.listfeaturetypes WHERE listfeaturetypes.valid=true $searchsql ORDER BY listfeaturetypes.featuretype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "featuretype";

		break;



////////// CASE EDIT DATA LISTINT/EXT

		case "listint/ext":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listint_ext";
		$columns = "1";
		$columnnames[1] = "int_ext";
			$columnheader[1] = "int/ext";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listint_ext.oid, listint_ext.int_ext AS \"int/ext\"
					from fielddata.listint_ext WHERE listint_ext.valid=true $searchsql;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "int/ext";

		break;

////////// CASE EDIT DATA LISTLOCATIONS

		case "listlocations":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listlocations";
		$columns = "1";
		$columnnames[1] = "location";
			$columnheader[1] = "location";
			$fieldtype[1] = "text";
			$fieldlength[1] = "20";
			$fieldsize[1] = "30";
			$fieldcolumnwidth[1] = "120";

		# variables to view recent entries

		$query = "select listlocations.oid, listlocations.location
					from fielddata.listlocations WHERE listlocations.valid=true $searchsql;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "locations";
		break;

////////// CASE EDIT DATA LISTPHASES

		case "listphases":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listphases";
		$columns = "1";
		$columnnames[1] = "phase";
			$columnheader[1] = "phase";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listphases.oid, listphases.phase AS \"phase\"
				from fielddata.listphases WHERE listphases.valid=true $searchsql ORDER BY listphases.phase;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "phase";

		break;


////////// CASE EDIT DATA LISTPHOTOTYPES

		case "listphototypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listphototypes";
		$columns = "1";
		$columnnames[1] = "phototype";
			$columnheader[1] = "photo type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "10";
			$fieldsize[1] = "7";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listphototypes.oid, listphototypes.phototype AS \"photo types\"
				from fielddata.listphototypes WHERE listphototypes.valid=true $searchsql ORDER BY listphototypes.phototype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "phototype";

		break;



////////// CASE ADD DATA LISTPHOTOINDEX

		case "listphotoindex":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listphotoindex";
		$columns = 2;
		$columnnames[1] = "indexcode";
			$columnheader[1] = "index code";
			$fieldtype[1] = "text";
			$fieldlength[1] = "7";
			$fieldsize[1] = "7";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "indexdescription";
			$columnheader[2] = "index description";
			$fieldtype[2] = "text";
			$fieldlength[2] = "100";
			$fieldsize[2] = "50";
			$fieldcolumnwidth[2] = "160";

		# variables to view recent entries

		$query = "select listphotoindex.oid, listphotoindex.indexcode AS \"index code\", listphotoindex.indexdescription AS \"index description\"
				from fielddata.listphotoindex WHERE listphotoindex.valid=true $searchsql ORDER BY listphotoindex.indexcode;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "indexcode";

		break;


////////// CASE EDIT DATA LISTPORTFOLIOS

		case "listportfolios":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listportfolios";
		$keyidname = "listportfolios.portfolionumber";
		$tablewidth = 300;
		$columns = 1;
		$columnnames[1] = "portfolionumber";
			$columnheader[1] = "portfolio number";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		$subtables = "1";

		$subdivid[1] = "layer4";
		$subdivstyle[1] = "position:absolute; left:0px; top:180px; width:220px; height:260px; z-index:4; overflow: auto";
		$subtablename[1] = "fielddata.listportfolioareas";
		$subkeyidname[1] = "portfolionumber";
		$subtablewidth[1] = 160;
		$subcolumns[1] = "1";
		$subcolumnnames[1][1] = "area";
			$subcolumnheader[1][1] = "area(s)";
			$subfieldtype[1][1] = "dropdown";
			$subdropdownsql[1][1] = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			$subfieldlength[1][1] = "10";
			$subfieldcolumnwidth[1][1] = "100";

		# variables to view recent entries

		$query = "select listportfolios.oid, listportfolios.portfolionumber AS \"portfolio number\", listportfolios.portfolionumber
				from fielddata.listportfolios WHERE listportfolios.valid=true $searchsql ORDER BY listportfolios.portfolionumber;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "portfolio number";



		$editquery = "select listportfolios.portfolionumber from fielddata.listportfolios WHERE listportfolios.valid=true";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 2;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 3;

		$keynumberofcolumns = 1;

		$keycolumn[1] = 2;
		$keyquery[1] = "SELECT listportfolioareas.area as \"area(s)\" FROM fielddata.listportfolioareas WHERE listportfolioareas.valid=true";
		$keysort[1] = "listportfolioareas.area";

		$keyeditnumberofcolumns = 1;
		$keyeditcolumn[1] = 0;
		$keyeditquery[1] = "SELECT listportfolioareas.area FROM fielddata.listportfolioareas WHERE listportfolioareas.valid=true";

		break;


////////// CASE EDIT DATA LISTREPORTTYPES

		case "listreporttypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listreporttypes";
		$columns = "1";
		$columnnames[1] = "reporttype";
			$columnheader[1] = "report type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "30";
			$fieldsize[1] = "20";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listreporttypes.oid, listreporttypes.reporttype AS \"report type\"
				from fielddata.listreporttypes WHERE listreporttypes.valid=true $searchsql ORDER BY listreporttypes.reporttype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "reporttype";

		break;



////////// CASE EDIT DATA LISTSAMPLETYPES

		case "listsampletypes":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listsampletypes";
		$columns = "1";
		$columnnames[1] = "sampletype";
			$columnheader[1] = "type";
			$fieldtype[1] = "text";
			$fieldlength[1] = "16";
			$fieldsize[1] = "16";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listsampletypes.oid, listsampletypes.sampletype AS \"type\"
				from fielddata.listsampletypes WHERE listsampletypes.valid=true $searchsql ORDER BY listsampletypes.sampletype;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "sampletype";

		break;


////////// CASE EDIT DATA LISTSCALES

		case "listscales":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listscales";
		$columns = "1";
		$columnnames[1] = "scale";
			$columnheader[1] = "scale (1:X)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "5";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listscales.oid, listscales.scale AS \"scale (1:X)\"
				from fielddata.listscales WHERE listscales.valid=true $searchsql ORDER BY listscales.scale;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "scale";

		break;




////////// CASE EDIT DATA LISTSITESEASONS

		case "listsiteseasons":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';


		# variables controlling the data input

		$tablename = "fielddata.listsiteseasons";
		$columns = 3;
		$columnnames[1] = "seasonname";
			$columnheader[1] = "season name";
			$fieldtype[1] = "text";
			$fieldlength[1] = "10";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "startdate";
			$columnheader[2] = "start date";
			$fieldtype[2] = "text";
			$fieldlength[2] = "10";
			$fieldsize[2] = "7";
			$fieldcolumnwidth[2] = "50";
		$columnnames[3] = "enddate";
			$columnheader[3] = "end date";
			$fieldtype[3] = "text";
			$fieldlength[3] = "10";
			$fieldsize[3] = "7";
			$fieldcolumnwidth[3] = "50";


		# variables to view recent entries

		$query = "select listsiteseasons.oid, listsiteseasons.seasonname AS \"season name\", listsiteseasons.startdate AS \"start date\", listsiteseasons.enddate AS \"end date\"
				from fielddata.listsiteseasons WHERE listsiteseasons.valid=true $searchsql ORDER BY listsiteseasons.seasonname;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "season name";

		break;



////////// CASE EDIT DATA LISTSOURCES

		case "listsources":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listsources";
		$columns = 5;
		$columnnames[1] = "sourcetitle";
			$columnheader[1] = "source title";
			$fieldtype[1] = "text";
			$fieldlength[1] = "255";
			$fieldsize[1] = "50";
			$fieldcolumnwidth[1] = "150";
		$columnnames[2] = "author";
			$columnheader[2] = "author(s)";
			$fieldtype[2] = "text";
			$fieldlength[2] = "255";
			$fieldsize[2] = "30";
			$fieldcolumnwidth[2] = "150";
		$columnnames[3] = "publisher";
			$columnheader[3] = "publisher(s)";
			$fieldtype[3] = "text";
			$fieldlength[3] = "255";
			$fieldsize[3] = "30";
			$fieldcolumnwidth[3] = "150";
		$columnnames[4] = "year";
			$columnheader[4] = "year";
			$fieldtype[4] = "text";
			$fieldlength[4] = "5";
			$fieldsize[4] = "5";
			$fieldcolumnwidth[4] = "30";
		$columnnames[5] = "location";
			$columnheader[5] = "location";
			$fieldtype[5] = "text";
			$fieldlength[5] = "50";
			$fieldsize[5] = "30";
			$fieldcolumnwidth[5] = "150";


		# variables to view recent entries

		$query = "select listsources.oid, listsources.sourcetitle AS \"source title\", listsources.author AS \"author(s)\", listsources.publisher AS \"publisher(s)\", listsources.year, listsources.location
				from fielddata.listsources WHERE listsources.valid=true $searchsql ORDER BY listsources.sourcetitle;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "source title";

		break;



////////// CASE EDIT DATA LISTSPECIALISTCATEGORIES

		case "listspecialistcategories":

		# variables controlling the data input

		$tablename = "fielddata.listspecialistcategories";
		$columns = 1;
		$columnnames[1] = "specialistcategory";
			$columnheader[1] = "sepcialist category";
			$fieldtype[1] = "text";
			$fieldlength[1] = "18";
			$fieldsize[1] = "14";
			$fieldcolumnwidth[1] = "100";


		# variables to view recent entries

		$query = "select listspecialistcategories.oid, listspecialistcategories.specialistcategory AS \"specialist category\"
				from fielddata.listspecialistcategories WHERE listspecialistcategories.valid=true $searchsql ORDER BY listspecialistcategories.specialistcategory;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "specialist category";

		break;



////////// CASE EDIT DATA LISTSQUARES

		case "listsquares":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listsquares";
		$columns = "1";
		$columnnames[1] = "squarename";
			$columnheader[1] = "square(s)";
			$fieldtype[1] = "text";
			$fieldlength[1] = "8";
			$fieldsize[1] = "8";
			$fieldcolumnwidth[1] = "80";

		# variables to view recent entries

		$query = "select listsquares.oid, listsquares.squarename AS \"square(s)\"
				from fielddata.listsquares WHERE listsquares.valid=true $searchsql ORDER BY listsquares.squarename;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "square";

		break;



////////// CASE EDIT DATA LISTSTORAGEMEDIUMS

		case "liststoragemediums":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.liststoragemediums";
		$columns = "1";
		$columnnames[1] = "storagemedium";
			$columnheader[1] = "storage medium";
			$fieldtype[1] = "text";
			$fieldlength[1] = "5";
			$fieldsize[1] = "4";
			$fieldcolumnwidth[1] = "200";

		# variables to view recent entries

		$query = "select liststoragemediums.oid, liststoragemediums.storagemedium AS \"storage medium\"
				from fielddata.liststoragemediums WHERE liststoragemediums.valid=true $searchsql ORDER BY liststoragemediums.storagemedium;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "storagemedium";

		break;


////////// CASE ADD DATA LISTWEIGHTPREFIX

		case "listweightprefix":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listweightprefix";
		$columns = "1";
		$columnnames[1] = "weightprefix";
			$columnheader[1] = "weight prefix";
			$fieldtype[1] = "text";
			$fieldlength[1] = "1";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "200";

		# variables to view recent entries

		$query = "select listweightprefix.oid, listweightprefix.weightprefix AS \"weight prefix\"
				from fielddata.listweightprefix WHERE listweightprefix.valid=true $searchsql ORDER BY listweightprefix.weightprefix;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "weightprefix";


		break;



////////// CASE EDIT DATA LISTYESNO

		case "listyesno":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.listyesno";
		$columns = "1";
		$columnnames[1] = "yesno";
			$columnheader[1] = "yes/no";
			$fieldtype[1] = "text";
			$fieldlength[1] = "3";
			$fieldsize[1] = "3";
			$fieldcolumnwidth[1] = "50";

		# variables to view recent entries

		$query = "select listyesno.oid, listyesno.yesno AS \"yes/no\"
				from fielddata.listyesno WHERE listyesno.valid=true $searchsql ORDER BY listyesno.yesno;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "yesno";

		break;
	}

if ($useraccesslevel>=4)
{
	switch ($submenuaction)
	{

////////// CASE EDIT DATA DBUSERS

		case "authentication":

		# switch sorting AND freetext searching options off (remove sorting bar in output)
		$nosortingoptions='yes';
		$nosearchoptions='yes';

		# variables controlling the data input

		$tablename = "fielddata.authentication";
		$columns = "5";
		$columnnames[1] = "name";
			$columnheader[1] = "username";
			$fieldtype[1] = "text";
			$fieldlength[1] = "50";
			$fieldsize[1] = "10";
			$fieldcolumnwidth[1] = "80";
		$columnnames[2] = "passwd";
			$columnheader[2] = "password";
			$fieldtype[2] = "password";
			$fieldlength[2] = "50";
			$fieldsize[2] = "10";
			$fieldcolumnwidth[2] = "80";
		$columnnames[3] = "groupid";
			$columnheader[3] = "security level<br>1 = read only<br>2 = add/edit<br>3 = add/edit/delete<br>4 = superuser";
			$fieldtype[3] = "text";
			$fieldlength[3] = "1";
			$fieldsize[3] = "1";
			$fieldcolumnwidth[3] = "200";
		$columnnames[4] = "initials";
			$columnheader[4] = "initials";
			$fieldtype[4] = "dropdown";
			$dropdownsql[4] = "SELECT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			$fieldlength[4] = "5";
			$fieldcolumnwidth[4] = "50";
		$columnnames[5] = "email";
			$columnheader[5] = "e-mail";
			$fieldtype[5] = "text";
			$fieldlength[5] = "50";
			$fieldsize[5] = "30";
			$fieldcolumnwidth[5] = "120";

		# variables to view recent entries

		$query = "select authentication.oid, authentication.name AS \"username\", authentication.passwd AS \"password\", authentication.groupid AS \"security level\", authentication.initials AS \"initials\", authentication.email AS \"e-mail\"
				from fielddata.authentication
				WHERE authentication.valid=true
				$searchsql
				ORDER BY authentication.name;";

		$uservariables = "$searchuservariables";

		$pageidentifiercolumn = 1;
		$pageidentifiername = "name";

		break;
	}
}



# create headers

if ($saveastxt=='yes')
{

}
elseif ($keyidname and ($edit or $update or $delete or $addline))
{
	echo'
		<div id="Layer2" style="position:absolute; left:'.$left.'px; top:'.($top+15).'px; width:800; height:555px; z-index:2; background-color: #000000; layer-background-color: #000000; border: 1px none #000000; overflow: visible">';
}
elseif ($directedit=='yes')
{

}
else
{
	echo'
		<div id="Layer3" style="position:absolute; left:'.($left).'px; top:'.($top+15).'px; width:800px; height:555px; z-index:3; background-color: #000000; layer-background-color: #000000; border: 1px none #000000; overflow: visible">';
}


// decide which module to load

if ($tablename)
{
	if ($keyidname)
	{
		include 'moduledataeditmultiple.php';
	}
	else
	{
		include 'moduledataeditsingle.php';
	}
}
	echo' </div>';
?>