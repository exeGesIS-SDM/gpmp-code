<?php

		#define email addresses that receive info of new feedback
		$administratoremail[0]='tobias.tonner@gmx.net';
		$administratoremail[1]='nbhansen@midway.uchicago.edu';
		$administratoremail[2]='ategypt@hotmail.com';		

		#define reply button on output
		$extrabuttonheader='option';
		$extrabuttonurl=''.$sitebasefile.'?indexaction=feedback&menuaction=feedback&submenuaction=reply';
		$extrabuttonname='reply';
		$extrabuttonvariablename='chosenfeedbackid';
		$extrabuttoncolumn=0;


		#define link to replies on output
		$subrecordslinkheader='replies';
		$subrecordslinkurl=''.$sitebasefile.'?indexaction=feedback&menuaction=feedbackreplies&submenuaction=viewreplies';
		$subrecordslinktext='view';

		# check if record exists to decide if link is displayed
		$subrecordslinktable='fielddata.userfeedbackreplies';
		$subrecordslinkcolumnname='feedbackid';
		$subrecordslinkcolumnnumber=0;
		

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 4;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 3;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 4;


# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
{
	case "addnew":

	if (!$feedbacksent)
	{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

		echo'
			<table width="790" border="0">

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&feedbacksent=yes" method="POST">

		    <tr valign="bottom"> 
      			<td height="25"><p class="menuheading">
				  post feedback on the gpmp excavation database</p></td>
		    </tr>
			<tr><td class="emptyline" height="20">&nbsp;</td></tr>	
			<tr> 
     			<td class="menutext">please select the subject your feedback is concerned with:</td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>
			<tr><td>
       			<select name="subject">
			   		<option selected></option>
					<option>database data</option>
					<option>need a query</option>
					<option>web interface</option>
					<option>other</option>
				</select></td>
		    </tr>
			<tr><td class="emptyline" height="20">&nbsp;</td></tr>	
			<tr> 
     			<td class="menutext">please enter your feedback in the box provided below and press \'send feedback\' when finished:</td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>	
			<tr><td>
				<textarea class="feedback" name="feedback" cols="120" rows="10"></textarea></td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>	
			<tr><td>
				<input class="submitbutton" type="submit" name="submit" value="send feedback">
				</td>
			</tr>
		</form>
	  </table>
	</div>';
	}
	else
	{
		# add feedback
		$sql = "INSERT INTO fielddata.userfeedback (dbuserid, subject, feedback) VALUES ('".$userid."', '".$subject."', '".$feedback."');";
		@$stat = pg_exec($dbh, $sql);

		for ($i=0; $i<count($administratoremail); $i++)
		{
			$informadministrator=@mail("".$administratoremail[$i]."", "new feedback added to gpmp excavation database", "this is to inform you that the following feedback was added recently to the gpmp excavation database:\r\n\r\nSUBJECT:\r\n$subject\r\n\r\nFEEDBACK:\r\n$feedback\r\n\r\n\r\nthis message was created automatically - please do not reply to it.\r\nif you you have mistakenly received this e-mail please report this error to:\r\ntobias.tonner@gmx.net",
								"From: \"www.gpmpdb.net\" <noreply@gpmpdb.net>\r\n"
								."Reply-To: noreply@gpmpdb.net\r\n"
								."X-Mailer: PHP/" . phpversion());
		}

		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';
		
		echo'
		<table width="790" border="0">
		    <tr valign="bottom"> 
      			<td height="25"><p class="menuheading">
				  thank you for posting your feedback</p></td>
		    </tr>
			<tr><td class="emptyline" height="20">&nbsp;</td></tr>	
			<tr> 
     			<td class="menutext">your comment will appear in the \'feedback\' section and we will try to address it as soon as possible. </td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>
			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'" method="POST">
			<tr><td>
				<input class="submitbutton" type="submit" name="submit" value="return to feedback">
				</td>
			</tr>
			</form>
	  </table>
	</div>';
	}
	break;


	case "reply":

	if (!$replysent)
	{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

		echo'
			<table width="790" border="0">

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&replysent=yes" method="POST">

		    <tr valign="bottom"> 
      			<td height="25"><p class="menuheading">
				  post feedback on the gpmp excavation database</p></td>
		    </tr>
			<tr><td class="emptyline" height="20">&nbsp;</td></tr>	
			<tr> 
     			<td class="menutext">please enter your reply in the box provided below and press \'send reply\' when finished:</td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>	
			<tr><td>
				<textarea class="feedback" name="reply" cols="120" rows="10"></textarea></td>
		    </tr>
			<tr><td class="emptyline" height="10">&nbsp;</td></tr>	
			<tr><td>
				<input class="submitbutton" type="submit" name="submit" value="send reply">
				<input type="hidden" name="chosenfeedbackid" value="'.$chosenfeedbackid.'">
				</td>
			</tr>
		</form>
	  	</table>
		</div>';
	}
	else
	{
		# add reply
		$sql = "INSERT INTO fielddata.userfeedbackreplies (feedbackid, dbuserid, reply) VALUES ('".$chosenfeedbackid."', '".$userid."', '".$reply."');";
		@$stat = pg_exec($dbh, $sql);

		# read e-mail address of user and inform him/her
		$sql = "SELECT authentication.email FROM fielddata.userfeedback LEFT JOIN fielddata.authentication ON userfeedback.dbuserid=authentication.dbuserid WHERE authentication.valid=true AND userfeedback.feedbackid=$chosenfeedbackid;";
		@$stat = pg_exec($dbh, $sql);
		@$useremail = pg_fetch_row($stat, 0);

		if ($useremail[0]!='')
		{
			$informuser=@mail("".$useremail[0]."", "new reply added to gpmp excavation database", "this is to inform you that the following was replied to your feedback posted on the gpmp excavation database:\r\n\r\nREPLY:\r\n$reply\r\n\r\n\r\nthis message was created automatically - please do not reply to it.\r\nif you you have mistakenly received this e-mail please report this error to:\r\ntobias.tonner@gmx.net",
								"From: \"www.gpmpdb.net\" <noreply@gpmpdb.net>\r\n"
								."Reply-To: noreply@gpmpdb.net\r\n"
								."X-Mailer: PHP/" . phpversion());
		}
		
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

		echo'
		<table width="790" border="0">
		    <tr valign="bottom"> 
      			<td height="25"><p class="menuheading">
				  thank you for posting your reply</p></td>
		    </tr>
			<tr><td class="emptyline" height="20">&nbsp;</td></tr>
			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'" method="POST">
			<tr><td>
				<input class="submitbutton" type="submit" name="submit" value="return to feedback">
				</td>
			</tr>
			</form>
		</table>
		</div>';
	}
	break;


	case "readall":

		$query = "SELECT userfeedback.feedbackid, userfeedback.tstamp::date AS date, authentication.name as user, userfeedback.subject, userfeedback.feedback
				FROM fielddata.userfeedback LEFT JOIN fielddata.authentication ON userfeedback.dbuserid=authentication.dbuserid
				WHERE authentication.valid=true $searchsql ORDER BY $sortsql;";

		$uservariables="sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";
		
		$title = "feedback";
		$heading1 = "option:";
		$text1 = "all";
		$heading2 = "-:";
		$text2 = "-";
		$savename="all feedback";
		$norecordtext="ERROR!!!<br><br> No feedback exist in database!";
	
		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}
	break;

	case "bysubject":

		$query = "SELECT userfeedback.feedbackid, userfeedback.tstamp::date AS date, authentication.name as user, userfeedback.subject, userfeedback.feedback
				FROM fielddata.userfeedback LEFT JOIN fielddata.authentication ON userfeedback.dbuserid=authentication.dbuserid
				WHERE authentication.valid=true AND userfeedback.subject='$subject' $searchsql ORDER BY $sortsql;";

		$uservariables="subject=$subject&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "feedback";
		$heading1 = "option:";
		$text1 = "by subject";
		$heading2 = "subject:";
		$text2 = "$subject";
		$savename="feedback of subject $subject";
		$norecordtext="ERROR!!!<br><br> No feedback for this subject exists in database!";
	
		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}
	break;

}

?>