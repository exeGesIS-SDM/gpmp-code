<?php

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;

# add sort option
	
	include 'componentsortdata.php';


# add freetext search option
	
	include 'modulefreetextsearch.php';


switch ($submenuaction)
{
	case "viewreplies":

		$query = "SELECT userfeedbackreplies.tstamp::date AS date, authentication.name as user, userfeedbackreplies.reply
				FROM fielddata.userfeedbackreplies LEFT JOIN fielddata.authentication ON userfeedbackreplies.dbuserid=authentication.dbuserid
				WHERE authentication.valid=true $searchsql AND userfeedbackreplies.feedbackid=$subrecordid ORDER BY $sortsql;";

		$uservariables="sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables&subrecordid=$subrecordid";
		
		$title = "feedback";
		$heading1 = "option:";
		$text1 = "replies";
		$heading2 = "-:";
		$text2 = "-";
		$savename="feedback replies";
		$norecordtext="ERROR!!!<br><br> No feedback exist in database!";
	
		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}
	break;
}

?>