<?php

if ($submenuaction)
{

	# evaluate feature numbers for burial
	$sql = "SELECT burialfeatures.featurenumber, burialfeatures.burialtype
			FROM fielddata.burialfeatures
			WHERE burialfeatures.burialnumber=$chosenburial AND burialfeatures.valid=true
			ORDER BY burialfeatures.featurenumber;";
	@$stat = pg_exec($dbh, $sql);
	@$rows = pg_numrows($stat);

	for	($i = 0; $i < $rows; $i++)
	{
		$burialfeatures = pg_fetch_array($stat, $i);
		$burialfeaturenumber[$i] = $burialfeatures[0];
		$burialfeaturenumbertext[$i] = $burialfeatures[0]." (".$burialfeatures[1].")";
	}
	
	if ($rows>0)
	{
		$listfeatures = implode("<br>", $burialfeaturenumbertext);
	}
	
	
// start output of features of burial

echo"<div id='Layer3' style='position:absolute; left:".($left+180)."px; top:".($top+15)."px; z-index:3; background-color: #2E1D27; layer-background-color: #2E1D27; border: 1px none #000000; overflow: auto'>";


echo"
<table width='100%' border='0'>
  <tr bgcolor='#42242D'> 
    <td class='browseresultheadingyellow' valign='top' height='36' width='40%' nowrap>burial $chosenburial contains features:</td>
	<td class='browseresultheading' height='36' width='60%' nowrap>$listfeatures</td>
  </tr>
  <tr><td colspan='2' class='emptyline' height='26'>&nbsp;</td></tr>
  <tr><td class='browseresultheadingyellow' valign='top' height='26' colspan='2' nowrap>detailed feature information:</td><tr>
</table>";


for	($z = 0; $z < $rows; $z++)
{

	$chosenfeature = $burialfeaturenumber[$z];

	include 'componentquerybyfeatureschecklogsforfeature.php';

	include 'modulefeatureoutput.php';


	echo"
		<table width='100%' border='0'>
		  <tr><td class='emptyline' height='60'>&nbsp;</td></tr>
		</table>";
}

echo"</div>";
}		
?>