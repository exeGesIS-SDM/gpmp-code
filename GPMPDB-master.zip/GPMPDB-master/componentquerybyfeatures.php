<?php

if ($submenuaction)
{

include 'componentquerybyfeatureschecklogsforfeature.php';

echo"

<div id='Layer3' style='position:absolute; left:".($left+205)."px; top:".($top+15)."px; width:750px; z-index:3; background-color: #2E1D27; layer-background-color: #2E1D27; border: 1px none #000000; overflow: auto'>";


include 'modulefeatureoutput.php';


echo"</div>";
}		
?>