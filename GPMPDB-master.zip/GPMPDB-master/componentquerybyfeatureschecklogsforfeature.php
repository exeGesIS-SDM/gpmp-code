<?php

  ////// check for feature form scan

$filedownloadheader="pdf file";
$filedownloadlink="http://gpmpfiles.esdm.co.uk/featureforms";
$filedownloadextension="pdf";
echo $filedownloadlink."/".$chosenfeature.".".$filedownloadextension;
  $ret = remote_file_exists($filedownloadlink."/".$chosenfeature.".".$filedownloadextension);
  if ($ret===true)
  {
  $logoutput[1]="<a class='yellowlink' href='".$filedownloadlink."/".$chosenfeature.".".$filedownloadextension."' target='_blank'>yes</a>";
  }
  elseif ($ret===false)
  {
  $logoutput[1] = "no";
  }
  else
  {
  $logoutput[1] = "error code: ".$ret;
  }

/*$logoutput[1] = "stopped temporarily by yusuke";*/

/////// check feature log for information

$queryfeaturelog = <<<SQL_END
SELECT
  featurenumber,
  date,
  description
FROM
  fielddata.featurelog f
WHERE
  valid = true
  AND idfalse = 0
  AND featurenumber = $chosenfeature
SQL_END;

$queryfeaturelogsquares = <<<SQL_END
SELECT
  squarename
FROM
  fielddata.featurelogsquares
WHERE
  valid = true
  AND idfalse = 0
  AND featurenumber = $chosenfeature
ORDER BY
  squarename
SQL_END;

$queryfeaturelogareas = <<<SQL_END
SELECT
  area
FROM
  fielddata.featurelogareas
WHERE
  valid = true
  AND idfalse = 0
  AND featurenumber = $chosenfeature
ORDER BY
  area
SQL_END;

$queryfeaturelogsupervisors = <<<SQL_END
SELECT
  supervisor
FROM
  fielddata.featurelogsupervisors
WHERE
  valid = true
  AND idfalse = 0
  AND featurenumber = $chosenfeature
ORDER BY
  supervisor
SQL_END;

$querysynopticfeatureform = <<<SQL_END
SELECT
  featurecategory,
  featuretype,
  matrixgroupnumber,
  groupnumberclosed,
  roomdesignations,
  extendedfeaturedescription,
  orientation,
  maxlengthqualifier || maxlength,
  maxwidthqualifier || maxwidth,
  maxvd,
  leveltop,
  levelbottom,
  int_ext,
  excavated,
  fullyexcavated,
  contaminated,
  spacenumber,
  structurenumber,
  fullextentvisibleinplan,
  lastmodified,
  excavationnote
FROM
  fielddata.synopticfeatureform
WHERE
  valid = true
  AND idfalse = 0
  AND featurenumber = $chosenfeature
SQL_END;

$data_grouplog = array();
$query_grouplog = <<<SQL_END
select
  groupnumber
from
  fielddata.grouplogfeatures
where
  valid = true
  and idfalse = 0
  and featurenumber = $chosenfeature
SQL_END;


$data_phases = array();
$query_synopticfeatureform_phases = <<<SQL_END
select
  seasonname || ': ' || phase
from
  fielddata.synopticfeatureformphases
where
  valid = true
  and idfalse = 0
  and featurenumber = $chosenfeature
SQL_END;


$data_bagregister = array();
$query_bagregisters = <<<SQL_END
select
  case
    when length(trim(bagprefix)) > 0 then bagprefix || '-' || bagnumber
    else '' || bagnumber
  end as a
from
  fielddata.bagregister
where
  featurenumber = $chosenfeature
  and idfalse = 0
  and valid = true
order by
  a
SQL_END;


$data_drawinglog = array();
$query_featurelog_drawinglogs = <<<SQL_END
select
  case
    when length(trim(d.season)) > 0 then d.season || '-' || d.drawingnumber
    else '' || d.drawingnumber
  end as a
from
  fielddata.drawinglog as d,
  fielddata.drawinglogfeatures as df
where
  df.featurenumber = $chosenfeature
  and d.drawingid = df.drawingid
  and df.valid = true
  and d.valid = true
SQL_END;


$data_photolog = array();
$query_featurelog_photologs = <<<SQL_END
select
  photolog.imagenumber
from
  fielddata.photolog as photolog,
  fielddata.photologfeatures as pf
where
  pf.featurenumber = $chosenfeature
  and photolog.photoid = pf.photoid
  and pf.valid = true
  and photolog.valid = true
SQL_END;


// START new TOBI April 2009

//  synopticfeatureform_relationships
$data_synopticfeatureform_relationships = array();
$query_synopticfeatureform_relationships = <<<SQL_END
select
  synopticfeatureformrelationships.relationshiptype || ': ' || synopticfeatureformrelationships.relatedfeaturenumber as featurerelationships
from
  fielddata.synopticfeatureformrelationships
where
  synopticfeatureformrelationships.featurenumber = $chosenfeature
  and synopticfeatureformrelationships.valid = true
order by
  synopticfeatureformrelationships.relationshiptype, synopticfeatureformrelationships.relatedfeaturenumber
SQL_END;
$result = pg_query($dbh, $query_synopticfeatureform_relationships);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_synopticfeatureform_relationships[] = pg_fetch_result($result, $i, 0);
  }
}

//  synopticfeatureform_cutfillrelationships
$data_synopticfeatureform_cutfillrelationships = array();
$query_synopticfeatureform_cutfillrelationships = <<<SQL_END
select
  synopticfeatureformcutfillrelationships.relationshiptype || ': ' || synopticfeatureformcutfillrelationships.relatedfeaturenumber as featurerelationships
from
  fielddata.synopticfeatureformcutfillrelationships
where
  synopticfeatureformcutfillrelationships.featurenumber = $chosenfeature
  and synopticfeatureformcutfillrelationships.valid = true
order by
  synopticfeatureformcutfillrelationships.relationshiptype, synopticfeatureformcutfillrelationships.relatedfeaturenumber
SQL_END;
$result = pg_query($dbh, $query_synopticfeatureform_cutfillrelationships);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_synopticfeatureform_cutfillrelationships[] = pg_fetch_result($result, $i, 0);
  }
}


// END new TOBI April 2009







// creates array of featurelog fields for feature number

$result = pg_query($dbh, $queryfeaturelog);
if($result) {
  $datafeaturelog = pg_fetch_array($result);
}


// creates list of squares for feature number

$result = pg_query($dbh, $queryfeaturelogsquares);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $datafeaturelogsquares[] = pg_fetch_result($result, $i, 0);
  }
}


// creates list of areas for feature number

$result = pg_query($dbh, $queryfeaturelogareas);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $datafeaturelogareas[] = pg_result($result, $i, 0);
  }
}


// creates list of supervisors for feature number

$result = pg_query($dbh, $queryfeaturelogsupervisors);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $datafeaturelogsupervisors[] = pg_result($result, $i, 0);
  }
}


/////// check synoptic feature form for information


// creates array of featurelog fields for feature number

$result = pg_fetch_array(pg_query($dbh, $querysynopticfeatureform));
if($result) {
  $datasynopticfeatureform = array_map("stripslashes", $result);
}

$result = pg_query($dbh, $query_grouplog);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_grouplog[] = pg_fetch_result($result, $i, 0);
  }
}


$result = pg_query($dbh, $query_synopticfeatureform_phases);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_phases[] = pg_fetch_result($result, $i, 0);
  }
}



$result = pg_query($dbh, $query_bagregisters);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_bagregister[] = pg_fetch_result($result, $i, 0);
  }
}


$result = pg_query($dbh, $query_featurelog_drawinglogs);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_drawinglog[] = pg_fetch_result($result, $i, 0);
  }
}


$result = pg_query($dbh, $query_featurelog_photologs);
if($result) {
  $count = pg_numrows($result);
  for($i = 0; $i < $count; $i++) {
    $data_photolog[] = pg_fetch_result($result, $i, 0);
  }
}


/////// check all other logs for information

$numberoflogs = 20;

$logname[1] = "ff scan";
$logname[2] = "browseentitylog";
$logname[3] = "browseentitylog";
$logname[4] = "phase";
$logname[5] = "notebooks";
$logname[6] = "dsr";
$logname[7] = "ceramics";
$logname[8] = "finds";
$logname[9] = "sealings";
$logname[10] = "lithics";
$logname[11] = "botanical";
$logname[12] = "charcoal";
$logname[13] = "fauna";
$logname[14] = "burials";
$logname[15] = "browsebagregister";
$logname[16] = "browsesampleregister";
$logname[17] = "browseexoticmaterialregister";
$logname[18] = "browsedrawinglog";
$logname[19] = "browsephotolog";
$logname[20] = "surveylog";

$logsubmenuaction[2] = "browsebydeffeature";
$logsubmenuaction[3] = "browsebyinclfeature";
$logsubmenuaction[15] = "browsebyfeature";
$logsubmenuaction[16] = "browsebyfeature";
$logsubmenuaction[17] = "browsebyfeature";
$logsubmenuaction[18] = "browsebyfeature";
$logsubmenuaction[19] = "browsebyfeature";

$filedownload[18] = "no";
$includeimage[19] = "yes";

$logquery[2] = "SELECT entitylogdefinedbyfeaturenumbers.definedbyfeaturenumber FROM fielddata.entitylogdefinedbyfeaturenumbers WHERE valid=true AND definedbyfeaturenumber=$chosenfeature;";
$logquery[3] = "SELECT entitylogincludesfeaturenumbers.inclfeaturenumber FROM fielddata.entitylogincludesfeaturenumbers WHERE valid=true AND inclfeaturenumber=$chosenfeature;";
/* $logquery[4] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[5] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[6] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[7] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[8] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[9] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[10] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[11] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[12] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[13] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[14] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */
/* $logquery[15] = "SELECT bagregister.featurenumber FROM fielddata.bagregister WHERE valid=true AND featurenumber=$chosenfeature;"; */
$logquery[16] = "SELECT sampleregister.featurenumber FROM fielddata.sampleregister WHERE valid=true AND featurenumber=$chosenfeature;";
$logquery[17] = "SELECT exoticmaterialregister.featurenumber FROM fielddata.exoticmaterialregister WHERE valid=true AND featurenumber=$chosenfeature;";
/* $logquery[18] = "SELECT drawinglogfeatures.featurenumber FROM fielddata.drawinglogfeatures WHERE valid=true AND featurenumber=$chosenfeature;"; */
/* $logquery[19] = "SELECT photologfeatures.featurenumber FROM fielddata.photologfeatures WHERE valid=true AND featurenumber=$chosenfeature;"; */
/* $logquery[20] = "SELECT featurelog.featurenumber FROM fielddata.featurelog WHERE valid=true AND featurenumber=0;"; */



for ($i = 2; $i <= $numberoflogs; $i++){
  if($i == 15) {
    $logoutput[$i] = "<a class='yellowlink' href='".$sitebasefile."?action=browse&menuaction=".$logname[$i]."&submenuaction=".$logsubmenuaction[$i]."&featurenumber=$chosenfeature&includeimage=".$includeimage[$i]."&filedownload=$filedownload[$i]' target='_blank'>" . join(", ", $data_bagregister) . "</a>";
  }elseif($i == 18) {
    $logoutput[$i] = "<a class='yellowlink' href='".$sitebasefile."?action=browse&menuaction=".$logname[$i]."&submenuaction=".$logsubmenuaction[$i]."&featurenumber=$chosenfeature&includeimage=".$includeimage[$i]."&filedownload=$filedownload[$i]' target='_blank'>" . join(", ", $data_drawinglog) . "</a>";
  }elseif($i == 19) {
    $logoutput[$i] = "<a class='yellowlink' href='".$sitebasefile."?action=browse&menuaction=".$logname[$i]."&submenuaction=".$logsubmenuaction[$i]."&featurenumber=$chosenfeature&includeimage=".$includeimage[$i]."&filedownload=$filedownload[$i]' target='_blank'>" . join(", ", $data_photolog) . "</a>";
  }
  if($logoutput[$i] or $logquery[$i] == NULL) continue;

  $statlog = pg_exec($dbh, $logquery[$i]);
  $rowslog[$i] = pg_numrows($statlog);

  if ($rowslog[$i]>0 and $logsubmenuaction[$i]) {
    $logoutput[$i] = "<a class='yellowlink' href='".$sitebasefile."?action=browse&menuaction=".$logname[$i]."&submenuaction=".$logsubmenuaction[$i]."&featurenumber=$chosenfeature&includeimage=".$includeimage[$i]."&filedownload=$filedownload[$i]' target='_blank'>yes</a>";
  } elseif ($rowslog[$i]>0) {
    $logoutput[$i] = "yes";
  } else {
    $logoutput[$i] = "no";
  }
}

?>