<?php


////////// CASE FEATURELOG FOR AREA DEFINITION

		if ($submenuaction=="dsrfeaturelog")
		{
			include 'componentbrowsefeaturelog.php';
		}
		
////////// CASE BAGREGISTER FOR AREA DEFINITION

		elseif ($submenuaction=="dsrbagregister")
		{
			include 'componentbrowsebagregister.php';
		}
		
////////// CASE SYNOPTICS FOR AREA DEFINITION

		elseif ($submenuaction=="dsrsynopticfeatureform")
		{
			include 'componentbrowsesynopticfeatureform.php';
		}		
		
////////// CASE DRAWINGLOG FOR AREA DEFINITION

		elseif ($submenuaction=="dsrdrawinglog")
		{
			include 'componentbrowsedrawinglog.php';
		}	

////////// CASE EXOTICS FOR AREA DEFINITION

		elseif ($submenuaction=="dsrexoticmaterialregister")
		{
			include 'componentbrowseexoticmaterialregister.php';
		}

////////// CASE PHOTOLOG FOR AREA DEFINITION

		elseif ($submenuaction=="dsrphotolog")
		{
			include 'componentbrowsephotolog.php';
		}
		
////////// CASE NOTEBOOKS FOR AREA DEFINITION

		elseif ($submenuaction=="dsrnotebookscatalog")
		{
			include 'componentbrowsenotebookscatalog.php';
		}		

////////// CASE SAMPLES FOR AREA DEFINITION

		elseif ($submenuaction=="dsrsampleregister")
		{
			include 'componentbrowsesampleregister.php';
		}		

////////// CASE REPORTS FOR AREA DEFINITION

		elseif ($submenuaction=="dsrreportscatalog")
		{
			include 'componentbrowsereportscatalog.php';
		}		
?>