<?php

switch ($submenuaction)
	{
		case "":
		break;



////////// CASE FEATURES BY AREA AND THEIR DRAWINGS

		case "areafeaturedrawing":


		# define sort columns
		$sortcolumn[1] = "featurelog.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "featureareas.area";
		$sortcolumndisplay[2] = "area";
		$sortcolumn[3] = "drawings.season, drawings.drawingnumber";
		$sortcolumndisplay[3] = "drawing";

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "featureareas.area";
				$pageidentifiername = "area";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "area";
		}

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "SELECT featureareas.area, featurelog.featurenumber AS feature,
					(CASE WHEN drawings.season IS NULL THEN '' WHEN drawings.season IS NOT NULL THEN drawings.season END) || '-' || (CASE WHEN drawings.drawingnumber IS NULL THEN '0' WHEN drawings.drawingnumber IS NOT NULL THEN drawings.drawingnumber END) AS drawing
					FROM (((fielddata.featurelog
					LEFT JOIN (SELECT * FROM fielddata.featurelogareas WHERE featurelogareas.valid=true) AS featureareas ON featurelog.featurenumber=featureareas.featurenumber)
					LEFT JOIN (SELECT * FROM fielddata.drawinglogfeatures WHERE drawinglogfeatures.valid=true) AS drawingfeatures ON featurelog.featurenumber=drawingfeatures.featurenumber)
					LEFT JOIN (SELECT * FROM fielddata.drawinglog WHERE drawinglog.valid=true) AS drawings ON drawingfeatures.drawingid=drawings.drawingid)
					WHERE featurelog.valid=true
					$searchsql
					ORDER BY $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;


		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse features by area with their drawings";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="features by area with their drawings";
		$norecordtext="ERROR!!!<br><br> No feature exist in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;


////////// CASE FEATURES BY SQUARE AND THEIR DRAWINGS

		case "squarefeaturedrawing":


		# define sort columns
		$sortcolumn[1] = "featurelog.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "featurelogsquares.squarename";
		$sortcolumndisplay[2] = "square";
		$sortcolumn[3] = "drawings.season, drawings.drawingnumber";
		$sortcolumndisplay[3] = "drawing";
		$sortcolumn[4] = "featurelog.description";
		$sortcolumndisplay[4] = "description";
		$sortcolumn[5] = "synoptics.featuretype";
		$sortcolumndisplay[5] = "type";

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "featurelogsquares.squarename";
				$pageidentifiername = "square";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "square";
		}

# add freetext search option

	include 'modulefreetextsearch.php';



		$query = "SELECT featurelogsquares.squarename as square, featurelog.featurenumber AS feature,
					(CASE WHEN drawings.season IS NULL THEN '' WHEN drawings.season IS NOT NULL THEN drawings.season END) || '-' || (CASE WHEN drawings.drawingnumber IS NULL THEN '0' WHEN drawings.drawingnumber IS NOT NULL THEN drawings.drawingnumber END) AS drawing,
					featurelog.description, synoptics.featuretype AS type, featurelog.featurenumber
					FROM ((((fielddata.featurelog
					LEFT JOIN (SELECT * FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true) AS featurelogsquares ON featurelog.featurenumber=featurelogsquares.featurenumber)
					LEFT JOIN (SELECT * FROM fielddata.drawinglogfeatures WHERE drawinglogfeatures.valid=true) AS drawingfeatures ON featurelog.featurenumber=drawingfeatures.featurenumber)
					LEFT JOIN (SELECT * FROM fielddata.drawinglog WHERE drawinglog.valid=true) AS drawings ON drawingfeatures.drawingid=drawings.drawingid)
					LEFT JOIN (SELECT * FROM fielddata.synopticfeatureform WHERE synopticfeatureform.valid=true) AS synoptics ON featurelog.featurenumber=synoptics.featurenumber)
					WHERE featurelog.valid=true
					$searchsql
					ORDER BY $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 6;

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse features by square with their drawings";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="features by square with their drawings";
		$norecordtext="ERROR!!!<br><br> No feature exist in database!";


		$keynumberofcolumns = 1;
		$keycolumn[1] = 5;
		$keyquery[1] = "SELECT featurelogareas.area AS \"area(s)\" FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keysort[1] = "featurelogareas.area";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;



		////////// CASE CONTENT OF CDs (drawings, notebooks, photos)

		case "cdcontents":

# sort options
	include 'componentsortdata.php';

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "SELECT cdinventory.storagemedium AS \"storage medium\", cdinventory.number, cdinventory.contents,
						CASE WHEN cdinventory.giza='t' THEN 'yes' WHEN cdinventory.giza='f' THEN 'no' END AS \"in Giza\",
						CASE WHEN cdinventory.boston='t' THEN 'yes' WHEN cdinventory.boston='f' THEN 'no' END AS \"in Boston\",
						CASE WHEN cdinventory.newyork='t' THEN 'yes' WHEN cdinventory.newyork='f' THEN 'no' END AS \"in New York\"
						from fielddata.cdinventory WHERE cdinventory.valid=true
						$searchsql
						order by $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 9;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		$outputcolumn[8]= 8;

		$keynumberofcolumns = 3;
		$keycolumn[1] = 1;
		$keytargetfield[1]="cd";
		$keyquery[1] = "SELECT (CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS \"drawing(s)\" FROM fielddata.drawinglog WHERE drawinglog.valid=true";
		$keysort[1] = "drawinglog.season, drawinglog.drawingnumber";
		$keycolumn[2] = 1;
		$keytargetfield[2]="cdlocation";
		$keyquery[2] = "SELECT notebookscatalog.notebookname as \"notebook name(s)\" FROM fielddata.notebookscatalog WHERE notebookscatalog.valid=true";
		$keysort[2] = "notebookscatalog.notebookname";
		$keycolumn[3] = 1;
		$keytargetfield[3]="cdnumber";
		$keyquery[3] = "SELECT photolog.imagenumber as \"image(s)\" FROM fielddata.photolog WHERE photolog.valid=true";
		$keysort[3] = "photolog.imagenumber";


		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "cdinventory with drawings, notebooks and photos";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="cdinventory with drawings notebooks photos";
		$norecordtext="ERROR!!!<br><br> No cdinventory entries exist in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;





	////////// CASE CONTENT OF DUPLICATE DRAWINGS

		case "duplicatedrawings":

# sort options
	include 'componentsortdata.php';

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select drawinglog.season, drawinglog.drawingnumber, count (drawinglog.season)
				FROM fielddata.drawinglog
				WHERE drawinglog.valid=true
				GROUP BY drawinglog.season, drawinglog.drawingnumber
				HAVING Count(drawinglog.season)>1;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;


		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "duplicate drawings";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="duplicate drawings";
		$norecordtext="ERROR!!!<br><br> No duplicate drawings exist in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;









				////////// CASE CONTENT OF PORTFOLIOS (drawings)

		case "portfoliocontents":

# sort options
	include 'componentsortdata.php';

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "SELECT listportfolios.portfolionumber AS \"portfolio number\", listportfolios.area
						FROM fielddata.listportfolios WHERE listportfolios.valid=true
						$searchsql
						ORDER BY $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;


		$keynumberofcolumns = 1;
		$keycolumn[1] = 0;
		$keytargetfield[1]="portfolionumber";
		$keyquery[1] = "SELECT (CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END) AS \"drawing(s)\" FROM fielddata.drawinglog WHERE drawinglog.valid=true";
		$keysort[1] = "drawinglog.season, drawinglog.drawingnumber";

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "portfolios with drawings";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="portfolios with drawings";
		$norecordtext="ERROR!!!<br><br> No portfolios exist in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;






////////// CASE BAGREGISTER WITH SEASONS

		case "bagregisterandseasons":


		# define sort columns
		$sortcolumn[1] = "bagregister.bagprefix, bagregister.bagnumber";
		$sortcolumndisplay[1] = "bag";
		$sortcolumn[2] = "bagregister.featurenumber";
		$sortcolumndisplay[2] = "feature";
		$sortcolumn[3] = "bagregister.date";
		$sortcolumndisplay[3] = "date";
		$sortcolumn[4] = "bagregister.category";
		$sortcolumndisplay[4] = "category";
		$sortcolumn[5] = "bagregister.comments";
		$sortcolumndisplay[5] = "comments";
		$sortcolumn[6] = "listsiteseasons.seasonname";
		$sortcolumndisplay[6] = "site season";

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "bagregister.bagprefix, bagregister.bagnumber";
				$pageidentifiername = "bag";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "bag";
		}

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select (CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END) AS bag, bagregister.featurenumber AS feature, bagregister.date, bagregister.category, bagregister.comments, listsiteseasons.seasonname AS \"site season\", bagregister.bagprefix, bagregister.bagnumber, cast((to_char(bagregister.featurenumber, 'FM09999') || to_char(bagregister.bagnumber, 'FM09999')) AS text) AS \"johns super ID\"
				from fielddata.bagregister, fielddata.listsiteseasons
				where bagregister.valid=true AND listsiteseasons.valid=true AND (bagregister.date>=listsiteseasons.startdate AND bagregister.date<=listsiteseasons.enddate)
				$searchsql
				order by $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 9;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;
		$outputcolumn[3]= 3;
		$outputcolumn[4]= 4;
		$outputcolumn[5]= 5;
		$outputcolumn[6]= 6;
		$outputcolumn[7]= 7;
		$outputcolumn[8]= 8;

		$uservariables = "sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "bagregister with site seasons";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "-";
		$text2 = "-";
		$savename="bagregister with site seasons";
		$norecordtext="ERROR!!!<br><br> No bags matching site seasons exist in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;





////////// CASE FEATURELOG AND SYNOPTICS BY SQUARE

		case "featurelogandsynopticsbysquare":


		# define sort columns
		$sortcolumn[1] = "featurelog.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "featurelog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "featurelog.description";
		$sortcolumndisplay[3] = "description";
		$sortcolumn[4] = "synopticfeatureform.phase";
		$sortcolumndisplay[4] = "phase";
		$sortcolumn[5] = "synopticfeatureform.matrixgroupnumber";
		$sortcolumndisplay[5] = "matrix group";
		$sortcolumn[6] = "synopticfeatureform.featuretype";
		$sortcolumndisplay[6] = "type";
		$sortcolumn[7] = "synopticfeatureform.int_ext";
		$sortcolumndisplay[7] = "int/ext";
		$sortcolumn[8] = "synopticfeatureform.contaminated";
		$sortcolumndisplay[8] = "contaminated";
		$sortcolumn[9] = "synopticfeatureform.insitu";
		$sortcolumndisplay[9] = "insitu";
		$sortcolumn[10] = "synopticfeatureform.fullyexcavated";
		$sortcolumndisplay[10] = "fully excavated";
		$sortcolumn[11] = "synopticfeatureform.entrycomplete";
		$sortcolumndisplay[11] = "entry complete";

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "featurelog.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}

# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select featurelog.featurenumber AS feature, featurelog.date, featurelog.description,
				synopticfeatureform.phase, synopticfeatureform.matrixgroupnumber AS \"matrix group\", synopticfeatureform.featuretype AS \"type\", synopticfeatureform.int_ext as \"int/ext\", synopticfeatureform.contaminated, synopticfeatureform.insitu, synopticfeatureform.fullyexcavated AS \"fully excavated\", CASE WHEN synopticfeatureform.entrycomplete='t' THEN 'yes' WHEN synopticfeatureform.entrycomplete='f' THEN 'no' END AS \"entry complete\",
				featurelog.featurenumber
				from (fielddata.featurelog left join fielddata.featurelogsquares on featurelog.featurenumber = featurelogsquares.featurenumber) left join fielddata.synopticfeatureform on featurelog.featurenumber = synopticfeatureform.featurenumber
				where featurelogsquares.squarename = '$squarename' AND featurelog.valid=true AND featurelog.featurenumber <> 7600 AND featurelog.featurenumber <> 8176
				$searchsql
				order by $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 16;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 14;
		$outputcolumn[3]= 13;
		$outputcolumn[4]= 12;
		$outputcolumn[5]= 2;
		$outputcolumn[6]= 15;
		$outputcolumn[7]= 16;
		$outputcolumn[8]= 3;
		$outputcolumn[9]= 4;
		$outputcolumn[10]= 5;
		$outputcolumn[11]= 6;
		$outputcolumn[12]= 7;
		$outputcolumn[13]= 8;
		$outputcolumn[14]= 9;
		$outputcolumn[15]= 10;


		$keynumberofcolumns = 5;
		$keycolumn[1] = 11;
		$keyquery[1] = "SELECT featurelogsupervisors.supervisor AS \"supervisor(s)\" FROM fielddata.featurelogsupervisors WHERE featurelogsupervisors.valid=true";
		$keysort[1] = "featurelogsupervisors.supervisor";
		$keycolumn[2] = 11;
		$keyquery[2] = "SELECT featurelogareas.area AS \"area(s)\" FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keysort[2] = "featurelogareas.area";
		$keycolumn[3] = 11;
		$keyquery[3] = "SELECT featurelogsquares.squarename AS \"square(s)\" FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keysort[3] = "featurelogsquares.squarename";
		$keycolumn[4] = 11;
		$keyquery[4] = "SELECT reassignedfeatures.oldfeaturenumber AS \"old feature number\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[4] = "reassignedfeatures.oldfeaturenumber";
		$keycolumn[5] = 11;
		$keyquery[5] = "SELECT reassignedfeatures.olddate as \"old date\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[5] = "reassignedfeatures.oldfeaturenumber";


		$uservariables = "squarename=$squarename&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log and synoptic feature form";
		$heading1 = "option:";
		$text1 = "by square";
		$heading2 = "square:";
		$text2 = "$squarename";
		$savename="features from square $squarename from featurelog and synoptic feature form";
		$norecordtext="ERROR!!!<br><br> No feature exist for this square in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;


////////// CASE FEATURELOG AND SYNOPTICS BY AREA AND SUPERVISOR

		case "featurelogandsynopticsbyareaandsupervisor":

		# define sort columns
		$sortcolumn[1] = "featurelog.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "featurelog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "featurelog.description";
		$sortcolumndisplay[3] = "description";
		$sortcolumn[4] = "synopticfeatureform.phase";
		$sortcolumndisplay[4] = "phase";
		$sortcolumn[5] = "synopticfeatureform.matrixgroupnumber";
		$sortcolumndisplay[5] = "matrix group";
		$sortcolumn[6] = "synopticfeatureform.featuretype";
		$sortcolumndisplay[6] = "type";
		$sortcolumn[7] = "synopticfeatureform.int_ext";
		$sortcolumndisplay[7] = "int/ext";
		$sortcolumn[8] = "synopticfeatureform.contaminated";
		$sortcolumndisplay[8] = "contaminated";
		$sortcolumn[9] = "synopticfeatureform.insitu";
		$sortcolumndisplay[9] = "insitu";
		$sortcolumn[10] = "synopticfeatureform.fullyexcavated";
		$sortcolumndisplay[10] = "fully excavated";
		$sortcolumn[11] = "synopticfeatureform.entrycomplete";
		$sortcolumndisplay[11] = "entry complete";

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "featurelog.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}


# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select featurelog.featurenumber AS feature, featurelog.date, featurelog.description,
				synopticfeatureform.phase, synopticfeatureform.matrixgroupnumber AS \"matrix group\", synopticfeatureform.featuretype AS \"type\", synopticfeatureform.int_ext as \"int/ext\", synopticfeatureform.contaminated, synopticfeatureform.insitu, synopticfeatureform.fullyexcavated AS \"fully excavated\", CASE WHEN synopticfeatureform.entrycomplete='t' THEN 'yes' WHEN synopticfeatureform.entrycomplete='f' THEN 'no' END AS \"entry complete\",
				featurelog.featurenumber
				from ((fielddata.featurelog left join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber) left join (fielddata.featurelogsupervisors left join fielddata.listexcavators on featurelogsupervisors.supervisor = listexcavators.initials) on featurelog.featurenumber = featurelogsupervisors.featurenumber) left join fielddata.synopticfeatureform on featurelog.featurenumber = synopticfeatureform.featurenumber
				where (featurelogareas.area || ' - ' || listexcavators.fullnames)='$areaandsupervisor' and featurelog.valid=true
				$searchsql
				order by $sortsql;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 16;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 14;
		$outputcolumn[3]= 13;
		$outputcolumn[4]= 12;
		$outputcolumn[5]= 2;
		$outputcolumn[6]= 15;
		$outputcolumn[7]= 16;
		$outputcolumn[8]= 3;
		$outputcolumn[9]= 4;
		$outputcolumn[10]= 5;
		$outputcolumn[11]= 6;
		$outputcolumn[12]= 7;
		$outputcolumn[13]= 8;
		$outputcolumn[14]= 9;
		$outputcolumn[15]= 10;


		$keynumberofcolumns = 5;
		$keycolumn[1] = 11;
		$keyquery[1] = "SELECT featurelogsupervisors.supervisor AS \"supervisor(s)\" FROM fielddata.featurelogsupervisors WHERE featurelogsupervisors.valid=true";
		$keysort[1] = "featurelogsupervisors.supervisor";
		$keycolumn[2] = 11;
		$keyquery[2] = "SELECT featurelogareas.area AS \"area(s)\" FROM fielddata.featurelogareas WHERE featurelogareas.valid=true";
		$keysort[2] = "featurelogareas.area";
		$keycolumn[3] = 11;
		$keyquery[3] = "SELECT featurelogsquares.squarename AS \"square(s)\" FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keysort[3] = "featurelogsquares.squarename";
		$keycolumn[4] = 11;
		$keyquery[4] = "SELECT reassignedfeatures.oldfeaturenumber AS \"old feature number\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[4] = "reassignedfeatures.oldfeaturenumber";
		$keycolumn[5] = 11;
		$keyquery[5] = "SELECT reassignedfeatures.olddate as \"old date\" FROM fielddata.reassignedfeatures WHERE reassignedfeatures.valid=true";
		$keysort[5] = "reassignedfeatures.oldfeaturenumber";

		$uservariables = "areaandsupervisor=$areaandsupervisor&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse feature log and synoptic feature form";
		$heading1 = "option:";
		$text1 = "by area and supervisor";
		$heading2 = "area and supervisor:";
		$text2 = "$areaandsupervisor";
		$savename="features of area/supervisor $areaandsupervisor of featurelog and synopticFF";
		$norecordtext="ERROR!!!<br><br> No feature exist for this area and supervisor in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;



////////// CASE BAGREGISTER BY AREA AND SEASON

		case "bagregisterbyareaandseason":

		# define sort columns
		$sortcolumn[1] = "bagregister.bagprefix, bagregister.bagnumber";
		$sortcolumndisplay[1] = "bag";
		$sortcolumn[2] = "bagregister.featurenumber";
		$sortcolumndisplay[2] = "feature";
		$sortcolumn[3] = "bagregister.date";
		$sortcolumndisplay[3] = "date";
		$sortcolumn[4] = "bagregister.category";
		$sortcolumndisplay[4] = "category";
		$sortcolumn[5] = "bagregister.comments";
		$sortcolumndisplay[5] = "comments";


		# define flexible sorting
		if ($sortsql=='')
		{

			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "bagregister.bagprefix, bagregister.bagnumber";
				$pageidentifiername = "bag";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "bag";
		}


# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select bagregister.bagregisterid, (CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END) AS bag, bagregister.featurenumber AS feature, bagregister.date, bagregister.category, bagregister.comments
				from (fielddata.featurelog right join fielddata.bagregister on featurelog.featurenumber = bagregister.featurenumber) left join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber
				where (featurelogareas.area || ' - ' || bagregister.bagprefix) = '$areabagprefix' AND bagregister.valid=true and featurelog.valid=true
				$searchsql
				order by $sortsql;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 6;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 6;

		$keynumberofcolumns = 1;
		$keycolumn[1] = "0";
		$keyquery[1] = "SELECT bagregistersquares.squarename FROM fielddata.bagregistersquares WHERE bagregistersquares.valid=true";
		$keysort[1] = "bagregistersquares.squarename";

		$uservariables = "areabagprefix=$areabagprefix&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse bagregister";
		$heading1 = "option:";
		$text1 = "by area and bagprefix";
		$heading2 = "areabagprefix:";
		$text2 = "$areabagprefix";
		$savename="bags from areabagprefix $areabagprefix from bagregister";
		$norecordtext="ERROR!!!<br><br> No bags exist for this areabagprefix in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;



////////// CASE BAGREGISTER BY SEASON WITH FEATURELOG SQUARES

		case "bagregisterbybagprefixwithfeaturelogsquares":

		# define sort columns
		$sortcolumn[1] = "bagregister.bagprefix, bagregister.bagnumber";
		$sortcolumndisplay[1] = "bag";
		$sortcolumn[2] = "bagregister.featurenumber";
		$sortcolumndisplay[2] = "feature";
		$sortcolumn[3] = "bagregister.date";
		$sortcolumndisplay[3] = "date";
		$sortcolumn[4] = "bagregister.category";
		$sortcolumndisplay[4] = "category";
		$sortcolumn[5] = "bagregister.comments";
		$sortcolumndisplay[5] = "comments";


		# define flexible sorting
		if ($sortsql=='')
		{

			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}

			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "bagregister.bagprefix, bagregister.bagnumber";
				$pageidentifiername = "bag";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "bag";
		}


# add freetext search option

	include 'modulefreetextsearch.php';


		$query = "select bagregister.bagregisterid, (CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END) AS bag, bagregister.featurenumber AS feature, bagregister.date, bagregister.category, bagregister.comments, bagregister.featurenumber
				from fielddata.bagregister
				where bagregister.bagprefix = '$bagprefix' AND bagregister.valid=true
				$searchsql
				order by $sortsql;";


		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 7;
		$outputcolumn[0]= 1;
		$outputcolumn[1]= 2;
		$outputcolumn[2]= 3;
		$outputcolumn[3]= 4;
		$outputcolumn[4]= 5;
		$outputcolumn[5]= 7;
		$outputcolumn[6]= 8;

		$keynumberofcolumns = 2;
		$keycolumn[1] = "0";
		$keyquery[1] = "SELECT bagregistersquares.squarename AS \"bag square(s)\" FROM fielddata.bagregistersquares WHERE bagregistersquares.valid=true";
		$keysort[1] = "bagregistersquares.squarename";
		$keycolumn[2] = "6";
		$keyquery[2] = "SELECT featurelogsquares.squarename AS \"feature square(s)\" FROM fielddata.featurelogsquares WHERE featurelogsquares.valid=true";
		$keysort[2] = "featurelogsquares.squarename";


		$uservariables = "bagprefix=$bagprefix&sortsql=$sortsql&pageidentifiername=$pageidentifiername&$searchuservariables";

		$title = "browse bagregister";
		$heading1 = "option:";
		$text1 = "by bagprefix with featurelog squares";
		$heading2 = "bagprefix:";
		$text2 = "$bagprefix";
		$savename="bags from bagprefix $bagprefix from bagregister";
		$norecordtext="ERROR!!!<br><br> No bags exist for this bagprefix in database!";


		# create appropriate save name if freetext search was performed
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$savename = "!filtered! $savename";
		}

		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}

		break;
	}

?>