<?php

# switch sorting AND freetext searching options off (remove sorting bar in output)
	$nosortingoptions='yes';
	$nosearchoptions='yes';	



switch ($submenuaction)
	{
		case "":
		break;


////////// CASE FEATURES PER SUPERVISOR

		case "featurespersupervisor":

		$query = "SELECT featurelogsupervisors.supervisor, COUNT(featurelog.featurenumber) AS features,
				round(
				cast(COUNT(featurelog.featurenumber)*100 AS decimal)
				/
				cast((SELECT COUNT (*) FROM fielddata.featurelog WHERE featurelog.valid=true AND (featurelogsupervisors.supervisor IS NOT NULL)) AS decimal)
				,2)
				as percentage
				FROM fielddata.featurelog LEFT JOIN fielddata.featurelogsupervisors ON featurelog.featurenumber=featurelogsupervisors.featurenumber
				WHERE featurelog.valid=true AND featurelogsupervisors.valid=true AND (featurelogsupervisors.supervisor IS NOT NULL) GROUP BY featurelogsupervisors.supervisor ORDER BY count(featurelog.featurenumber) DESC;";

		# define output order  -  NOTE: KEY-FIELDS OMITTED! CREATE TABLE - MODULE CREATES ONE ARRAY OF MAIN TABLE AND ALL SUBTABLES FOR HEADINGS AND RESULT TEXTS!!!
		$outputcolumns = 3;
		$outputcolumn[0]= 0;
		$outputcolumn[1]= 1;
		$outputcolumn[2]= 2;

		$pageidentifiercolumn = 0;
		$pageidentifiername = "supervisor";

		$uservariables = "";
		
		$title = "query for features per supervisor<br>(sum of percentages > 100%)";
		$heading1 = "option:";
		$text1 = "-";
		$heading2 = "supervisors:";
		$text2 = "all";
		$savename="features per supervisor";
		$norecordtext="ERROR!!!<br><br> No features exist in database!";
		
		if ($saveastxt=='yes')
		{
			include 'modulesavequeryastxt.php';
		}
		else
		{
			include 'modulebrowsequeryresults.php';
		}
		
		break;

	}

?>