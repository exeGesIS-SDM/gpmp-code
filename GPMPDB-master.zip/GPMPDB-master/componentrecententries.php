<?php

	$timerecententries = "'12 hours'::interval";
	
	if ($viewrecententries=='yes')
	{
		$viewrecentsql="('now'::timestamp with time zone - $submenuaction.tstamp)<$timerecententries";

		if ($searchcolumn!='' and $searchkeywords!='')
		{
			$searchsql = $searchsql." AND $viewrecentsql";
			$searchuservariables = $searchuservariables."&viewrecententries=yes";
		}
		else
		{
			$searchsql = "AND $viewrecentsql";
			$searchuservariables = "viewrecententries=yes";
		}
	}

?>