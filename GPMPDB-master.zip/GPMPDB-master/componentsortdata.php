<?php

if ($menuaction=='browseareas')
{
		# define sort columns
		$sortcolumn[1] = "broadareas.broadareacode";
		$sortcolumndisplay[1] = "broad area code";
		$sortcolumn[2] = "broadareas.broadareaname";
		$sortcolumndisplay[2] = "broad area name";
		$sortcolumn[3] = "localareas.localareacode";
		$sortcolumndisplay[3] = "local area code";
		$sortcolumn[4] = "localareas.localareaname";
		$sortcolumndisplay[4] = "local area name";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "broadareas.broadareacode";
				$pageidentifiername = "broad area code";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "broad area code";
		}
}


if ($menuaction=='browsebagregister' or $submenuaction=='bagregister' or $submenuaction=='dsrbagregister')
{
		# define sort columns
		$sortcolumn[1] = "bagregister.bagprefix, bagregister.bagnumber";
		$sortcolumndisplay[1] = "bag";
		$sortcolumn[2] = "bagregister.featurenumber";
		$sortcolumndisplay[2] = "feature";
		$sortcolumn[3] = "bagregister.date";
		$sortcolumndisplay[3] = "date";
		$sortcolumn[4] = "bagregister.category";
		$sortcolumndisplay[4] = "category";
		$sortcolumn[5] = "bagregister.comments";
		$sortcolumndisplay[5] = "comments";	
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "bagregister.bagprefix, bagregister.bagnumber";
				$pageidentifiername = "bag";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "bag";
		}
}



elseif ($menuaction=='browseburialfeatures' or $submenuaction=='burialfeatures' or $submenuaction=='dsrburialfeatures')
{
		# define sort columns
		$sortcolumn[1] = "burialfeatures.burialnumber";
		$sortcolumndisplay[1] = "burial";
		$sortcolumn[2] = "burialfeatures.featurenumber";
		$sortcolumndisplay[2] = "feature";
		$sortcolumn[3] = "burialfeatures.burialtype";
		$sortcolumndisplay[3] = "burial type";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "burialfeatures.burialnumber";
				$pageidentifiername = "burial";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "burial";
		}
}


elseif ($menuaction=='browsebroadareas' or $submenuaction=='broadareas')
{
		# define sort columns
		$sortcolumn[1] = "broadareas.broadareacode";
		$sortcolumndisplay[1] = "broad area code";
		$sortcolumn[2] = "broadareas.broadareaname";
		$sortcolumndisplay[2] = "broad area name";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "broadareas.broadareacode";
				$pageidentifiername = "broad area code";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "broad area code";
		}
}



elseif ($menuaction=='browsecdinventory' or $submenuaction=='cdinventory' or $submenuaction=='dsrcdinventory' or $submenuaction=='cdcontents')
{
		# define sort columns
		$sortcolumn[1] = "cdinventory.storagemedium";
		$sortcolumndisplay[1] = "storage medium";
		$sortcolumn[2] = "cdinventory.number";
		$sortcolumndisplay[2] = "number";
		$sortcolumn[3] = "cdinventory.contents";
		$sortcolumndisplay[3] = "contents";
		$sortcolumn[4] = "cdinventory.giza";
		$sortcolumndisplay[4] = "in Giza";		
		$sortcolumn[5] = "cdinventory.boston";
		$sortcolumndisplay[5] = "in Boston";
		$sortcolumn[6] = "cdinventory.newyork";
		$sortcolumndisplay[6] = "in New York";	

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "cdinventory.number";
				$pageidentifiername = "number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "number";
		}
}



elseif ($menuaction=='browsedrawinglog' or $submenuaction=='drawinglog' or $submenuaction=='dsrdrawinglog')
{
		# define sort columns
		$sortcolumn[1] = "drawinglog.season, drawinglog.drawingnumber";
		$sortcolumndisplay[1] = "drawing";
		$sortcolumn[2] = "drawinglog.area";
		$sortcolumndisplay[2] = "area";
		$sortcolumn[3] = "drawinglog.date";
		$sortcolumndisplay[3] = "date";		
		$sortcolumn[4] = "drawinglog.drawinglabel";
		$sortcolumndisplay[4] = "description";
		$sortcolumn[5] = "drawinglog.scale";
		$sortcolumndisplay[5] = "scale";
		$sortcolumn[6] = "drawinglog.checked";
		$sortcolumndisplay[6] = "checked";
		$sortcolumn[7] = "drawinglog.cd";
		$sortcolumndisplay[7] = "cd/dvd storage";
		$sortcolumn[8] = "drawinglog.drawingtype";
		$sortcolumndisplay[8] = "drawing type";
		$sortcolumn[9] = "drawinglog.portfolionumber";
		$sortcolumndisplay[9] = "portfolio number";
		$sortcolumn[10] = "drawinglog.locationoriginal";
		$sortcolumndisplay[10] = "location of original";
		$sortcolumn[11] = "drawinglog.copied";
		$sortcolumndisplay[11] = "copied?";
		$sortcolumn[12] = "drawinglog.scanned";
		$sortcolumndisplay[12] = "scanned?";		
		$sortcolumn[13] = "drawinglog.cropped";
		$sortcolumndisplay[13] = "cropped?";
		$sortcolumn[14] = "drawinglog.renamed";
		$sortcolumndisplay[14] = "renamed?";
		$sortcolumn[15] = "drawinglog.burnttocd";
		$sortcolumndisplay[15] = "burnt to CD?";
		$sortcolumn[16] = "drawinglog.scanuploaded";
		$sortcolumndisplay[16] = "scan uploaded?";
		$sortcolumn[17] = "drawinglog.drawingsenttoboston";
		$sortcolumndisplay[17] = "date drawing sent to boston";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "drawinglog.season, drawinglog.drawingnumber";
				$pageidentifiername = "drawing";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "drawing";
		}
}




elseif ($menuaction=='browseentitylog' or $submenuaction=='entitylog' or $submenuaction=='dsrentitylog')
{
		# define sort columns
		$sortcolumn[1] = "entitylog.entitynumber";
		$sortcolumndisplay[1] = "entity";
		$sortcolumn[2] = "entitylog.entitytype";
		$sortcolumndisplay[2] = "type";
		$sortcolumn[3] = "entitylog.entityname";
		$sortcolumndisplay[3] = "name";
		$sortcolumn[4] = "entitylog.excavationarea";
		$sortcolumndisplay[4] = "area";		
		$sortcolumn[5] = "entitylog.date";
		$sortcolumndisplay[5] = "date";
		$sortcolumn[6] = "entitylog.supervisor";
		$sortcolumndisplay[6] = "creator";	
		$sortcolumn[7] = "entitylog.description";
		$sortcolumndisplay[7] = "description";	
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "entitylog.entitynumber";
				$pageidentifiername = "entity";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "entity";
		}
}




elseif ($menuaction=='browseexoticmaterialregister' or $submenuaction=='exoticmaterialregister' or $submenuaction=='dsrexoticmaterialregister')
{
		# define sort columns
		$sortcolumn[1] = "exoticmaterialregister.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "exoticmaterialregister.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "exoticmaterialregister.materialcategory";
		$sortcolumndisplay[3] = "category";
		$sortcolumn[4] = "exoticmaterialregister.count";
		$sortcolumndisplay[4] = "count";		
		$sortcolumn[5] = "exoticmaterialregister.weight";
		$sortcolumndisplay[5] = "weight";
		$sortcolumn[6] = "exoticmaterialregister.comments";
		$sortcolumndisplay[6] = "comments";	
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "exoticmaterialregister.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}
}



elseif ($menuaction=='browsefeaturelog' or $submenuaction=='featurelog' or $submenuaction=='dsrfeaturelog')
{
		# define sort columns
		$sortcolumn[1] = "featurelog.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "featurelog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "featurelog.description";
		$sortcolumndisplay[3] = "description";

		if ($submenuaction=='browsereassignedfeatures')
		{
			# add additional sort column
			$sortcolumn[4] = "reassignedfeatures.oldfeaturenumber";
			$sortcolumndisplay[4] = "old feature number";
		}

		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}

			elseif ($submenuaction=='browsereassignedfeatures')
			{
				# add additional sort column
				$sortsql = "reassignedfeatures.oldfeaturenumber";
				$pageidentifiername = "old feature number";
			}
			else
			{
				$sortsql = "featurelog.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}
}

elseif ($menuaction=='browsegrouplog' or $submenuaction=='grouplog')
{
		# define sort columns
		$sortcolumn[1] = "grouplog.groupnumber";
		$sortcolumndisplay[1] = "group number";
		$sortcolumn[2] = "grouplog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "grouplog.description";
		$sortcolumndisplay[3] = "description";

	
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}

			else
			{
				$sortsql = "grouplog.groupnumber";
				$pageidentifiername = "group number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "group";
		}
}

elseif ($menuaction=='imagecollection' or $submenuaction=='imagecollection')
{
		# define sort columns
		$sortcolumn[1] = "imagecollection.imagenumber";
		$sortcolumndisplay[1] = "number";
		$sortcolumn[2] = "imagecollection.date";
		$sortcolumndisplay[2] = "date";		
		$sortcolumn[3] = "imagecollection.description";
		$sortcolumndisplay[3] = "description";
		$sortcolumn[4] = "imagecollection.facing";
		$sortcolumndisplay[4] = "facing";	
		$sortcolumn[5] = "imagecollection.photographer";
		$sortcolumndisplay[5] = "photographer";
		$sortcolumn[6] = "imagecollection.cdnumber";
		$sortcolumndisplay[6] = "cd number";
				
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "imagecollection.imagenumber";
				$pageidentifiername = "number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "number";
		}
}


elseif ($menuaction=='browselocalareas' or $submenuaction=='localareas')
{
		# define sort columns
		$sortcolumn[1] = "localareas.localareacode";
		$sortcolumndisplay[1] = "local area code";
		$sortcolumn[2] = "localareas.localareaname";
		$sortcolumndisplay[2] = "local area name";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "localareas.localareacode";
				$pageidentifiername = "local area code";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "local area code";
		}
}

elseif ($menuaction=='browsenotebookscatalog' or $submenuaction=='notebookscatalog' or $submenuaction=='dsrnotebookscatalog')
{
		# define sort columns
		$sortcolumn[1] = "notebookscatalog.notebookname";
		$sortcolumndisplay[1] = "notebook name";
		$sortcolumn[2] = "notebookscatalog.datestarted";
		$sortcolumndisplay[2] = "date started";
		$sortcolumn[3] = "notebookscatalog.datecompleted";
		$sortcolumndisplay[3] = "date completed";
		$sortcolumn[4] = "notebookscatalog.comments";
		$sortcolumndisplay[4] = "comments";
		$sortcolumn[5] = "notebookscatalog.cdlocation";
		$sortcolumndisplay[5] = "cd";		
		$sortcolumn[6] = "notebookscatalog.bindertype";
		$sortcolumndisplay[6] = "binder type";
		$sortcolumn[7] = "notebookscatalog.arearecordbinderlocation";
		$sortcolumndisplay[7] = "binder number";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "notebookscatalog.notebookname";
				$pageidentifiername = "notebook name";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "notebook name";
		}
}




elseif ($menuaction=='browsephotolog' or $submenuaction=='photolog' or $submenuaction=='dsrphotolog')
{
		# define sort columns
		$sortcolumn[1] = "photolog.imagenumber";
		$sortcolumndisplay[1] = "number";
		$sortcolumn[2] = "photolog.date";
		$sortcolumndisplay[2] = "date";		
		$sortcolumn[3] = "photolog.description";
		$sortcolumndisplay[3] = "description";
		$sortcolumn[4] = "photolog.facing";
		$sortcolumndisplay[4] = "facing";	
		$sortcolumn[5] = "photolog.photographer";
		$sortcolumndisplay[5] = "photographer";
		$sortcolumn[6] = "photolog.cdnumber";
		$sortcolumndisplay[6] = "cd number";
				
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "photolog.imagenumber";
				$pageidentifiername = "number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "number";
		}
}




elseif ($submenuaction=='reassignedfeatures')
{
		# define sort columns

		$sortcolumn[1] = "reassignedfeatures.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "reassignedfeatures.oldfeaturenumber";
		$sortcolumndisplay[2] = "old feature number";
		$sortcolumn[3] = "reassignedfeatures.olddate";
		$sortcolumndisplay[3] = "old date";

		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "reassignedfeatures.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}
}




elseif ($menuaction=='browsereportscatalog' or $submenuaction=='reportscatalog' or $submenuaction=='dsrreportscatalog')
{
		# define sort columns
		$sortcolumn[1] = "reportscatalog.reportname";
		$sortcolumndisplay[1] = "report name";
		$sortcolumn[2] = "reportscatalog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "reportscatalog.reporttype";
		$sortcolumndisplay[3] = "report type";
		$sortcolumn[4] = "reportscatalog.comments";
		$sortcolumndisplay[4] = "comments";
		$sortcolumn[5] = "reportscatalog.cd";
		$sortcolumndisplay[5] = "cd";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "reportscatalog.reportname";
				$pageidentifiername = "report name";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "report name";
		}
}



elseif ($menuaction=='browsesampleregister' or $submenuaction=='sampleregister' or $submenuaction=='dsrsampleregister')
{
		# define sort columns
		if ($submenuaction=='sampleregister')
		{
			$sortcolumn[1] = "sampleregister.sampleprefix";
			$sortcolumndisplay[1] = "sampleprefix";
			$sortcolumn[2] = "sampleregister.samplenumber";
			$sortcolumndisplay[2] = "samplenumber";
			$sortcolumn[3] = "sampleregister.featurenumber";
			$sortcolumndisplay[3] = "feature";
			$sortcolumn[4] = "sampleregister.bagnumber";
			$sortcolumndisplay[4] = "bag";
			$sortcolumn[5] = "sampleregister.date";
			$sortcolumndisplay[5] = "date";
			$sortcolumn[6] = "sampleregister.sampletype";
			$sortcolumndisplay[6] = "type";		
			$sortcolumn[7] = "sampleregister.comments";
			$sortcolumndisplay[7] = "comments";
		}
		else
		{
			$sortcolumn[1] = "sampleregister.sampleprefix, sampleregister.samplenumber";
			$sortcolumndisplay[1] = "sample number";
			$sortcolumn[2] = "sampleregister.featurenumber";
			$sortcolumndisplay[2] = "feature";
			$sortcolumn[3] = "sampleregister.bagnumber";
			$sortcolumndisplay[3] = "bag";
			$sortcolumn[4] = "sampleregister.date";
			$sortcolumndisplay[4] = "date";
			$sortcolumn[5] = "sampleregister.sampletype";
			$sortcolumndisplay[5] = "type";		
			$sortcolumn[6] = "sampleregister.comments";
			$sortcolumndisplay[6] = "comments";
		}
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			elseif ($submenuaction=='sampleregister')
			{
				$sortsql = "sampleregister.samplenumber";
				$pageidentifiername = "samplenumber";
			}
			else
			{
				$sortsql = "sampleregister.sampleprefix, sampleregister.samplenumber";
				$pageidentifiername = "sample number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "sample number";
		}
}





elseif ($menuaction=='browsespacelog' or $submenuaction=='spacelog')
{
		# define sort columns
		$sortcolumn[1] = "spacelog.spacenumber";
		$sortcolumndisplay[1] = "space number";
		$sortcolumn[2] = "spacelog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "spacelog.description";
		$sortcolumndisplay[3] = "description";

	
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}

			else
			{
				$sortsql = "spacelog.spacenumber";
				$pageidentifiername = "space number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "space number";
		}
}


elseif ($menuaction=='browsestructurelog' or $submenuaction=='structurelog')
{
		# define sort columns
		$sortcolumn[1] = "structurelog.structurenumber";
		$sortcolumndisplay[1] = "structure number";
		$sortcolumn[2] = "structurelog.date";
		$sortcolumndisplay[2] = "date";
		$sortcolumn[3] = "structurelog.description";
		$sortcolumndisplay[3] = "description";

	
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}

			else
			{
				$sortsql = "structurelog.structurenumber";
				$pageidentifiername = "structure number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "structure number";
		}
}


elseif ($menuaction=='browsesynopticfeatureform' or $submenuaction=='synopticfeatureform' or $submenuaction=='dsrsynopticfeatureform' or $submenuaction=='personalsynopticfeatureform')
{
		# define sort columns
		$sortcolumn[1] = "synopticfeatureform.featurenumber";
		$sortcolumndisplay[1] = "feature";
		$sortcolumn[2] = "synopticfeatureform.featuretype";
		$sortcolumndisplay[2] = "type";
		$sortcolumn[3] = "synopticfeatureform.phase";
		$sortcolumndisplay[3] = "phase";
		$sortcolumn[4] = "synopticfeatureform.matrixgroupnumber";
		$sortcolumndisplay[4] = "matrix group";
		$sortcolumn[5] = "synopticfeatureform.int_ext";
		$sortcolumndisplay[5] = "int/ext";		
		$sortcolumn[6] = "synopticfeatureform.contaminated";
		$sortcolumndisplay[6] = "contaminated";
		$sortcolumn[7] = "synopticfeatureform.insitu";
		$sortcolumndisplay[7] = "insitu";	
		$sortcolumn[8] = "synopticfeatureform.fullyexcavated";
		$sortcolumndisplay[8] = "fully excavated";	
		$sortcolumn[9] = "synopticfeatureform.entrycomplete";
		$sortcolumndisplay[9] = "entry complete";
				
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "synopticfeatureform.featurenumber";
				$pageidentifiername = "feature";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "feature";
		}
}



elseif ($menuaction=='feedback')
{
		# define sort columns
		$sortcolumn[1] = "userfeedback.tstamp";
		$sortcolumndisplay[1] = "date";
		$sortcolumn[2] = "authentication.name";
		$sortcolumndisplay[2] = "user";
		$sortcolumn[3] = "userfeedback.subject";
		$sortcolumndisplay[3] = "subject";
		$sortcolumn[4] = "userfeedback.feedback";
		$sortcolumndisplay[4] = "feedback";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "userfeedback.tstamp DESC";
				$pageidentifiername = "date (descending)";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "date (descending)";
		}
}

elseif ($menuaction=='feedbackreplies')
{
		# define sort columns
		$sortcolumn[1] = "userfeedbackreplies.tstamp";
		$sortcolumndisplay[1] = "date";
		$sortcolumn[2] = "authentication.name";
		$sortcolumndisplay[2] = "user";
		$sortcolumn[3] = "userfeedbackreplies.reply";
		$sortcolumndisplay[3] = "reply";
		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "userfeedbackreplies.tstamp DESC";
				$pageidentifiername = "date (descending)";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "date (descending)";
		}
}


elseif ($submenuaction=='portfoliocontents')
{
		# define sort columns
		$sortcolumn[1] = "listportfolios.portfolionumber";
		$sortcolumndisplay[1] = "portfolio number";
		$sortcolumn[2] = "listportfolios.area";
		$sortcolumndisplay[2] = "area";

		
		# define flexible sorting
		if ($sortsql=='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort1)
				{
					$sort1=$sortcolumn[$i];
					$pageidentifiername = $sortcolumndisplay[$i];
				}
			}
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort2)
				{
					$sort2=$sortcolumn[$i];
				}
			}			
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$sort3)
				{
					$sort3=$sortcolumn[$i];
				}
			}
			
			if ($sort1!='' and $sort2!='' and $sort3!='')
			{
				$sortsql = "$sort1, $sort2, $sort3";
			}
			elseif ($sort1!='' and $sort2!='')
			{
				$sortsql = "$sort1, $sort2";
			}
			elseif ($sort1!='')
			{
				$sortsql = "$sort1";
			}
			else
			{
				$sortsql = "listportfolios.portfolionumber";
				$pageidentifiername = "portfolio number";
			}
		}
		elseif (!$pageidentifiername)
		{
			$pageidentifiername = "portfolio number";
		}
}
?>