<?php

if ($fullscreen=='yes')
{
	include 'authentication.php';
	echo'<body bgcolor="#000000" text="#000000">';
}

	echo"<table width='100%'>
		<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
		<tr bgcolor='#333333'> 
	    	<td class='heading' valign='top' colspan='5' height='30'>HELP<br>$topicname</td>
		</tr>
		<tr><td class='emptyline' height='5'>&nbsp;</td></tr>";

		
	if (!$fullscreen and $topic)
	{
		echo "<tr bgcolor='#1A1F2D'><td>";
		printf ("<a class='yellowlink' href=\"help.php?fullscreen=%s&indexaction=%s&topic=%s&topicname=%s\" target=\"_blank\">
			printable version</a>", 'yes', $indexaction, $topic, $topicname);
		echo "</td></tr>
			<tr><td class='emptyline' height='20'>&nbsp;</td></tr>";
	}
	
		
switch ($topic)
{
	case "":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
		help topics
	</td></tr>";
	
	$topicname[1] = 'data browse and query';
		$topiclink[1] = 'databrowsequery';
	$topicname[2] = 'data entry';
		$topiclink[2] = 'dataadd';
	$topicname[3] = 'data editing and deleting';
		$topiclink[3] = 'dataeditdelete';
	$topicname[4] = 'finding aid';
		$topiclink[4] = 'findingaid';
	$topicname[5] = 'known issues and bugs';
		$topiclink[5] = 'issuesandbugs';
	$topicname[6] = 'version log';
		$topiclink[6] = 'versionlog';
	
	for	($i=1; $i<=count($topicname); $i++)
	{
		echo"
		<tr bgcolor='#1A1F2D'><td class='helptext'>
		<a class='menulink' href='".$sitebasefile."?indexaction=$indexaction&topic=$topiclink[$i]&topicname=$topicname[$i]'>
			$topicname[$i]</a>
		</td></tr>";
	}
	
	echo"
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
		<a class='menulink' href='./output/DBLiveLink.zip'>download \"live link\" files</a>
	</td></tr>
	";

	break;



	case "versionlog":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.82 (01jun2011)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemented support for space log recording
	- implemented support for structure log recording
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.81 (17may2011)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemented support for group log recording
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>


	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.80 (17april2009)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemented full editing and viewing of synoptic information
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>


	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.79 (16february2009)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added related photos to photolog browsing
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>


	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.78 (05april2008)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed bug where database wouldn't remember whether you have enable 'fast data entry'<br>
	- made database remember if user wants to show linked files during session<br>
	- extended synoptic feature form datastructure and uploaded latest information<br>
	- extended photolog datastructure and uploaded latest information<br>
	- fixed data download routine to escape funny characters in file names<br>
	- increased size of browse featurelog feature number fields
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.77 (15november2007)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added editing functionality to single table data entry<br>
	- added multiple areas to portfolio list<br>
	- increased size of exotic materials register materialtype field to 25 characters<br>
	- increase size of entity description to 255 characters
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.76 (23august2007)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- re-activated function checking if files exist on file server. links now only show if file can be downloaded.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.75 (17july2007)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- rewired linked docs and images to changed LP Archaeology server IP address
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.74 (19march2007)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- rewired linked docs and images to new LP Archaeology server
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.73 (04december2006)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixes after server crash
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.72 (01march2006)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- modified drawinglog table to accomodate checklist entries<br>
	- updated 'live link' AccessDB to match new drawinglog settings
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.71 (03february2006)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added broad and local area tables<br>
	- added indexing functionality to photolog<br>
	- setup 'live link' into DB data from external DBs
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.70 (22december2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added fast data entry functionality to all subforms<br>
	- added multiple delete functionality to all subforms<br>
	- made subform records sort ascending in edit mode<br>
	- new functionality in browse area: multiple filter values can be entered (separated by commas)<br>
	- fixed fullscreen/HTMLprint page selector mode<br>
	- fixed fullscreen/HTMLprint button on results window<br>
	- optimized freetext search functionality on results window<br>
	- added hyperlinks from any feature to 'query by feature' section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.62 (16november2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- optimised page selector in results table (now uses javascript)<br>
	- added functionality to show/hide linked files<br>
	- added browse featurelog by area<br>
	- added specialized query: features by square and their drawings
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.61 (12may2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed 'browse drawinglog by features' etc. bug<br>
	- fixed 'features by area and their drawings' query bug
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.60 (31mar2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added imagecollection table<BR>
	- added listtable 'sources'<BR>
	- modified data entry/edit forms to handle multiple toplines<BR>
	- modified structural layout of add/edit listings<BR>
	- added field 'CD' to reportscatalog<BR>
	- added field 'bindertype' to notebookscatalog<BR>
	- added listtable 'binders'
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.56 (24mar2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added 'listportfolios' table<br>
	- fixed data entry check for featurenumber in exotic material register<br>
	- changed portfolionumber in drawinglog to dropdown list<br>
	- added specialized query for listing drawings of portfolios<br>
	- added specialized query for duplicate drawings
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.55 (07mar2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added specialized query 'features by area and their drawings' which queries feature records, their areas and their drawings.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.54 (22feb2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added 'recall previous record' function to data entry forms with subforms (e.g. drawing log, feature log, etc.)
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.53 (09feb2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added specialized query 'cd content' which queries cdinventory records and related drawings, notebooks and photos<br>
	- extended subquery capabilities<br>
	- fixed specialized queries related to synoptics
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.52 (15jan2005)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- removed columns 'portfolionumber' and 'phototype' from photolog<br>
	- removed list table 'listphototypes'<br>
	- added column 'portfolionumber' to drawinglog<br>
	- changed drawinglog and listdrawingtype column 'drawingtype' to varchar(20)<br>
	- indexed photolog properly<br>
	- fixed sort order for 'browse reassigned features'
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.51 (18dec2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- adjusted menu to pure html for maximum browser compatibility<br>
	- improved txt file output
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.50 (15dec2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- simplified navigation and menu structure of web interface<br>
	- added 'return' button to all browse and query results<br>
	- added search 'by specialist info' to 'browse photolog' section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.41 (05dec2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- changed photo links to new AERA server<br>
	- fixed notebookscatalog edit/delete link<br>
	- edited finding aid for better display of photolog entries<br>
	- changed default season to '2005'<br>
	- added 'photologareas' table and removed 'area'-field from photolog table<br>
	- change add/edit/delete of photolog to accomodate new one-to-many relation with photologareas<br>
	- added columns 'portfolio number' and 'photo type' to photolog<br>
	- added 'listphototypes' table<br>
	- added validation for add/edit of feature log and photo log<br>
	- fixed view of specialist-id field of photolog
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.40 (18nov2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- updated email links in 'feedback' section<br>
	- added browse function 'by category' to bagregister
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.39 (16oct2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed 'save as txt' function<br>
	- fixed 'burial query'
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.38 (16aug2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- removed column 'dsrsupervisor' from table 'syopticfeatureform'<br>
	- updated synoptic feature form information
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.37 (14aug2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added content list and anchor navigation to help section<br>
	- added Nicole's finding aid to help section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.36 (11aug2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added browse options 'by area', 'by supervisor'/'by author' and 'by square' to reports catalog and notebooks catalog
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.35 (07aug2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed direct download of raw tables<br>
	- updated 'known issues and bugs'<br>
	- added specialized query 'bagregister with site seasons'<br>
	- added columns 'bostondrawer' and 'bostonfolder' to drawinglog
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.34 (26jul2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed txt download of compiled area record tables<br>
	- updated 'known issues and bugs'<br>
	- added forced print window for 'printable version' pages
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.33 (07jul2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added reply function to feedback section<br>
	- added 'email' column to user table<br>
	- added email function to feedback and reply sections
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.32 (06jul2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemeted query 'by burial'<br>
	- added data input/edit validation procedures: check for values that are empty or not an integer, check for duplicates in subtables
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.31 (05jul2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added 'burialfeatures' table with list table 'listburialtypes'<br>
	- fixed bug in pagination display<br>
	- updated metadata section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.30 (01jul2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed photologspecialists output display<br>
	- fixed entitylogchanges output display<br>
	- implemented checks for existing log records in compiled area records section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.29 (30jun2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added subtable 'photologspecialists'<br>
	- added 'direct downloads' function for raw tables<br>
	- added missing unique constraints to tables<br>
	- adjusted drop-down behavior of compiled area records to receive list data from list tables
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.28 (28jun2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed data entry bug of 'cd inventory'<br>
	- changed freetext search to non-case-sensitive<br>
	- added support for resource existence check
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.27 (25jun2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- created links to folders/files from tables feature log, notebooks catalog and reports catalog<br>
	- added info about 'browse' and 'query' functions to help section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.26 (17jun2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemented full screen add/edit<br>
	- added column 'drawingtype' to drawinglog<br>
	- added table 'listdrawingtypes'<br>
	- added reportscatalog, reportscatalogareas, reportscatalogsquares, reportscatalogauthors and listreporttypes tables
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.25 (03jun2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- implemented 'direct edit' function for multiple table logs<br>
	- finalized help section<br>
	- completely new implementation of PDF saving option using FPDF class
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.24 (13may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- changed 'seasonname' in listsiteseasons to varchar(10)<br>
	- added specialized query 'site seasons of features with bags'<br>
	- updated introduction and help section
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.23 (11may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- merged edit/delete options<br>
	- added 'old date' column to reassigned features table<br>
	- fixed quotation mark problem for multiple subcolumn tables<br>
	- added 'listsiteseasons' table
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.22 (10may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed multiple column freetext searches in edit/delete<br>
	- made 'view recent entries' of 'add' mode editable, searchable and sortable<br>
	- removed 'add personal synopticfeatureform' option<br>
	- added browse drawinglog by artist
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.21 (06may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed preview image in add mode<br>
	- added 'sort by old feature number' for 'browse reassigned features'<br>
	- changed 'view recent entries' to 'view entries / changes of last 12 hours'<br>
	- fixed 'add personal data' of synoptic feature form
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.20 (05may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	and another big step forward for the database: data entry, edit and delete have been significantly improved!<br>
	- added columns 'inboston' and 'cd' to drawinglog<br>
	- fixed 'first active field' of edit<br>
	- added jump to subform behavior to topline data add / edit<br>
	- added 'view image' function for add / edit of photolog<br>
	- improved design of add/edit/delete displays<br>
	- added search and sort options for edit and delete
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.13 (04may2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- disabled 'freetext search option' in view recent entries<br>
	- fixed browse by feature for entitylog<br>
	- added browse raw tables<br>
	- added meta data for raw tables<br>
	- added check for recent changes of raw tables<br>
	- moved edit button and delete tick box to the left side of tables
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.12 (30apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added 'freetext search' for all browse outputs<br>
	- fixed minor errors in browse outputs
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.11 (29apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- made listdata browsable<br>
	- removed sorting options for 'view recent entries'<br>
	- added browse reassigned features option in featurelog<br>
	- fixed start field pointer in add data multiple<br>
	- converted 'checked' and 'ingiza' fields in drawinglog from boolean to varchar(3)<br>
	- added general empty drop-down field option<br>
	- removed squares from bagregister and exotics data entry (these have to be entered through the edit option now!)
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.10 (28apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	another big step towards a smoothly running and visual acceptable gpmp excavation database!<br>
	- added unique constraint to imagenumber in photolog<br>
	- added sample register to query 'compiled area records'<br>
	- adjusted display/add/edit/delete order of all register<br>
	- added individualized query 'bagregister by bagprefix with featurelog squares'<br>
	- rewrote code for displaying query output: column order (including one-to-many columns) can now be freely defined<br>
	- fixed concacenated query outputs (e.g. weight in exotic material register)<br>
	- fixed checkbox output of dataentrysingle<br>
	- fixed editmultiple for multiple subcolumns<br>
	- added cancel button for editmultiple<br>
	- added automatic season setting for data entry<br>
	- fixed empty field output for multiple subcolumns<br>
	- added custom column headers for add/edit<br>
	- made various adjustments in add/edit column widths<br>
	- added custom table names in browse/add/edit/delete<br>
	- added extra delete button on bottom of delete pages<br>
	- adjusted color scheme of add/edit<br>
	- added sort options for 'feedback'
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.03 (21apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- fixed logout button<br>
	- fixed quotation mark problem in 'add' and 'edit'<br>
	- fixed 'blank-screen' problem in 'edit'<br>
	- created drop-down menu and list for weightprefix in exoticmaterialsregister<br>
	- changed all drop-down menues of squares in 'edit' mode to listdataentrysquares
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
		<tr bgcolor='#333333'><td class='helptextyellow'>
	ver	1.02 (20apr2004)
	</td></tr>
	<tr	bgcolor='#1A1F2D'><td class='helptext'>
	- added logout button<br>
	- fixed 'compiled area records' query (query syntax was too restrictive)
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.01 (16apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	- added feedback option to improve communication between the users and the programmer / data entry person<br>
	- added monitoring of database usage
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'>
	ver 1.00 (12apr2004)
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	after almost five months of hard work we made the big step: version 1.00 is online! this means that the complete gpmp excavation data is stored, managed and queried through the very web interface you have just logged onto.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;


	case "databrowsequery":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	List of content
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	<a class='whitelink' href='#introduction'>introduction</a><br>
	<a class='whitelink' href='#browse'>browse functions</a><br>
	<a class='whitelink' href='#query'>query functions</a><br>
	<a class='whitelink' href='#output'>browse and query output window</a>
	</td></tr>
	<tr><td class='emptyline' height='30'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='introduction'></a>
	introduction
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	all the data that is entered into the gpmp excavation database can be accessed through either the 'browse' or the 'query' menu. these two options distinguish from each other by their functions: use 'browse' for general enquiries and 'query' for specific tasks.<br>
	we recommend that you start your information search in 'browse' - most of your questions will be answered there. for advanced users and special tasks we have created the 'query' area and if you would like to retrieve specific data then we can even add queries tailored to your needs here.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='browse'></a>
	browse functions
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	welcome to the browse area. find out about all fielddata recovered from gpmp excavations. simply click on the name of the table that contains the topic you are searching for (e.g. 'photolog' for excavation photos).<br>
	if you are interested in the original database tables (e.g. to download them and incorporate them in your own database), then use the link 'raw tables'. this leads you to the original, undigested data and you can view or download each of them. use the 'direct download' function to receive tab-delimited text files of all raw tables. to find out when the last changes were performed on each of the tables click on the 'check for changes' link. you will be presented with a list of available tables and their latest modifications (careful! dates are not considering deletions in the datasets!). for a comprehensive description of how the raw tables interact with each other and what data types they contain, we have provided you with a metadata section (link 'raw tables => read metadata').<br>
	some users might want to view or make use of our typology. find out about that under the link 'list tables'. these lists are used as drop-down menues in the data entry part of the database. note that only the important type tables are listed here. 
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='query'></a>
	query functions
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	in the query menu you will find a list of advanced options to retrieve information from the database. there are two very powerful functions: query all information of the database in relation to a feature or an area.<br>
	if you are interested in a specific feature and you would like to know everything the database knows about it, click on the link 'by feature' and then enter the feature number. the database will provide you with a compiled list of all available information.<br>
	if you need to compile all information for a specific excavation area (e.g. you have to write a report), use the 'compiled area records' function. you will be asked to define an area and three options are available: use an existing area, use the square(s) or use supervisor(s) that worked there. note that you can use any combination of the three or leave fields blank. in the 'square(s)' and 'supervisor(s)' lists you can even choose multiple entries by holding the control key on your keyboard. once you have selected your defintion click on 'continue'. finally choose the type of information you would like to view (e.g. photolog for all the photos that were taken in the area you have defined).<br>
	if you can't find the query option you need, this is the area where we can add your personal query. contact the database administrator and explain the function you need. once it is implemented it will be accessible through the link 'specialized queries'.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'><a name='output'></a>
	browse and query output window
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	after you have selected a browse or query option the result will appear in a standardized format.<br>
	the <b>header</b> of each result contains the title of your search, a short description and the number of retrieved result rows, all displayed on the left. on the right side you have the option to export the result table as a text (tab-delimited) or PDF file. use the text option if you want to process the results in your own spreadsheet program or database. use the PDF option if you are only interested in a preformatted, ready to print copy of your query.<br>
	under the header you will find the <b>sort/search bar</b>. use sort for applying a custom sort order for up to three columns. use the freetext search option to limit your query results further to specific search strings.<br>
	under the sort/search bar you can see the <b>page selection bar</b> if your result table contains more than 100 rows. to reduce the download time to your computer, the result is split up in packages of 100 rows and each package can be retrieved by selecting the appropriate result page. the pages are identified by the current primary sort column (which may change if you adjust the sort order) and each page is represented by the value of the first record followed by a '+' symbol indicating that the page contains records that start with this identifier.<br>
	finally there is the table containing the results of your browse or query option. for some tables there is extra information that is linked to each record (e.g. image thumbnails for the photolog or feature forms in pdf format for the features). click on the link in the first column of the appropriate record if you want to download this extra information.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;



	case "dataadd":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	List of content
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	<a class='whitelink' href='#introduction'>introduction</a><br>
	<a class='whitelink' href='#tableselection'>table selection menu</a><br>
	<a class='whitelink' href='#dataentrygeneral'>data entry window: general information</a><br>
	<a class='whitelink' href='#tablesnorelation'>data entry window: tables without relationships</a><br>
	<a class='whitelink' href='#tablesrelation'>data entry window: tables with one-to-one and one-to-many relationships</a>
	</td></tr>
	<tr><td class='emptyline' height='30'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='introduction'></a>
	introduction
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	one major advantage of the gpmp excavation database compared to a standard internet database is the capability to accept online data entry.
	when we developed the concept of the datbase we decided that the data entry area has to accessible to authorized persons only.
	most of the users will therefore not be able to contribute to the digital archiving of excavation data.<br>
	if you have been granted access to the data entry part you will be able to see a menu of links to tables once you have clicked on 'add' in the main menu.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tableselection'></a>
	table selection menu
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	once you have selected 'add' in the main menu, a list of links to tables appears on the left side of your screen. in the upper part of this submenu are the general excavation / archive tables located and in the lower part the list tables that are used as drop-down lists in the general tables.
	if you are a superuser you will be able to see another link at the very bottom of this submenu for adding users to the database system.<br>
	to add data to one of these tables, simply click on the relevant name and the data entry window will appear on you screen.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='dataentrygeneral'></a>
	data entry window: general information
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	in the data entry window you can add a new record to the database. two types of tables with different functions exist:<br>(1) tables with no relationships<br>(2) tables with one-to-one and one-to-many relationships<br>
	they can be distinguished by examining the button line above the data entry fields. if you can see a button called 'clear form', you are are adding a record to a 'type 2' table. you will also see additional lines and buttons with different content arranged under the first data entry line. if there is no 'clear form' button you are adding a record to a 'type 1' table. these tables have no additional data entry lines under the main line.<br>
	both types of tables have buttons called 'upload data' and 'view entries / changes of last 12h' located over the the data entry fields:<br>
	use 'upload data' to send the entries visible in your window to the database. data is not stored in the database until you press this button! once you have sent your entries, the data entry window resets itself to its initial empty state and you can enter more records.<br>
	use 'view entries / changes of last 12h' to review all entries or changes that have been performed on the table you are working on over the last 12 hours. if you press this button a data edit/delete window will appear on your screen (see 'data editing and deleting' help section for details).
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tablesnorelation'></a>
	data entry window: tables without relationships
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	tables that do not have any relationships to subtables appear as a single data entry line on your screen. once you have entered the first data line you have to press the 'add' button. your data will be stored temporarely and appears above the second data entry line. this way you can add up to 10 new lines followed by a message advising you to upload your data. this can easily be done by pressing the 'upload data' button.<br>
	once your data has been successfully uploaded, the temporary storage is cleared and your data entry window will appear again with an empty first data entry line. if the upload was not successfull, you will be advised to check your data. make sure that you have entered the right types of data for each field.<br>
	if you made a mistake you can easily delete a temporarely stored line by pressing the 'delete' button next to it.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tablesrelation'></a>
	data entry window: tables with one-to-one and one-to-many relationships
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	the data entry window for tables with relationships (i.e. subtables attached to them) works different from the tables without relationships. your screen will show a single data entry line at the top which represents the main table information. under this line will be one or more smaller data entry lines which represent the subtables that are attached to the main table. first you should enter the main data entry line and finalize the entry by hitting the 'update' button to the right of it. if you change this entry again before uploading your data, then don't forget to hit the 'update' button again!<br>
	once the main line has been entered you can add multiple lines to the subtable entries. simply enter the appropriate info in the appropriate field and click on the 'add' button next to it. if one of your subtable entries has a mistake you can delete it by hitting the 'delete' button to the right of it.<br>
	once you have entered all the data related to the record you have to hit the 'upload data' button. if your entry does comply to the database types, it will be saved and returns a new empty data entry screen for the table. if there have been problems with the data, you will advised to check your entries.  make sure that you have entered the right types of data for each field.<br>
	you can clear the current form by clicking on the 'clear form' button. if you are doing repetitive data entry of similar records, you may find the 'recall previous record' button helpful; if you click it the form will reload the record you have just previously uploaded to the DB. make sure though that you change the correct fields to match the new record completely!
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;


	case "dataeditdelete":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	List of content
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	<a class='whitelink' href='#introduction'>introduction</a><br>
	<a class='whitelink' href='#tableselection'>table selection menu</a><br>
	<a class='whitelink' href='#dataeditdeletegeneral'>data edit & delete window: general information</a><br>
	<a class='whitelink' href='#tablesnorelation'>data edit & delete window: tables without relationships</a><br>
	<a class='whitelink' href='#tablesrelation'>data edit & delete window: tables with one-to-one and one-to-many relationships</a><br>
	<a class='whitelink' href='#directedit'>direct edit functions</a>
	</td></tr>
	<tr><td class='emptyline' height='30'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='introduction'></a>
	introduction
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	the date edit and delete area completes the data management part of the gpmp online excavation database. previously entered information can be changed or removed from the database.<br>
	as you will see, we have implemented very powerful tools such as the sort and search functions you already know from the browse area, to maximise the efficiency of your work.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tableselection'></a>
	table selection menu
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	once you have selected 'edit & delete' in the main menu, a list of links to tables appears on the left side of your screen. at the very top is a link to the direct edit functions of the database followed by the general excavation / archive tables and in the lower part the list tables that are used as drop-down lists in the general tables.
	if you are a superuser you will be able to see another link at the very bottom of this submenu for adding users to the database system.<br>
	to edit or delete data of one of these tables, simply click on the relevant name and the data entry window will appear on you screen.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='dataeditdeletegeneral'></a>
	data edit & delete window: general information
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	in the data edit and delete window you can change or remove records of the database. similar to the add mode, there are two types of tables with different functions:<br>
	(1) tables with no relationships<br>
	(2) tables with one-to-one and one-to-many relationships<br>
	when you first enter the edit and delete mode for a table, all entries that exist appear in your window. each record is headed by an 'edit' button and additionally by an 'delete' button if you have the right access level. use the 'edit' button the change the information of a record and use the 'delete' button to remove it permanently from the database.<br>
	once you have hit the 'edit' button, your window will change into edit mode. for both table types, this mode looks different
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tablesnorelation'></a>
	data edit & delete window: tables without relationships
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	for tables that do not have any relationships to subtables, the record you chose for editing will appear within the same table context as a data entry line holding the old values. once you have changed or corrected the data, press the 'update' button. if your changes were successful, your window will return to the state before you entered the edit mode. if there are problems with your entry, you will be advised to check your data. make sure that you have entered the right types of data for each field.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='tablesrelation'></a>
	data edit & delete window: tables with one-to-one and one-to-many relationships
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	in case of tables with relationships (i.e. subtables attached to them), the selected record for editing will be loaded into the screen you already know from data entry of the table. your screen will show a single data entry line at the top which represents the main table information. under this line will be one or more smaller data entry lines which represent the subtables that are attached to the main table. if you need to change data in the main data entry line, don't forget to finalize it by hitting the 'update' button to the right of it. if you add lines to the subtable entries don't forget to hit the 'add' button next to it. if one of your subtable entries has a mistake you can delete it by hitting the 'delete' button to the right of it.<br>
	once you have changed or added all the data you needed you have to hit the 'update DB' button to confirm your changes. if your entry does comply to the database types, it will be saved and you will return to the table view with all the records of the table. if there have been problems with the data, you will advised to check your entries.  make sure that you have entered the right types of data for each field, then try to 'update DB' again.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'><a name='directedit'></a>
	direct edit functions
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	as a special quick function to edit an entry of a table with relationships, you can use the direct edit function. simply enter the record identifier (e.g. feature number for the feature log) in the direct edit main window and the database will produce this record directly in edit mode. if the record does not exist you will be notified in the same window.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;




	case "findingaid":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	List of content
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	<a class='whitelink' href='#introduction'>Introduction</a><br>
	<a class='whitelink' href='#bagregister'>Bag Register</a><br>
	<a class='whitelink' href='#burialfeatures'>Burial Features</a><br>
	<a class='whitelink' href='#cdinventory'>CD Inventory</a><br>
	<a class='whitelink' href='#drawinglog'>Drawing Log</a><br>
	<a class='whitelink' href='#entitylog'>Entity Log</a><br>
	<a class='whitelink' href='#exoticmaterialregister'>Exotic Material Register</a><br>
	<a class='whitelink' href='#featurelog'>Feature Log</a><br>
	<a class='whitelink' href='#notebookscatalog'>Notebooks Catalog</a><br>
	<a class='whitelink' href='#photolog'>Photo Log</a><br>
	<a class='whitelink' href='#reportscatalog'>Reports Catalog</a><br>
	<a class='whitelink' href='#sampleregister'>Sample Register</a>
	</td></tr>
	<tr><td class='emptyline' height='30'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='introduction'></a>
	Introduction
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	The purpose of this finding aid is to give an overview of the contents available in the GPMP database, and any special information that will help you to use that material. The GPMP database is a constantly evolving and growing resource, and the information in the following document is current as of July 2004.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='bagregister'></a>
	Bag Register
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	In the database, you will find each bag number consists of a year prefix plus a number unique to that set of year prefixes. Note that in the 1988 to 1991a seasons, more than one set of numbers were being used, and the prefixes were created during the 2003 study season to distinguish between different bags. It should be noted that bags from all seasons that contained more than one category of find were classified as 'Mixed' in the category field in the database. The types of material in the bag were listed in the comments field. When a bag contained material from more than one feature, the bag is listed under the lowest of the two feature numbers, and the second is mentioned in the comments field.<br><br>
	Therefore, these newly created prefixes will not appear on the bags themselves in the storeroom.<br><br>
	<b>�	1988-89, 1991 spring (Area AA):</b> A running list of bag numbers was kept for each individual excavation square in this area (A1-A6), starting with 1, and continuing through both seasons. In the database, these items are entered with their reassigned feature numbers (the old feature numbers can be found in the comments field).<br><br>
	<b>�	1991 spring (Area A7):</b> A running sequence of bag numbers was used, starting with 1.<br><br>
	<b>�	1991a (Area AA):</b> A running sequence of bag numbers was used, starting with 1.<br><br>
	<b>�	1991a (Area A8):</b> A running sequence of bag numbers was used, starting with 1. In the database, these items are entered with their reassigned feature numbers (the old feature numbers can be found in the comments field).<br><br>
	<b>�	1991a (Area A7), 1995:</b> In 1991a, a running sequence of bag numbers was used, starting with 1. However, pre-printed bag registers were not used, and so the bag numbers were not entered into the register in sequence during this season, and therefore there are unaccounted for gaps and numbers used twice. The last known number from this season is 1397). The sequence of numbers was continued in 1995 (1425-2080), when they were registered in sequence.<br><br>
	<b>�	In 1995,</b> disparate finds were put together in one guffa assigned a single bag number. These were given the bag type 'mixed' in the bag register.<br><br>
	<b>�	1997:</b> A running sequence of bag numbers was used, starting with 1.<br><br>
	<b>�	1998:</b> A running sequence of bag numbers was used, starting with 1. Several bag numbers were used twice during this season.<br><br>
	<b>�	1999-2000:</b> A running sequence of bag numbers, starting with 1, was used in fall 1999 (up to 495) and spring 2000 (496-3490).<br><br>
	<b>�	2000b:</b>  A running sequence of bag numbers, starting with 1, was used in fall 2000 (up to 1547) and continued in spring 2001 (1548-1560, 1583-2472). The last bag in this sequence was assigned on 26 Feb 2001.<br><br>
	<b>�	2001a:</b> A running sequence of bag numbers, starting with 1, was started on 7 February 2001.<br><br>
	<b>�	2002:</b>  A running sequence of bag numbers was used, starting with 1.<br><br>
	<b>�	2004:</b> A running sequence of bag numbers was used, starting with 1. When bag numbers from previous seasons were used twice in previous seasons, the bag number belonging to the higher numbered feature of the pair were given new 2004 bag numbers. These items are cross-referenced in the comments field.<br><br>

	<b>In the database, the following bag prefixes are used:</b><br>
	�	1988-A1<br>
	�	1988-A2<br>
	�	1988-A4<br>
	�	1988-A5<br>
	�	1988-A6<br>
	�	1991-A3<br>
	�	1991-A7<br>
	�	1991a-AA<br>
	�	1991-A7<br>
	�	1991-A8<br>
	�	1995<br>
	�	1998<br>
	�	1999 (=1999-2000 above)<br>
	�	2000 (=2000b above)<br>
	�	2001 (=2001a above)<br>
	�	2002<br>
	�	2004<br>
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='burialfeatures'></a>
	Burial Features
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	This log contains a list of burial features, the number of the burial to which they belong, and their type. It allows users to search for data for a particular burial.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='cdinventory'></a>
	CD Inventory
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	The GPMP strives to keep a copy of all its data on two CDs or DVDs, one in Boston and the other in Giza, and a few items are also in New York. This inventory gives a list of discs and indicates whether they are present or not in each location.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='drawinglog'></a>
	Drawing Log
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	Field drawings have unique designations that consist of a year prefix and a number. The first season in which such a numbering system was used was 1997, and it has continued to be used in subsequent seasons. While the season prefix most commonly is the same as the season in which the drawing was prepared, it is not always the case. Since the 2003 study season, when drawings from previous seasons that were never recorded in the drawing log are discovered, they are given new numbers in the log for the current season. Already existing inked drawings have begun to be added to the drawing log in 2004 as well.<br><br>
	Because artists were not always scrupulous when filling in the drawing log, we have discovered it is necessary to recheck the drawing itself against the log in the database. Once the data is checked and updated, this is noted in the database. This process of checking drawings is currently ongoing as of the date of this writing.<br><br>
	In theory, there should be three versions of every field drawing: an original pencil drawing on mylar (to be archived in Boston), a photocopy of the drawing (to be archived in Giza), and a digital scan. It should be noted that not all drawings have been photocopied to scale. An inventory of these drawings is ongoing in both Boston and Giza and has not been completed as of this writing (June 2004). Therefore, if the database says a drawing is not found in Giza or Boston, it does not mean it is not actually there. If the drawing has been scanned, the number of the CD on which it is stored is listed.<br><br>
	Scans of drawings, when available, can currently be downloaded as a tif file from within the drawing log itself. In the future, these drawings may be made available for viewing in a zoomable format directly online.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='entitylog'></a>
	Entity Log
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	During the 2003 study season, the concept of an entity was developed at the GPMP. An entity was meant to be a descriptive tool that provides the means to assign convenient names to small- and large-scale spatial elements found in an archaeological excavation. Entities were created for a number of areas of the site during the study season but there are still a number of issues that need to be worked out about these before they can be a completely viable tool for analyzing data.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='exoticmaterialregister'></a>
	Exotic Material Register
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	Since 1991, this register has been used for recording stone materials that were brought to the site from other locations.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='featurelog'></a>
	Feature Log
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	Most features from 1991a and earlier seasons have been reassigned new feature numbers. These new feature numbers are used in all records in the database, but the original feature number is also recorded if needed.<br><br>
	No area designation was recorded in the original paper log, but in the 2004 season, areas were listed wherever possible. However, a number of features still need their area(s) numbers filled in by individuals familiar with the area(s) excavated.<br><br>
	Feature forms are only scanned once a feature has been completely excavated and there is no possibility that information will need to be added to the form. Currently, if a feature form is available for a feature, it can be downloaded as a pdf from the feature log or when searching for a particular feature.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='notebookscatalog'></a>
	Notebooks Catalog
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	The notebooks catalog contains a summary of the contents of field notebooks. More than half of the existing notebooks have been converted to pdf format and are available for downloading from within the notebook catalog itself. Notebooks that are available online in pdf format have also been cataloged completely. The remainder only have a limited amount of metadata available. As pdfs are created for these, the metadata will be filled in completely.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='photolog'></a>
	Photo Log
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	The photo log contains the data from the photo logs, along with the images themselves. Ultimately, it will contain all images in the GPMP collection. Currently, most of the 2004 field images have been included, as well as selected images from 2001 and 2002.<br><br>
	All images currently in the database are displayed in a minithumbnail format. Some images have larger views available by clicking on the minithumbnails, and some have a second larger format called a 'printable' available. The format of the images provided through the database is currently under review and the format may change.<br><br>
	A table has been added to the database not included in the original photo log for specialists' items. This can be exported to the specialists' own databases to provide a list of photos related to their materials.<br><br>
	Digital images from 2001 forward were renamed to conform with the new unique numbering system implemented by the GPMP in 2004. To the extent possible, these new numbers were formed from the original number plus a prefix. With the exception of Francis' NK Blocks, which were scanned slides, all of the renamed images were originally shot with a digital camera. The bold-italic part represents the prefix, whereas the remainder of the number is derived from the original image number:<br><br>
	<b>�	Francis' NK Blocks (2003):</b> <b><u>60</u></b>0001-<b><u>60</u></b>0178 (was 0001-0178)<br><br>
	<b>�	Mohsen's Camera (2002):</b>  <b><u>6</u></b>01119-<b><u>6</u></b>01137 (was DSC01119-DSC01137)<br><br>
	<b>�	2002 Objects images:</b> 601138-602439 (original images were named by their object number. A photolog has been created to keep this data after renaming)<br><br>
	<b>�	All 2001 images (except the 'x-files', see below):</b> <b><u>60</u></b>3717-<b><u>60</u></b>5644 (was DSCN3717-DSCN5644)<br><br>
	<b>�	2003 AQMP images:</b> <b><u>60</u></b>6045-<b><u>60</u></b>6250 (was DSC0045-DSC0250)<br><br>
	<b>�	Kevin's Camera (2002):</b> <b><u>70</u></b>0001-<b><u>70</u></b>2390 (was DSCN0001-DSCN2390)<br><br>
	<b>�	Paul's Camera (2002)</b> had some single digit image numbers he used repeatedly. In order to distinguish these from one another they were given a number that consisted of the prefix 70, the month in which they were shot (3 or 4), the date (starting with 0 if a single digit date) plus the image number. For example, image 703054 was image 4 shot on March 5. The number of these images fall between 703041 and 704183.<br><br>
	<b>�	Paul's Camera (unique numbers from 2002):</b> <b><u>705</u></b>001-<b><u>705</u></b>432 (was DSCN0001-DSCN0432)<br><br>
	<b>�	Jessica's Camera (2002):</b> <b><u>705</u></b>589-<b><u>705</u></b>749 (was DSCN0589-DSCN0749)<br><br>
	<b>�	2001 images with the prefix 'X':</b> <b><u>8000</u></b>01-<b><u>8000</u></b>34 (was x01-x34)<br><br>
	<b>�	Wall Trench Photos (2002):</b> <b><u>80</u></b>0923-<b><u>80</u></b>1445 (was DSCN0923-DSCN1445)
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='reportscatalog'></a>
	Reports Catalog
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	This contains an inventory of all sorts of reports (e.g. weekly reports, data structure reports, Mark's dispatches, specialists' reports) and the areas and squares to which they pertain. In some cases, these are available for downloading in rtf format.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='sampleregister'></a>
	Sample Register
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	In the earlier seasons of the GPMP, a sample register was kept. Its function varied over time, and sometimes its contents overlapped with the bag register. The sample register is no longer used and all material is now included in the bag register.<br><br>
	<b>�	1988-89:</b> No separate sample register was found. However, samples found listed in a notebook have been included in the database with this prefix.<br><br>
	<b>�	1988-89(c):</b> No separate sample register found. However, charcoal samples found in a notebook have been included in the database with this prefix.<br><br>
	<b>�	1991 spring (Area A7):</b> Two separate sample registers were used, each starting with 1, one for flot samples (f) and one for charcoal (c) samples. These samples were not included in the bag register.<br><br>
	<b>�	1991a (Area A7):</b> Six separate sample registers were used, each starting with 1, to some extent divided by feature supervisors but not entirely so. It was used for charcoal, soil, float, slag, bone and unidentified samples. These samples were not included in the bag register. According to John's notebook, prior to October 21, charcoal samples were collected as bags.<br><br>
	<b>�	1991a (Area A8):</b>  A separate sample register was used, starting with 1. It was used for charcoal, flot and pigment. These samples were not included in the bag register. In the database, these items are entered with their reassigned feature numbers (the old feature numbers can be found in the comments field).<br><br>
	<b>�	1995:</b> Only 4 samples exist, all of which are soil. Some have been given bag numbers as well.<br><br>
	<b>�	1997:</b> A running sequence of sample numbers was used, starting with 1. Only in a few cases have the samples been given bag numbers as well. It is used for flot, bone and pigment.<br><br>
	<b>�	1998:</b> A running sequence of sample numbers was used, starting with 1. All samples have bag numbers as well. It was used for flot, wet sieve, and special residues.<br><br>
	<b>�	1999, spring 2000:</b> A running sequence of sample numbers was used in fall 1999, starting with 1, and continued in spring 2000. All samples have bag numbers as well. It was used for flot, mineral, pigment, plaster and metal. A number of 1991a flot samples are included.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;



	case "issuesandbugs":

	echo"
	<tr bgcolor='#333333'><td class='helptextyellow'>
	List of content
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	<a class='whitelink' href='#introduction'>introduction</a><br>
	<a class='whitelink' href='#browser'>browser support</a><br>
	<a class='whitelink' href='#download'>download of txt and pdf files</a><br>
	<a class='whitelink' href='#logout'>prompt for username and password after logout</a><br>
	<a class='whitelink' href='#saving'>saving huge query results as pdf</a><br>
	<a class='whitelink' href='#timeout'>timeout of user login</a>
	</td></tr>
	<tr><td class='emptyline' height='30'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='introduction'></a>
	introduction
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	this section holds information about unresolved issues and bugs within the gpmp excavation database. as with any other computer program there are cases where the software does not operate as expected. this can be caused by incompatabilities between hard- and software (on the internet server or on the user's computer) or by specific programming bugs / software restrictions.<br>
	only problems that cannot be solved within reasonable time or are not solvable at all are listed here.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='browser'></a>
	browser support
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	it has been reported that mozilla and internet explorer react differently to some pages of the gpmp excavation database. [nicole: please details!]
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='download'></a>
	download of txt and pdf files
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	the query result can only be saved as txt or pdf after the resultspage has been fully loaded. please be patient before you click on 'save as txt' or 'save as pdf'.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

	<tr bgcolor='#333333'><td class='helptextyellow'><a name='logout'></a>
	prompt for username and password after logout
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	once you log out of the gpmp excavation database you will be prompted to enter your username and password. this is normal and indicates that you have logged out successfully. entering your username and password now will result in an error. if you wish to enter the database again close your browser and open a new one with the 'www.gpmpdb.net' URL.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'><a name='saving'></a>
	saving huge query results as pdf
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	due to a five minute scripting timeout on the server side, any pdf document that takes longer than that will not be produced. to work around this problem you will have to reduce the size of information included in your query results and then try again to produce the pdf output.
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
	
	<tr bgcolor='#333333'><td class='helptextyellow'><a name='timeout'></a>
	timeout of user login
	</td></tr>
	<tr bgcolor='#1A1F2D'><td class='helptext'>
	it has been reported that some browser versions [nicole: please details!] do not automatically timeout a user session after 10 minutes. to reduce the risk of unwanted access to gpmp information, please make sure that you always logout from the database when you are done working with it!
	</td></tr>
	<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
	break;

}

echo"</table>";

if ($fullscreen=='yes')
{
	echo'
		<script language="JavaScript">
		<!--
		if (window.print){ window.print(); }
		// -->
		</script>
	';
}

?>