<?php

include 'authentication.php';

echo '
<frameset rows="18,*" border=0 width=0 frameborder=no framespacing=0> 
  <frame src="./indextabs.php" name="indextabs" marginwidth=0 marginheight=0 scrolling=no>
  <frame src="./indexstart.php" name="indexcontent" noresize>
</frameset>
<plaintext> <noframes> 
<body bgcolor="#FFFFFF" text="#000000">
</body>
</noframes> 
</html>';
?>