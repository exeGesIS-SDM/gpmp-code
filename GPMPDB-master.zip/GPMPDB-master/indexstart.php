<?php

include 'authentication.php';


// remove session variables
	unset($query);
	unset($savename);
	unset($query);
	unset($title);
	unset($outputcolumn);
	unset($outputcolumns);
	unset($keynumberofcolumns);
	unset($keycolumn);
	unset($keyquery);
	unset($keysort);

	$_SESSION['sessionquery']=$query;
	$_SESSION['sessionsavename']=$savename;
	$_SESSION['sessionquery']=$query;
	$_SESSION['sessiontitle']=$title;
	$_SESSION['sessionoutputcolumn']=$outputcolumn;
	$_SESSION['sessionoutputcolumns']=$outputcolumns;
	$_SESSION['sessionkeynumberofcolumns']=$keynumberofcolumns;
	$_SESSION['sessionkeycolumn']=$keycolumn;
	$_SESSION['sessionkeyquery']=$keyquery;
	$_SESSION['sessionkeysort']=$keysort;

//changed by Simon

	// unset($_SESSION['sessionquery']);
	// unset($_SESSION['sessionsavename']);
	// unset($_SESSION['sessionquery']);
	// unset($_SESSION['sessiontitle']);
	// unset($_SESSION['sessionoutputcolumn']);
	// unset($_SESSION['sessionoutputcolumns']);
	// unset($_SESSION['sessionkeynumberofcolumns']);
	// unset($_SESSION['sessionkeycolumn']);
	// unset($_SESSION['sessionkeyquery']);
	// unset($_SESSION['sessionkeysort']);

	$PHP_self=substr($_SERVER['REQUEST_URI'],1,999);//$_SERVER['PHP_SELF'];
	$PHP_SELF=substr($_SERVER['REQUEST_URI'],1,999);

	/*
	if(!isset($indexaction)) $indexaction='';
	if(!isset($menuaction)) $menuaction='';
	if(!isset($filedownload)) $filedownload='';
	if(!isset($_SESSION['sessionfiledownload'])) $_SESSION['sessionfiledownload']='';
	if(!isset($keyidname)) $keyidname=false;
	if(!isset($commit)) $commit=false;
	if(!isset($_SESSION['alldata'])) $_SESSION['alldata']=false;
	if(!isset($deleteline)) $deleteline=false;
	if(!isset($editline)) $editline=false;
	if(!isset($editdata)) $editdata=array();
	if(!isset($count)) $count=0;
	if(!isset($columns)) {
		$columns="1";
		$columnnames[1] = "";
		$columnheader[1] = "";
		$fieldtype[1] = "";
		$fieldlength[1] = "";
		$fieldsize[1] = "";
		$fieldcolumnwidth[1] = "";
		$defaultvalue[1] = "";
	}
	if(!isset($edit)) $edit=false;
	*/



// check if user wants to see linked media

	//check if session variable already exists

	if (!$filedownload)
	{
		if ($_SESSION['sessionfiledownload']!="")
		{
			$filedownload=$_SESSION['sessionfiledownload'];
			$casetest="1".$filedownload;
		}
		else
		{
			$filedownload="no";
			$casetest="2".$filedownload;
		}
	}
	elseif ($filedownload!="")
	{
		$_SESSION['sessionfiledownload']=$filedownload;
		$casetest="3".$filedownload;
	}

// layout position definitions

$left = 0;
$top = 0;


 echo'

<body bgcolor="#000000" text="#000000">';
// <div id="Layer1" style="position:absolute; left:'.$left.'px; top:'.$top.'px; width:800; height:573px; z-index:1;  background-color: #212838; layer-background-color: #212838;">';


// include 'menutabs.php';

include 'menumain.php';

echo'
</body>
</html>';

?>