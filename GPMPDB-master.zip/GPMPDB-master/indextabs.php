<?php

include 'authentication.php';

echo'
<html>
<head>
<style>.clScroll {font-family:Geneva, Arial, Helvetica, san-serif;font-size:11pt;font-weight:bold;font-style:italic;color:#FFFFFF;cursor:default;line-height:10pt;}
.tabs {  font-family: Geneva, Arial, Helvetica, san-serif; font-size: 12px; font-weight: bold}
</style>
</head>
<body bgcolor="#8C7264" topmargin=0 leftmargin=0>
<table cellpadding=0 cellspacing=0 width=100% border="1" bordercolor="#000000">
  <tr>
    <td width="221" valign=top class="clScroll" nowrap>GPMP Excavation Database</td>
    <td valign=top bgcolor="#AE8960" width="46" class="tabs">
      <div align="center"><a href="./indexstart.php" target="indexcontent">
	  <font color="#000000">Home</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="64" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=browse" target="indexcontent">
	  <font color="#000000">Browse</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="60" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=query" target="indexcontent">
	  <font color="#000000">Query</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="43" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=add" target="indexcontent">
	  <font color="#000000">Add</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="82" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=editdelete" target="indexcontent">
	  <font color="#000000">Edit/Delete</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="95" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=introduction" target="indexcontent">
	  <font color="#000000">Introduction</font></a></div></td>
    <td valign=top bgcolor="#AE8960" width="44" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=help" target="indexcontent">
	  <font color="#000000">Help</font></a></div></td>
    <!--<td valign=top bgcolor="#AE8960" width="82" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=feedback&menuaction=feedback" target="indexcontent">
	  <font color="#000000">Feedback</font></a></div></td> -->
    <td valign=top bgcolor="#AE8960" width="54" class="tabs">
      <div align="center"><a href="./indexstart.php?indexaction=logout&logout=yes" target="indexcontent">
	  <font color="#000000">Logout</font></a></div></td>
	<td width="190"/>
  </tr>
</table>
</body></html>
';
?>