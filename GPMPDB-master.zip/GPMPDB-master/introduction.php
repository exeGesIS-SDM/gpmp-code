<?php

if ($fullscreen=='yes')
{
	include 'authentication.php';
	echo'<body bgcolor="#000000" text="#000000">';
}


	echo"<table width='100%'>
		<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
		  <tr bgcolor='#333333'> 
		    <td class='heading' valign='top' colspan='5' height='30'>INTRODUCTION</td>
		  </tr>
		  <tr><td class='emptyline' height='5'>&nbsp;</td></tr>";

	if (!$fullscreen)
	{
		echo "<tr bgcolor='#1A1F2D'><td>";
		printf ("<a class='yellowlink' href=\"introduction.php?fullscreen=%s&indexaction=%s\" target=\"_blank\">
			printable version</a>", 'yes', $indexaction);
		echo "</td></tr>
			<tr><td class='emptyline' height='5'>&nbsp;</td></tr>";
	}

echo"
<tr bgcolor='#1A1F2D'><td class='helptext'>
this short introduction will provide you with all the basic information about the gpmp excavation database that will get you going. for more detailed information please consult the 'help' area.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>


<tr bgcolor='#333333'><td class='helptextyellow'>
security
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
you will have noticed when you logged onto this web page that you had to enter a username and password. this is, of course, for security reasons - all our excavation data is out there on the internet and we have to make sure that nobody tempers with it. it is, therefore, your personal responsibility to keep your username and password secret. in this database we are handling confidential research data and any misuse is monitored and can be tracked down.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>


<tr bgcolor='#333333'><td class='helptextyellow'>
access levels
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
there are several access levels to the database and according to your position within the gpmp you will be able to use only specific parts (e.g. if you are an excavator you will only be able to read data, if you are involved with data entry you will be able to read and write data, etc.). your access level was set up with your username and password. should you need additional access to restricted areas please contact the database administrator in charge.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

<tr bgcolor='#333333'><td class='helptextyellow'>
database contents
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
nicole, please send info for this!
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

<tr bgcolor='#333333'><td class='helptextyellow'>
database structure
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
the gpmp excavation database is powered by a postgreSQL database which runs on a linux server hosted by pghoster.com. the user interface was programmed using PHP, HTML and JavaScript.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

<tr bgcolor='#333333'><td class='helptextyellow'>
interface structure
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
there are four main areas where tasks can be performed:<br>
- <b>browse:</b> here you can access all field records and query them according to your specifications<br>
- <b>query:</b> go here if you need specific, more processed information on field records<br>
- <b>add/edit/delete:</b> this is a restricted area and can only be accessed by a data entry person. field records are added/edited and deleted here.<br>
if you can't find a way of retrieving the information you need, a special query can be designed for you which will be put into the 'query' area. please use the 'feedback' area to send us the details of your query.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

<tr bgcolor='#333333'><td class='helptextyellow'>
viewing and saving search results
</td></tr>
<tr bgcolor='#1A1F2D'><td class='helptext'>
after you have selected a browse or query option the result will appear in a standardized format.<br>
the <b>header</b> of each result contains the title of your search, a short description and the number of retrieved result rows, all displayed on the left. on the right side you have the option to export the result table as a text (tab-delimited) or PDF file. use the text option if you want to process the results in your own spreadsheet program or database. use the PDF option if you are only interested in a preformatted, ready to print copy of your query.<br>
under the header you will find the <b>sort/search bar</b>. use sort for applying a custom sort order for up to three columns. use the freetext search option to limit your query results further to specific search strings.<br>
under the sort/search bar you can see the <b>page selection bar</b> if your result table contains more than 100 rows. to reduce the download time to your computer, the result is split up in packages of 100 rows and each package can be retrieved by selecting the appropriate result page. the pages are identified by the current primary sort column (which may change if you adjust the sort order) and each page is represented by the value of the first record followed by a '+' symbol indicating that the page contains records that start with this identifier.
</td></tr>
<tr><td class='emptyline' height='10'>&nbsp;</td></tr>

</table>";
		
if ($fullscreen=='yes')
{
	echo'
		<script language="JavaScript">
		<!--
		if (window.print){ window.print(); }
		// -->
		</script>
	';
}
?>