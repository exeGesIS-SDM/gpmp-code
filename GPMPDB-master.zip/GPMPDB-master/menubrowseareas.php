<?php


$queryarray['browsebybroadareacode'] = "select distinct broadareas.broadareacode
										FROM fielddata.broadareas
										WHERE broadareas.valid=true
										ORDER BY broadareas.broadareacode;";

$queryarray['browsebylocalareacode'] = "select distinct localareas.localareacode
										FROM fielddata.localareas
										WHERE localareas.valid=true
										ORDER BY localareas.localareacode;";

$queryarray['browsebysupervisor'] = "select distinct localareasexcavators.supervisor
										FROM fielddata.localareasexcavators
										WHERE localareasexcavators.valid=true
										ORDER BY localareasexcavators.supervisor;";

$queryarray['browsebysquare'] = "select distinct localareassquares.squarename
										FROM fielddata.localareassquares
										WHERE localareassquares.valid=true
										ORDER BY localareassquares.squarename;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';


	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse broad and local areas</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="3">
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browseallareas">
					complete log</a></td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  by broad area code</p></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebybroadareacode'];

			$formname="listbroadareacodes";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebybroadareacode";
			$selectname="broadareacode";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  by local area code</p></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebylocalareacode'];

			$formname="listlocalareacodes";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebylocalareacode";
			$selectname="localareacode";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  by supervisor</p></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysupervisor'];

			$formname="listsupervisors";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysupervisor";
			$selectname="supervisor";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  by square</p></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysquare'];

			$formname="listsquares";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysquare";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
  </table>';
}

	include 'componentbrowseareas.php';

?>