<?php

$queryarray['browsebyfeature']="SELECT DISTINCT featurenumber FROM fielddata.bagregister WHERE bagregister.valid=true ORDER BY featurenumber;";
$queryarray['browsebycategory']="SELECT DISTINCT bagcategory FROM fielddata.listbagcategories WHERE listbagcategories.valid=true ORDER BY bagcategory;";

if (!$submenuaction)
{
	echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse bag register</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="5"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompleteregister"><font color="#FFFFFF">
					complete register</a></td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by single bag</p></td>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesinglebag" method="POST">
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4">
					<div class="menutext"><input class="text" type="text" name="bagnumber" size="4" maxlength="5">
			        	bag no.</div>
					</td>
				</tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="5">
					<div class="menutext"><input class="text" type="text" name="featurenumber" size="4" maxlength="5">
			        	feature no.</div>
					</td>
				</tr>
			    <tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4">
					<div class="menutext"><input class="text" type="text" name="bagprefix" size="6" maxlength="8">
			        	bagprefix</div>
					</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="4">
				<p class="menutext">
					by series of bags</p></td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsebagseries" method="POST">
				<tr>
					<td width="14">&nbsp;</td>
					<td width="5">&nbsp; </td>
					<td colspan="5">
					<div class="menutext"><input class="text" type="text" name="firstbagnumber" size="4" maxlength="5">
					        to
					    <input class="text" type="text" name="lastbagnumber" size="4" maxlength="5"></div></td>
			    </tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="5">
					<div class="menutext"><input class="text" type="text" name="featurenumber" size="4" maxlength="5">
			        	feature no.</div>
					</td>
				</tr>
			    <tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="2">
					<div class="menutext"><input class="text" type="text" name="bagprefix" size="6" maxlength="8">
			        	bagprefix</div></td>
				</tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by feature</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyfeature'];

			$formname="listfeaturenumber";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyfeature";
			$selectname="featurenumber";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by category</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebycategory'];

			$formname="listbagcategory";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebycategory";
			$selectname="category";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
  </table>';

}

	include 'componentbrowsebagregister.php';

?>