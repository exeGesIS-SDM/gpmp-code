<?php


if (!$submenuaction)
{
	echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'		  
  <table border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="2" height="26"><p class="menuheading">
				  browse burial features</p></td>
		    </tr>
	
			<tr> 
     			<td width="5">&nbsp;</td>
				<td>
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompleteregister">
					complete register</a>
    			</td>
		    </tr>

  </table>';
}

	include 'componentbrowseburialfeatures.php';
	
?>