<?php

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';
		
	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  browse cd inventory</p></td>
		    </tr>
	
			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompleteinventory"><font color="#FFFFFF">
					complete inventory</a></td>
		    </tr>

  </table>';
}

	include 'componentbrowsecdinventory.php';
	
?>