<?php

$queryarray['browsebyseason']="SELECT DISTINCT season FROM fielddata.drawinglog WHERE drawinglog.valid=true ORDER BY season;";
$queryarray['browsebysquare']="SELECT DISTINCT squarename FROM fielddata.drawinglogsquares WHERE drawinglogsquares.valid=true ORDER BY squarename;";
$queryarray['browsebyarea']="select distinct drawinglog.area from fielddata.drawinglog where drawinglog.valid=true ORDER BY drawinglog.area;";
$queryarray['browsebyfeature']="select distinct drawinglogfeatures.featurenumber from fielddata.drawinglogfeatures where drawinglogfeatures.valid=true ORDER BY drawinglogfeatures.featurenumber;";
$queryarray['browsebysupervisor']="select distinct drawinglogsupervisors.supervisor from fielddata.drawinglogsupervisors where drawinglogsupervisors.valid=true ORDER BY drawinglogsupervisors.supervisor;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse drawing log</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="5"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompletelog"><font color="#FFFFFF">
					complete log</a>
    			</td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by single drawing</p></td>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesingledrawing" method="POST">
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4">
					<div class="menutext"><input class="text" type="text" name="drawingnumber" size="4" maxlength="5">
			        	drawing no.</div>
					</td>
				</tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="5">
					<div class="menutext"><input class="text" type="text" name="season" size="4" maxlength="5">
			        	season</div>
					</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="4"><p class="menutext">
					by series of drawings</p></td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsedrawingseries" method="POST">
				<tr>
					<td width="14">&nbsp;</td>
					<td width="5">&nbsp; </td>
					<td colspan="5"><div class="menutext">
						<input class="text" type="text" name="firstdrawingnumber" size="4" maxlength="5">
					        to
					    <input class="text" type="text" name="lastdrawingnumber" size="4" maxlength="5"></div></td>
			    </tr>
			    <tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="2"><div class="menutext">
					<input class="text" type="text" name="season" size="4" maxlength="5">
			        	season</div></td>
				</tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
			</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by season</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyseason'];

			$formname="listseasons";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyseason";
			$selectname="season";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by square</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysquare'];

			$formname="listsquarename";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysquare";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by area</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyarea'];

			$formname="listareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyarea";
			$selectname="area";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by feature</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyfeature'];

			$formname="listfeatures";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyfeature";
			$selectname="featurenumber";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by artist</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysupervisor'];

			$formname="listsupervisors";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysupervisor";
			$selectname="supervisor";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


  </table>';
}

	include 'componentbrowsedrawinglog.php';

?>