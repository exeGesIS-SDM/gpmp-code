<?php

$queryarray['browsebyentitytype']="SELECT DISTINCT entitytype FROM fielddata.entitylog WHERE entitylog.valid=true ORDER BY entitytype;";
$queryarray['browsebyexcavationarea']="SELECT DISTINCT excavationarea FROM fielddata.entitylog WHERE entitylog.valid=true ORDER BY excavationarea;";
$queryarray['browsebysupervisor']="SELECT DISTINCT supervisor FROM fielddata.entitylog WHERE entitylog.valid=true ORDER BY supervisor;";


if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse entity log</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="3"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompletelog"><font color="#FFFFFF">
					complete log</a></td>
		    </tr>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by entity number</p></td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesingleentity" method="POST">
				<tr>
			    	<td width="10">&nbsp;</td>
			    	<td width="9">&nbsp; </td>
			    	<td width="64">
			        	<input class="text" "type="text" name="entitynumber" size="4" maxlength="5">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by series of entities</p></td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browseentityseries" method="POST">
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td colspan="2"><div class="menutext">
						<input class="text" type="text" name="firstentitynumber" size="4" maxlength="5">
					        to
					    <input class="text" "type="text" name="lastentitynumber" size="4" maxlength="5"></div></td>
			    </tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by entitytype</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyentitytype'];

			$formname="listentitytypes";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyentitytype";
			$selectname="entitytype";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by excavation area</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyexcavationarea'];

			$formname="listexcavationareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyexcavationarea";
			$selectname="excavationarea";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by supervisor</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysupervisor'];

			$formname="listsupervisors";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysupervisor";
			$selectname="supervisor";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


  </table>';
}

	include 'componentbrowseentitylog.php';

?>