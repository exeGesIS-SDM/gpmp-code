<?php

$queryarray['browsebyfeature']="SELECT DISTINCT featurenumber FROM fielddata.exoticmaterialregister WHERE exoticmaterialregister.valid=true ORDER BY featurenumber;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="4" height="26"><p class="menuheading">
				  browse exotic material register</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="3"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompleteregister">
					complete register</a></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by feature</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyfeature'];

			$formname="listfeaturenumber";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyfeature";
			$selectname="featurenumber";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
  </table>';
}

	include 'componentbrowseexoticmaterialregister.php';

?>