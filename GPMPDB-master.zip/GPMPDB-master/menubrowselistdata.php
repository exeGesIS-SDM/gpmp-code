<?php

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  browse list tables</p></td>
		    </tr>';
	
	$numberoflisttables = 9;
	$listtablename[1] = 'areas';
		$listtablelink[1] = 'listareas';
	$listtablename[2] = 'bag categories';
		$listtablelink[2] = 'listbagcategories';
	$listtablename[3] = 'entity types';
		$listtablelink[3] = 'listentitytypes';
	$listtablename[4] = 'excavators';
		$listtablelink[4] = 'listexcavators';
	$listtablename[5] = 'exotic material categories';
		$listtablelink[5] = 'listexoticmaterialcategories';
	$listtablename[6] = 'feature type groups';
		$listtablelink[6] = 'listfeaturetypegroups';
	$listtablename[7] = 'feature types';
		$listtablelink[7] = 'listfeaturetypes';
	$listtablename[8] = 'sample types';
		$listtablelink[8] = 'listsampletypes';
	$listtablename[9] = 'site seasons';
		$listtablelink[9] = 'listsiteseasons';
		
	for	($i=1; $i<=$numberoflisttables; $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
		

echo '</table>';
}

	include 'componentbrowselistdata.php';
	
?>