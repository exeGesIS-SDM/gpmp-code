<?php

$queryarray['browsebyfeature']="SELECT DISTINCT photologfeatures.featurenumber FROM fielddata.photologfeatures WHERE photologfeatures.valid=true ORDER BY photologfeatures.featurenumber;";
$queryarray['browsebyarea']="SELECT DISTINCT photologareas.area FROM fielddata.photologareas WHERE photologareas.valid=true ORDER BY photologareas.area;";
$queryarray['browsebysquare']="SELECT DISTINCT photologsquares.squarename FROM fielddata.photologsquares WHERE photologsquares.valid=true ORDER BY photologsquares.squarename;";
$queryarray['browsebyphotographer']="SELECT DISTINCT photolog.photographer FROM fielddata.photolog WHERE photolog.valid=true ORDER BY photolog.photographer;";
$queryarray['browsebyindex']="SELECT DISTINCT photologindex.indexcode FROM fielddata.photologindex WHERE photologindex.valid=true ORDER BY photologindex.indexcode;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
		  <table border="0" bgcolor="#333333">

		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse photolog</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="4">
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompletelog&includeimage=yes">
					complete log</a></td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by imagenumber</p></td>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesinglephoto&includeimage=yes" method="POST">
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4">
					<div class="menutext"><input class="text" type="text" name="imagenumber" size="4" maxlength="6">
			       		</div>
					</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="4"><p class="menutext">
					by series of imagenumbers</p></td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsephotoseries&includeimage=yes" method="POST">
				<tr>
					<td width="14">&nbsp;</td>
					<td width="5">&nbsp; </td>
					<td colspan="5"><div class="menutext">
						<input class="text" type="text" name="firstimagenumber" size="4" maxlength="6">
					        to
					    <input class="text" type="text" name="lastimagenumber" size="4" maxlength="6"></div></td>
			    </tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
			</tr>
			</form>


			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by feature</p></td>
		    </tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyfeature'];

			$formname="listfeatures";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyfeature&includeimage=yes";
			$selectname="featurenumber";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by area</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyarea'];

			$formname="listareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyarea&includeimage=yes";
			$selectname="area";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by square</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysquare'];

			$formname="listsquarename";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysquare&includeimage=yes";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by photographer</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyphotographer'];

			$formname="listareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyphotographer&includeimage=yes";
			$selectname="photographer";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by index code</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyindex'];

			$formname="listindexes";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyindex&includeimage=yes";
			$selectname="indexcode";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by specialist information</p></td>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsebyspecialistinfo&includeimage=yes" method="POST">
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = "select distinct listspecialistcategories.specialistcategory
				from fielddata.listspecialistcategories
				where listspecialistcategories.valid=true
				order by listspecialistcategories.specialistcategory;";

			$selectnoform='yes';
			$selectname="specialistcategory";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="5">
					<div class="menutext"><input class="text" type="text" name="specialistid" size="12" maxlength="15">
			        	specialist id</div>
					</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>

	</table>';
}

		include 'componentbrowsephotolog.php';

?>