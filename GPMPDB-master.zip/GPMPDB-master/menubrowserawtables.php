<?php

	$tablecounter=0;
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'bagregister';
		$rawtablelink[$tablecounter] = 'bagregister';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'bagregistersquares';
		$rawtablelink[$tablecounter] = 'bagregistersquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'burialfeatures';
		$rawtablelink[$tablecounter] = 'burialfeatures';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'broadareas';
		$rawtablelink[$tablecounter] = 'broadareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'broadareaslocalareas';
		$rawtablelink[$tablecounter] = 'broadareaslocalareas';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'cdinventory';
		$rawtablelink[$tablecounter] = 'cdinventory';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'drawinglog';
		$rawtablelink[$tablecounter] = 'drawinglog';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'drawinglogfeatures';
		$rawtablelink[$tablecounter] = 'drawinglogfeatures';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'drawinglogsquares';
		$rawtablelink[$tablecounter] = 'drawinglogsquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'drawinglogsupervisors';
		$rawtablelink[$tablecounter] = 'drawinglogsupervisors';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'entitylog';
		$rawtablelink[$tablecounter] = 'entitylog';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'entitylogchanges';
		$rawtablelink[$tablecounter] = 'entitylogchanges';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'entitylogdefinedbyfeaturenumbers';
		$rawtablelink[$tablecounter] = 'entitylogdefinedbyfeaturenumbers';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'entitylogincludesentitynumbers';
		$rawtablelink[$tablecounter] = 'entitylogincludesentitynumbers';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'entitylogincludesfeaturenumbers';
		$rawtablelink[$tablecounter] = 'entitylogincludesfeaturenumbers';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'exoticmaterialregister';
		$rawtablelink[$tablecounter] = 'exoticmaterialregister';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'exoticmaterialregistersquares';
		$rawtablelink[$tablecounter] = 'exoticmaterialregistersquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'featurelog';
		$rawtablelink[$tablecounter] = 'featurelog';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'featurelogareas';
		$rawtablelink[$tablecounter] = 'featurelogareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'featurelogsquares';
		$rawtablelink[$tablecounter] = 'featurelogsquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'featurelogsupervisors';
		$rawtablelink[$tablecounter] = 'featurelogsupervisors';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'localareas';
		$rawtablelink[$tablecounter] = 'localareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'localareasexcavators';
		$rawtablelink[$tablecounter] = 'localareasexcavators';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'localareassquares';
		$rawtablelink[$tablecounter] = 'localareassquares';
	$tablecounter++;
		
	$rawtablename[$tablecounter] = 'notebookscatalog';
		$rawtablelink[$tablecounter] = 'notebookscatalog';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'notebookscatalogareas';
		$rawtablelink[$tablecounter] = 'notebookscatalogareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'notebookscatalogsquares';
		$rawtablelink[$tablecounter] = 'notebookscatalogsquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'notebookscatalogsupervisors';
		$rawtablelink[$tablecounter] = 'notebookscatalogsupervisors';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photolog';
		$rawtablelink[$tablecounter] = 'photolog';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photologareas';
		$rawtablelink[$tablecounter] = 'photologareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photologfeatures';
		$rawtablelink[$tablecounter] = 'photologfeatures';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photologindex';
		$rawtablelink[$tablecounter] = 'photologindex';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photologspecialists';
		$rawtablelink[$tablecounter] = 'photologspecialists';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'photologsquares';
		$rawtablelink[$tablecounter] = 'photologsquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'reassignedfeatures';
		$rawtablelink[$tablecounter] = 'reassignedfeatures';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'reportscatalog';
		$rawtablelink[$tablecounter] = 'reportscatalog';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'reportscatalogareas';
		$rawtablelink[$tablecounter] = 'reportscatalogareas';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'reportscatalogsquares';
		$rawtablelink[$tablecounter] = 'reportscatalogsquares';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'reportscatalogauthors';
		$rawtablelink[$tablecounter] = 'reportscatalogauthors';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'sampleregister';
		$rawtablelink[$tablecounter] = 'sampleregister';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'synopticfeatureform';
		$rawtablelink[$tablecounter] = 'synopticfeatureform';


if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  browse raw tables</p></td>
		    </tr>
			<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="yellowlink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=checkforchanges">
			 	check for changes</a></td>
		    </tr>
			<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="yellowlink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=directdownload">
			 	direct download</a></td>
		    </tr>
			<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="yellowlink" href="'.$sitebasefile.'?indexaction=rawtablesmetadata">
			 	read meta data</a></td>
		    </tr>
			<tr><td class="emptyline" colspan="2" height="5">&nbsp;</td></tr>';
			

	for	($i=1; $i<=count($rawtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$rawtablelink[$i].'">
			 '.$rawtablename[$i].'</a></td>
		    </tr>';
	}
		

echo '</table>';
}

	include 'componentbrowserawtables.php';
	
?>