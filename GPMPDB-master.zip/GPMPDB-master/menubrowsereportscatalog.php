<?php

$queryarray['browsebyarea']="SELECT DISTINCT area FROM fielddata.reportscatalogareas WHERE reportscatalogareas.valid=true ORDER BY area;";
$queryarray['browsebyauthor']="select distinct listexcavators.fullnames from fielddata.listexcavators right join fielddata.reportscatalogauthors on listexcavators.initials = reportscatalogauthors.author WHERE reportscatalogauthors.valid=true and listexcavators.valid=true order by listexcavators.fullnames;";
$queryarray['browsebysquare']="SELECT DISTINCT squarename FROM fielddata.reportscatalogsquares WHERE reportscatalogsquares.valid=true ORDER BY squarename;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
		  <table border="0" bgcolor="#333333">';

			echo'
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse reportscatalog</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="3">
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompletelog">
					complete log</a></td>
		    </tr>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by area</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyarea'];
			$formname="listsareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyarea";
			$selectname="area";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by author</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyauthor'];

			$formname="listauthors";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyauthor";
			$selectname="author";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>



			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by square</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysquare'];

			$formname="listsquarename";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysquare";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>';


echo'</table>';
}

		include 'componentbrowsereportscatalog.php';

?>