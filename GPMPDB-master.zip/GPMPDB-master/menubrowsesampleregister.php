<?php

$queryarray['browsebyfeature']="SELECT DISTINCT featurenumber FROM fielddata.sampleregister WHERE sampleregister.valid=true ORDER BY featurenumber;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';


	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse sample register</p></td>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="5">
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompleteregister">
					complete register</a>
    			</td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="4"><p class="menutext">
				  by single sample</p></td>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesinglesample" method="POST">
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4"><div class="menutext"><input class="text" type="text" name="samplenumber" size="4" maxlength="5">
			        	sample no.</td></div>
				</tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="5"><div class="menutext"><input class="text" type="text" name="featurenumber" size="4" maxlength="5">
			        	feature no.</td></div>
				</tr>
			    <tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="4"><div class="menutext"><input class="text" type="text" name="year" size="4" maxlength="4">
			        	year</td></div>
				</tr>
				<tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="4"><p class="menutext">
					by series of samples</p>
				</td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesampleseries" method="POST">
				<tr>
					<td width="14">&nbsp;</td>
					<td width="5">&nbsp; </td>
					<td colspan="5">
					<div class="menutext">
						<input class="text" type="text" name="firstsamplenumber" size="4" maxlength="5">
						    to
					    <input class="text" type="text" name="lastsamplenumber" size="4" maxlength="5"></div>
					</td>
			    </tr>
				<tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
					<td colspan="5"><div class="menutext">
					<input class="text" type="text" name="featurenumber" size="4" maxlength="5">
						feature no.</div></td>
				</tr>
			    <tr>
			    	<td width="14">&nbsp;</td>
			    	<td width="5">&nbsp; </td>
			    	<td colspan="2"><div class="menutext">
					<input class="text" type="text" name="year" size="4" maxlength="5">
			        	year </div></td>
				</tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><b><font face="Geneva, Arial, Helvetica, san-serif" size="1"><font color="#FFFFFF">
					by feature</font></font></b></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyfeature'];

			$formname="listfeaturenumber";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyfeature";
			$selectname="featurenumber";

			include 'modulecreatevaluelist.php';


		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
  </table>';
}

	include 'componentbrowsesampleregister.php';

?>