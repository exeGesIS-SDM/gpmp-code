<?php

$queryarray['browsebyarea']="SELECT DISTINCT area FROM fielddata.featurelogareas WHERE featurelogareas.valid=true ORDER BY area;";
$queryarray['browsebymatrixgroupnumber']="SELECT DISTINCT matrixgroupnumber FROM fielddata.synopticfeatureform WHERE synopticfeatureform.valid=true ORDER BY matrixgroupnumber;";
$queryarray['browsebysquare']="select distinct featurelogsquares.squarename
					from fielddata.synopticfeatureform left join fielddata.featurelogsquares on synopticfeatureform.featurenumber = featurelogsquares.featurenumber
					where (((featurelogsquares.squarename) is not null)) and featurelogsquares.valid=true and synopticfeatureform.valid=true
					ORDER BY featurelogsquares.squarename;";

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';


	echo'
	  <table border="0" bgcolor="#333333">
		    <tr valign="bottom">
      			<td colspan="5" height="26"><p class="menuheading">
				  browse synoptic feature form</p>
		    </tr>

			<tr>
     			<td width="14">&nbsp;</td>
     			<td colspan="3"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsecompletelog">
					complete log</a></td>
		    </tr>

			<tr>
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  by feature number</p>
		    </tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsesinglefeature" method="POST">
				<tr>
			    	<td width="10">&nbsp;</td>
			    	<td width="9">&nbsp; </td>
			    	<td width="64">
			        	<input class="text" "type="text" name="featurenumber" size="4" maxlength="5">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by series of features</p>
				</td>
			</tr>

			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=browsefeatureseries" method="POST">
				<tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td colspan="2">
					<div class="menutext">
						<input class="text" "type="text" name="firstfeaturenumber" size="4" maxlength="5">
						    to
					    <input class="text" type="text" name="lastfeaturenumber" size="4" maxlength="5"></div>
					</td>
			    </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by area</p>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebyarea'];
			$formname="listareas";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebyarea";
			$selectname="area";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by matrixgroupnumber</p>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebymatrixgroupnumber'];
			$formname="listmatrixgroupnumbers";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebymatrixgroupnumber";
			$selectname="matrixgroupnumber";

			include 'modulecreatevaluelist.php';

		echo'	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					by square</p></td>
			</tr>

			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';

			$query = $queryarray['browsebysquare'];

			$formname="listsquarename";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=browsebysquare";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
  </table>';
}

	include 'componentbrowsesynopticfeatureform.php';

?>