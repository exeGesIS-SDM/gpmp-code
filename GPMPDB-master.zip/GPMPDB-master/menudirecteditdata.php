<?php

if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';


	if(!$line[0] and $submit)
	{
		echo"	<table width='100%' border='0' bgcolor='#333333'>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br>The record you want to edit does not exist in database!
				</td></tr>
				<tr><td class='emptyline' height='10'>&nbsp;</td></tr>
				</table>";
	}

	echo'  <table width="250" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="4" height="26">
        <p class="menuheading">direct edit general records</p>
      </td>
    </tr>

    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>bag register</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=bagregister&fastdataentry=yes" method="POST">
      <tr>
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">season prefix
			<input class="text" type="text" name="bagprefix" size="5" maxlength="8">
          </p>
        </td>
        <td width="150">
          <p class="menutext">bag number 
          <input class="text" type="text" name="bagnumber" size="4" maxlength="5">
		  </p>
        </td>
        <td width="60" valign="bottom"> 
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
      </tr>
    </form>

	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>drawing log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=drawinglog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">season prefix
			<input class="text" type="text" name="season" size="5" maxlength="8">
          </p>
        </td>
        <td width="150">
          <p class="menutext">drawing number 
          <input class="text" type="text" name="drawingnumber" size="4" maxlength="5">
		  </p>
        </td>
        <td width="60" valign="bottom"> 
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
      </tr>
    </form>

	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>entity log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=entitylog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">entity number
			<input class="text" type="text" name="entitynumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>
	
	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>feature log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=featurelog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">feature number
			<input class="text" type="text" name="featurenumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>

	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>group log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=grouplog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">group number
			<input class="text" type="text" name="groupnumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>
	
	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>

    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>space log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=spacelog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">space number
			<input class="text" type="text" name="spacenumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>
	
	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>structure log</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=structurelog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">structure number
			<input class="text" type="text" name="structurenumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>
	
	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>
	
	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>synoptic feature form</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=synopticfeatureform&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">feature number
			<input class="text" type="text" name="featurenumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>

	<tr><td class="emptyline" height="5" colspan="5">&nbsp;</td></tr>

	
    <tr> 
      <td colspan="4" bgcolor="#292529">
        <p class="menutext">
		<b>photolog</b></p>
      </td>
    </tr>
    <form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=photolog&fastdataentry=yes" method="POST">
      <tr> 
        <td width="9">&nbsp; </td>
        <td width="150"> 
          <p class="menutext">image number
			<input class="text" type="text" name="imagenumber" size="5" maxlength="8">
          </p>
        </td>
        <td width="150" valign="bottom">
          <input class="submitbutton" type="submit" name="submit" value="edit">
        </td>
        <td width="60">&nbsp;
        </td>
      </tr>
    </form>

  </table>';
}

if ($submenuaction)
{
	include 'componenteditdata.php';
}
?>