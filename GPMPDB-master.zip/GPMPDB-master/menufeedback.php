<?php
		  
if (!$submenuaction)
{
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
	  <table width="164" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  gpmp excavation database feedback</p></td>
		    </tr>
			<tr><td class="emptyline" height="10" colspan="4">&nbsp;</td></tr>
			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="yellowlinklarge" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=addnew">
					add new</a></td>
		    </tr>
			<tr><td class="emptyline" height="10" colspan="4">&nbsp;</td></tr>
			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=readall&subrecordslink=yes&extrabutton=yes">
					read all</a></td>
		    </tr>		
			<tr> 
		      <td width="14">&nbsp;</td>
		      <td colspan="3"><p class="menutext">
				  search by subject</p></td>
		    </tr>
	
			<tr> 
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
			
			$query = "SELECT DISTINCT userfeedback.subject FROM fielddata.userfeedback ORDER BY userfeedback.subject;";
			$formname="listssubjects";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=bysubject&subrecordslink=yes&extrabutton=yes";
			$selectname="subject";

			include 'modulecreatevaluelist.php';		

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>


  </table>';
}

if ($menuaction=='feedback')
{
	include 'componentfeedback.php';
}
elseif ($menuaction=='feedbackreplies')
{
	include 'componentfeedbackreplies.php';
}
?>