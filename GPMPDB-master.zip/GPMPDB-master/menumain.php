<?php

if ($menuaction)
	{
		include 'menumainactions.php';
	}
	else
	{
	switch ($indexaction)
		{
		case "":

		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD height="90">&nbsp;</TD>
		</TR>
		<TR><TD align="center"><IMG SRC="images/site.jpg" WIDTH=800 HEIGHT=347 alt="gpmp excavations in 2001 (kevin kaiser)"></TD>
		</TR>
		<TR><TD height="89">&nbsp;</TD>
		</TR></TABLE>';
	
		break;
	
	
		case "browse":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">
		  
  <table width="164" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  browse database</p></td>
    </tr>';
	
	
	$fieldtablename[1] = 'bag register';
		$fieldtablelink[1] = 'bagregister';
	$fieldtablename[2] = 'broad and local areas';
		$fieldtablelink[2] = 'areas';
	$fieldtablename[3] = 'burial features';
		$fieldtablelink[3] = 'burialfeatures';
	$fieldtablename[4] = 'cd inventory';
		$fieldtablelink[4] = 'cdinventory';
	$fieldtablename[5] = 'drawing log';
		$fieldtablelink[5] = 'drawinglog';
	$fieldtablename[6] = 'entity log';
		$fieldtablelink[6] = 'entitylog';
	$fieldtablename[7] = 'exotic material register';
		$fieldtablelink[7] = 'exoticmaterialregister';
	$fieldtablename[8] = 'feature log';
		$fieldtablelink[8] = 'featurelog';
	$fieldtablename[9] = 'group log';
		$fieldtablelink[9] = 'grouplog';
	$fieldtablename[10] = 'list tables';
		$fieldtablelink[10] = 'listdata';
	$fieldtablename[11] = 'notebooks catalog';
		$fieldtablelink[11] = 'notebookscatalog';
	$fieldtablename[12] = 'photo log';
		$fieldtablelink[12] = 'photolog';
	$fieldtablename[13] = 'raw tables';
		$fieldtablelink[13] = 'rawtables';
	$fieldtablename[14] = 'reports catalog';
		$fieldtablelink[14] = 'reportscatalog';
	$fieldtablename[15] = 'sample register';
		$fieldtablelink[15] = 'sampleregister';
	$fieldtablename[16] = 'space log';
		$fieldtablelink[16] = 'spacelog';
	$fieldtablename[17] = 'structure log';
		$fieldtablelink[17] = 'structurelog';
	$fieldtablename[18] = 'synoptic feature form';
		$fieldtablelink[18] = 'synopticfeatureform';
	$fieldtablename[19] = 'binders';
		$fieldtablelink[19] = 'binders';
	for	($i=1; $i<=count($fieldtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=browse'.$fieldtablelink[$i].'">
			 '.$fieldtablename[$i].'</a></td>
		    </tr>';
	}
	
	echo'</TD>
		</TR>
		</TABLE>';

		break;
		

		case "query":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">
  <table width="164" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  query database</p></td>
    </tr>';


	$querygroupname[1] = 'by burial';
		$querygrouplink[1] = 'querybyburials';
	$querygroupname[2] = 'by feature';
		$querygrouplink[2] = 'querybyfeatures';
	$querygroupname[3] = 'compiled area records';
		$querygrouplink[3] = 'querydsrs';
	$querygroupname[4] = 'specialized queries';
		$querygrouplink[4] = 'queryindividualized';
	$querygroupname[5] = 'statistics';
		$querygrouplink[5] = 'querystatistics';
	
	for	($i=1; $i<=count($querygroupname); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$querygrouplink[$i].'">
			 '.$querygroupname[$i].'</a></td>
		    </tr>';
	}

	echo'</TD>
		</TR>
		</TABLE>';


		break;
		

		case "add":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="20%" height="100%" valign="top">';


if ($useraccesslevel>=2)
{
	echo'
  <table width="200" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  add excavation records</p></td>
    </tr>';
	
	$fieldtablename[1] = 'bag register';
		$fieldtablelink[1] = 'bagregister';
	$fieldtablename[2] = 'burial features';
		$fieldtablelink[2] = 'burialfeatures';
	$fieldtablename[3] = 'broad areas';
		$fieldtablelink[3] = 'broadareas';
	$fieldtablename[4] = 'cd inventory';
		$fieldtablelink[4] = 'cdinventory';
	$fieldtablename[5] = 'drawing log';
		$fieldtablelink[5] = 'drawinglog';
	$fieldtablename[6] = 'entity log';
		$fieldtablelink[6] = 'entitylog';
	$fieldtablename[7] = 'exotic material register';
		$fieldtablelink[7] = 'exoticmaterialregister';
	$fieldtablename[8] = 'feature log';
		$fieldtablelink[8] = 'featurelog';
	$fieldtablename[9] = 'group log';
		$fieldtablelink[9] = 'grouplog';
	$fieldtablename[10] = 'local areas';
		$fieldtablelink[10] = 'localareas';
	$fieldtablename[11] = 'notebooks catalog';
		$fieldtablelink[11] = 'notebookscatalog';
	$fieldtablename[12] = 'photo log';
		$fieldtablelink[12] = 'photolog';
	$fieldtablename[13] = 'reports catalog';
		$fieldtablelink[13] = 'reportscatalog';
	$fieldtablename[14] = 'sample register';
		$fieldtablelink[14] = 'sampleregister';
	$fieldtablename[15] = 'space log';
		$fieldtablelink[15] = 'spacelog';
	$fieldtablename[16] = 'structure log';
		$fieldtablelink[16] = 'structurelog';
	$fieldtablename[17] = 'synoptic feature form';
		$fieldtablelink[17] = 'synopticfeatureform';
	
	for	($i=1; $i<=count($fieldtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$fieldtablelink[$i].'&fastdataentry=yes">
			 '.$fieldtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($fieldtablelink);
	unset ($fieldtablename);
	
	echo'
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  add image collection records</p></td>
    </tr>';
	
	$fieldtablename[1] = 'image collection';
		$fieldtablelink[1] = 'imagecollection';
	
	for	($i=1; $i<=count($fieldtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$fieldtablelink[$i].'">
			 '.$fieldtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($fieldtablelink);
	unset ($fieldtablename);
	
    echo'
	</table></td>
	<TD width="20%" height="100%" valign="top">

  <table width="200" border="0" bgcolor="#333333">
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add spatial list data</p></td>
    </tr>';
	$listtablename[1] = 'areas';
		$listtablelink[1] = 'listareas';
	$listtablename[2] = 'data entry squares';
		$listtablelink[2] = 'listdataentrysquares';
	$listtablename[3] = 'int/ext';
		$listtablelink[3] = 'listint/ext';
	$listtablename[4] = 'squares';
		$listtablelink[4] = 'listsquares';
		
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
	      <td width="14">&nbsp;</td>
	      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
		 '.$listtablename[$i].'</a></td>
	    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add category/type list data</p></td>
    </tr>';
	$listtablename[1] = 'bag categories';
		$listtablelink[1] = 'listbagcategories';
	$listtablename[2] = 'burial types';
		$listtablelink[2] = 'listburialtypes';
	$listtablename[3] = 'drawing types';
		$listtablelink[3] = 'listdrawingtypes';
	$listtablename[4] = 'entity types';
		$listtablelink[4] = 'listentitytypes';
	$listtablename[5] = 'exotic material categories';
		$listtablelink[5] = 'listexoticmaterialcategories';
	$listtablename[6] = 'feature types';
		$listtablelink[6] = 'listfeaturetypes';
	$listtablename[7] = 'feature type groups';
		$listtablelink[7] = 'listfeaturetypegroups';
	$listtablename[8] = 'photo index';
		$listtablelink[8] = 'listphotoindex';
	$listtablename[9] = 'report types';
		$listtablelink[9] = 'listreporttypes';
	$listtablename[10] = 'sample types';
		$listtablelink[10] = 'listsampletypes';
	$listtablename[11] = 'specialist categories';
		$listtablelink[11] = 'listspecialistcategories';
	$listtablename[12] = 'storage mediums';
		$listtablelink[12] = 'liststoragemediums';

	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
	      <td width="14">&nbsp;</td>
	      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
		 '.$listtablename[$i].'</a></td>
	    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);
	

	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add temporal list data</p></td>
    </tr>';

	$listtablename[1] = 'bag seasons';
		$listtablelink[1] = 'listbagseasons';
	$listtablename[2] = 'drawing seasons';
		$listtablelink[2] = 'listdrawingseasons';
	$listtablename[3] = 'phases';
		$listtablelink[3] = 'listphases';
	$listtablename[4] = 'site seasons';
		$listtablelink[4] = 'listsiteseasons';

	
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
	      <td width="14">&nbsp;</td>
	      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
		 '.$listtablename[$i].'</a></td>
	    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add name list data</p></td>
    </tr>';

	$listtablename[1] = 'binders';
		$listtablelink[1] = 'listbinders';
	$listtablename[2] = 'directions';
		$listtablelink[2] = 'listdirections';
	$listtablename[3] = 'excavators';
		$listtablelink[3] = 'listexcavators';
	$listtablename[4] = 'locations';
		$listtablelink[4] = 'listlocations';
	$listtablename[5] = 'portfolios';
		$listtablelink[5] = 'listportfolios';
	$listtablename[6] = 'sources';
		$listtablelink[6] = 'listsources';
	
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
	      <td width="14">&nbsp;</td>
	      <td width="178"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
		 '.$listtablename[$i].'</a></td>
	    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);
	

	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add miscellaneous list data</p></td>
    </tr>';

	$listtablename[1] = 'scales';
		$listtablelink[1] = 'listscales';
	$listtablename[2] = 'weight prefix';
		$listtablelink[2] = 'listweightprefix';
	$listtablename[3] = 'yes / no';
		$listtablelink[3] = 'listyesno';	

	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
	      <td width="14">&nbsp;</td>
	      <td width="186"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
		 '.$listtablename[$i].'</a></td>
	    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


	
echo '
		</table></td>';
	
	
if ($useraccesslevel>=4)
{
    echo'
	<TD width="164" height="100%" valign="top">

  <table width="164" border="0" bgcolor="#333333">
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  add user data</p></td>
    </tr>';
	$numberoflisttables = 1;
	$listtablename[1] = 'users';
		$listtablelink[1] = 'authentication';
	
	for	($i=1; $i<=$numberoflisttables; $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=adddata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	echo '
		</table></td>';
}	

	
		echo'</TR>
		</TABLE>';

}

		break;


		case "editdelete":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="15%" height="100%" valign="top">';
		  
if ($useraccesslevel>=2)
{
	echo'
  <table width="160" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  direct edit</p></td>
    </tr>
	<tr> 
	  <td width="14">&nbsp;</td>
	  <td width="136"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=directeditgeneralrecords">
	  general records</a></td>
	</tr>
  </table></td>
  <TD width="20%" height="100%" valign="top">

  <table width="230" border="0" bgcolor="#333333">
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  edit/delete excavation records</p></td>
    </tr>';
	
	$fieldtablename[1] = 'bag register';
		$fieldtablelink[1] = 'bagregister';
	$fieldtablename[2] = 'burial features';
		$fieldtablelink[2] = 'burialfeatures';
	$fieldtablename[3] = 'broad areas';
		$fieldtablelink[3] = 'broadareas';
	$fieldtablename[4] = 'cd inventory';
		$fieldtablelink[4] = 'cdinventory';
	$fieldtablename[5] = 'drawing log';
		$fieldtablelink[5] = 'drawinglog';
	$fieldtablename[6] = 'entity log';
		$fieldtablelink[6] = 'entitylog';
	$fieldtablename[7] = 'exotic material register';
		$fieldtablelink[7] = 'exoticmaterialregister';
	$fieldtablename[8] = 'feature log';
		$fieldtablelink[8] = 'featurelog';
	$fieldtablename[9] = 'group log';
		$fieldtablelink[9] = 'grouplog';
	$fieldtablename[10] = 'local areas';
		$fieldtablelink[10] = 'localareas';
	$fieldtablename[11] = 'notebooks catalog';
		$fieldtablelink[11] = 'notebookscatalog';
	$fieldtablename[12] = 'photo log';
		$fieldtablelink[12] = 'photolog';
	$fieldtablename[13] = 'reports catalog';
		$fieldtablelink[13] = 'reportscatalog';
	$fieldtablename[14] = 'sample register';
		$fieldtablelink[14] = 'sampleregister';
	$fieldtablename[15] = 'space log';
		$fieldtablelink[15] = 'spacelog';
	$fieldtablename[16] = 'structure log';
		$fieldtablelink[16] = 'structurelog';
	$fieldtablename[17] = 'synoptic feature form';
		$fieldtablelink[17] = 'synopticfeatureform';
	
	for	($i=1; $i<=count($fieldtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$fieldtablelink[$i].'&fastdataentry=yes">
			 '.$fieldtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($fieldtablelink);
	unset ($fieldtablename);
	
	echo'
    <tr valign="bottom"> 
      <td colspan="2" height="26"><p class="menuheading">
	  edit/delete image collection records</p></td>
    </tr>';
	
	$fieldtablename[1] = 'image collection';
		$fieldtablelink[1] = 'imagecollection';
	
	for	($i=1; $i<=count($fieldtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$fieldtablelink[$i].'">
			 '.$fieldtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($fieldtablelink);
	unset ($fieldtablename);

	
    echo'
	</table></td>
	<TD width="20%" height="100%" valign="top">

  <table width="230" border="0" bgcolor="#333333">
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit/delete spatial list data</p></td>
    </tr>';
	$listtablename[1] = 'areas';
		$listtablelink[1] = 'listareas';
	$listtablename[2] = 'data entry squares';
		$listtablelink[2] = 'listdataentrysquares';
	$listtablename[3] = 'int/ext';
		$listtablelink[3] = 'listint/ext';
	$listtablename[4] = 'squares';
		$listtablelink[4] = 'listsquares';
		
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit/delete category/type list data</p></td>
    </tr>';
	$listtablename[1] = 'bag categories';
		$listtablelink[1] = 'listbagcategories';
	$listtablename[2] = 'burial types';
		$listtablelink[2] = 'listburialtypes';
	$listtablename[3] = 'drawing types';
		$listtablelink[3] = 'listdrawingtypes';
	$listtablename[4] = 'entity types';
		$listtablelink[4] = 'listentitytypes';
	$listtablename[5] = 'exotic material categories';
		$listtablelink[5] = 'listexoticmaterialcategories';
	$listtablename[6] = 'feature types';
		$listtablelink[6] = 'listfeaturetypes';
	$listtablename[7] = 'feature type groups';
		$listtablelink[7] = 'listfeaturetypegroups';
	$listtablename[8] = 'photo index';
		$listtablelink[8] = 'listphotoindex';
	$listtablename[9] = 'report types';
		$listtablelink[9] = 'listreporttypes';
	$listtablename[10] = 'sample types';
		$listtablelink[10] = 'listsampletypes';
	$listtablename[11] = 'specialist categories';
		$listtablelink[11] = 'listspecialistcategories';
	$listtablename[12] = 'storage mediums';
		$listtablelink[12] = 'liststoragemediums';

	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);
	

	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit/delete temporal list data</p></td>
    </tr>';

	$listtablename[1] = 'bag seasons';
		$listtablelink[1] = 'listbagseasons';
	$listtablename[2] = 'drawing seasons';
		$listtablelink[2] = 'listdrawingseasons';
	$listtablename[3] = 'phases';
		$listtablelink[3] = 'listphases';
	$listtablename[4] = 'site seasons';
		$listtablelink[4] = 'listsiteseasons';

	
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit/delete name list data</p></td>
    </tr>';

	$listtablename[1] = 'binders';
		$listtablelink[1] = 'listbinders';
	$listtablename[2] = 'directions';
		$listtablelink[2] = 'listdirections';
	$listtablename[3] = 'excavators';
		$listtablelink[3] = 'listexcavators';
	$listtablename[4] = 'locations';
		$listtablelink[4] = 'listlocations';
	$listtablename[5] = 'portfolios';
		$listtablelink[5] = 'listportfolios';
	$listtablename[6] = 'sources';
		$listtablelink[6] = 'listsources';
	
	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);
	

	echo '
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit/delete miscellaneous list data</p></td>
    </tr>';

	$listtablename[1] = 'scales';
		$listtablelink[1] = 'listscales';
	$listtablename[2] = 'weight prefix';
		$listtablelink[2] = 'listweightprefix';
	$listtablename[3] = 'yes / no';
		$listtablelink[3] = 'listyesno';	

	for	($i=1; $i<=count($listtablename); $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="216"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}
	unset ($listtablename);
	unset ($listtablelink);


echo '
		</table></td>';

		
if ($useraccesslevel>=4)
{
    echo'
	<TD width="164" height="100%" valign="top">

  <table width="164" border="0" bgcolor="#333333">
	<tr valign="bottom"> 
      <td colspan="2" height="36"><p class="menuheading">
	  edit / delete user data</p></td>
    </tr>';
	$numberoflisttables = 1;
	$listtablename[1] = 'users';
		$listtablelink[1] = 'authentication';

	
	for	($i=1; $i<=$numberoflisttables; $i++)
	{
		echo'<tr> 
		      <td width="14">&nbsp;</td>
		      <td width="140"><a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction=editdeletedata&submenuaction='.$listtablelink[$i].'">
			 '.$listtablename[$i].'</a></td>
		    </tr>';
	}	
	echo '
		</table></td>';
}	

	
		echo'</TR>
		</TABLE>';
}

		break;		
		
		
				
		case "introduction":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left">
		<TR><TD width="100%" height="100%" valign="top">';
		  
		  include 'introduction.php';

		echo'</td></TR></table>';
		
		break;

		
		
		case "help":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left">
		<TR><TD width="100%" height="100%" valign="top">';

		  include 'help.php';

		echo'</td></TR></table>';
				  		
		break;

		
		case "rawtablesmetadata":
		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=5 CELLSPACING=0 align="left">
		<TR><TD width="100%" height="100%" valign="top">';

		  include 'rawtablesmetadata.php';

		echo'</td></TR></table>';
		
		break;

		}
	}
?>