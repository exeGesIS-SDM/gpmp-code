<?php

switch ($menuaction)
	{
		case "browsefeaturelog":
			include 'menubrowsefeaturelog.php';
		break;
		
		case "browsegrouplog":
			include 'menubrowsegrouplog.php';
		break;
		
		case "browsespacelog":
			include 'menubrowsespacelog.php';
		break;
		
		case "browsestructurelog":
			include 'menubrowsestructurelog.php';
		break;
		
		case "browseareas":
			include 'menubrowseareas.php';
		break;
				
		case "browsebagregister":
			include 'menubrowsebagregister.php';
		break;

		case "browseburialfeatures":
			include 'menubrowseburialfeatures.php';
		break;

		case "browsecdinventory":
			include 'menubrowsecdinventory.php';
		break;		
		
		case "browsesampleregister":
			include 'menubrowsesampleregister.php';
		break;			

		case "browseexoticmaterialregister":
			include 'menubrowseexoticmaterialregister.php';
		break;			

		case "browsedrawinglog":
			include 'menubrowsedrawinglog.php';
		break;			

		case "browsesynopticfeatureform":
			include 'menubrowsesynopticfeatureform.php';
		break;			

		case "browseentitylog":
			include 'menubrowseentitylog.php';
		break;

		case "browselistdata":
			include 'menubrowselistdata.php';
		break;		

		case "browserawtables":
			include 'menubrowserawtables.php';
		break;	

		case "browsereportscatalog":
			include 'menubrowsereportscatalog.php';
		break;	
		
		case "browsenotebookscatalog":
			include 'menubrowsenotebookscatalog.php';
		break;

		case "browsephotolog":
			include 'menubrowsephotolog.php';
		break;
		
		case "querybyburials":
			include 'menuquerybyburials.php';
		break;

		case "querybyfeatures":
			include 'menuquerybyfeatures.php';
		break;
		
		case "querystatistics":
			include 'menuquerystatistics.php';
		break;
		
		case "querydsrs":
			include 'menuquerydsrs.php';
		break;

		case "queryindividualized":
			include 'menuqueryindividualized.php';
		break;

		case "feedback":
			include 'menufeedback.php';
		break;

		case "feedbackreplies":
			include 'menufeedback.php';
		break;

	case "browsebinders":
	  include 'menubrowsebinders.php';
	  break;
	}

  
if ($useraccesslevel>=2)
{
	switch ($menuaction)
		{
			case "adddata":
				include 'componentadddata.php';
			break;
		
			case "editdeletedata":
				include 'componenteditdata.php';
			break;

			case "directeditgeneralrecords":
				include 'menudirecteditdata.php';
			break;
		}
}

?>