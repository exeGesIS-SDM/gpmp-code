<?php

		echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">
		  
	  <table width="164" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  field records by burial</p></td>
		    </tr>

			<tr> 
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					choose burial</p></td>
			</tr>
			
			<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=chosenburial" method="POST">
				<tr> 
			    	<td width="10">&nbsp;</td>
			    	<td width="9">&nbsp; </td>
			    	<td width="64"> 
			        	<input class="text" type="text" name="chosenburial" size="4" maxlength="5">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			    <tr>
					<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp; </td>
				</tr>
			</form>	
 	 </table>';
	include 'componentquerybyburials.php';
	
?>