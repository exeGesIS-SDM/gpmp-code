<?php

	  
if (!$submenuaction)
{
	echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	if ($chooselog=='yes')
	{
		# count number of selected items
		if ($squarename[0]!='')
		{
			$countsquares = count($squarename);
		}
		elseif (!$countsquares) // this is because of return to log selection button
		{
			$countsquares = 0;
		}
		if ($supervisor[0]!='')
		{
			$countsupervisors = count($supervisor);
		}
		elseif (!$countsupervisors) // this is because of return to log selection button
		{		
			$countsupervisors = 0;
		}
		
		if ($countsquares>0 and $squarename[0]!='')
		{
			$listsquares = implode("<br>or ", $squarename);
		}

		if ($countsupervisors>0 and $supervisor[0]!='')
		{
			$listsupervisors = implode("<br>or ", $supervisor);
		}

		/////// check logs for information

		$dsrdatacheck="yes";

		$logname[1] = "featurelog";
		$logname[2] = "bagregister";
		$logname[3] = "synopticfeatureform";
		$logname[4] = "drawinglog";
		$logname[5] = "exoticmaterialregister";
		$logname[6] = "photolog";
		$logname[7] = "notebookscatalog";
		$logname[8] = "sampleregister";
		$logname[9] = "reportscatalog";
		
		$filedownload[1]="no";
		$filedownload[4]="no";
		$filedownload[7]="no";
		$filedownload[9]="no";

		$includeimage[6]="yes";
		
		for ($z = 1; $z <= count($logname); $z++)
		{
			unset ($sortsql); // this is because of return to log selection button

			include 'modulecreatesqlforarea.php';
			$submenuaction="dsr".$logname[$z];
			include "componentbrowse".$logname[$z].".php";

			@$statlog = pg_exec($dbh, $query);
			@$line = pg_fetch_row($statlog, 0);
			if ($line!='')
			{
				$logexists[$z]="yes";
			}
			else
			{
				$logexists[$z]="no";			
			}
			unset($sortsql);
		}

		$uservariables = "area=$area&listsquares=$listsquares&listsupervisors=$listsupervisors&countsquares=$countsquares&countsupervisors=$countsupervisors";
		
		echo'
		  <table width="250" border="0" bgcolor="#333333">
			    <tr valign="bottom">
   		   			<td colspan="3" class="menuheading" height="26"><p class="menuheading">
					  compiled area records</p></td>
				</tr>
				<tr>
					<td colspan="3" class="emptyline" height="10">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="largetextyellow" valign="top">your area definition is:</td>
				</tr>
				<tr>
					<td colspan="3" class="emptyline" height="5">&nbsp;</td>
				</tr>
				<tr>
					<td width="30%" class="largetextbold" valign="top">area</td>
					<td width="35%" class="largetextbold" valign="top">square(s)</td>
					<td width="35%" class="largetextbold" valign="top">supervisor(s)</td>
				</tr>
				<tr>
					<td width="30%" class="largetext" valign="top">'.$area.'</td>
					<td width="35%" class="largetext" valign="top">'.$listsquares.'</td>
					<td width="35%" class="largetext" valign="top">'.$listsupervisors.'</td>
				</tr>
			</table>
		  <table width="250" border="0" bgcolor="#333333">
				<tr>
					<td colspan="3" class="emptyline" height="20">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3" class="largetextyellow">these logs contain data:</td>
				</tr>
				<tr>
					<td colspan="3" class="emptyline" height="10">&nbsp;</td>
				</tr>';

			for ($i = 1; $i <= count($logname); $i++)
			{
				if ($logexists[$i]=='yes')
				{
					echo'
					<tr>
						<td width="10%">&nbsp;</td>
						<form action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=dsr'.$logname[$i].'&'.$uservariables.'&includeimage='.$includeimage[$i].'&filedownload='.$filedownload[$i].'" method="POST">
							<td colspan="2">
								<input class="dsrbutton" type="submit" name="submit" value="'.$logname[$i].'">
							</td>
						</form>
					</tr>';
				}
			}
		echo'</table>';
	}
	else
	{
		echo'
		  <table width="164" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  compiled area records -<br>define an area</p></td>
		    </tr>
	
			<tr> 
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					select area</p></td>
			</tr>
			
			<tr> 
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "SELECT DISTINCT listareas.area FROM fielddata.listareas WHERE listareas.valid=true ORDER BY listareas.area;";
			
			$formname="listdsr";
			$formaction="$_PHP_SELF";
			$selectname="area";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>

			<tr> 
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					select square(s)</p></td>
			</tr>
			<tr> 
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "SELECT DISTINCT listsquares.squarename FROM fielddata.listsquares WHERE listsquares.valid=true ORDER BY listsquares.squarename;";
			
			$selectname="squarename[]";
			$multipleselect="yes";

			$selectnoform="yes";
	
			
			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>

			<tr> 
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					select supervisor(s)</p></td>
			</tr>
			<tr> 
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "SELECT DISTINCT listexcavators.initials FROM fielddata.listexcavators WHERE listexcavators.valid=true ORDER BY listexcavators.initials;";
			
			$selectname="supervisor[]";
			$multipleselect="yes";

			$selectnoform="yes";
	
			
			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>

			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input type="hidden" name="chooselog" value="yes">
						<input class="submitbutton" type="submit" name="submit" value="continue">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
		</table>';
	}
}
else
{
	include 'modulecreatesqlforarea.php';
	include 'componentquerydsrs.php';
}
?>