<?php


if (!$submenuaction)
{
echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';


	echo'		  
  <table width="200" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  specialized queries</p></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>

			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=bagregisterandseasons">
					bagregister with site seasons</a></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>

			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=cdcontents">
					CD contents</a></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>

			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=portfoliocontents">
					portfolio contents</a></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>

			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=duplicatedrawings">
					duplicate drawings</a></td>
		    </tr>
			
			
			<tr><td class="emptyline" height="5">&nbsp;</td></tr>
			
			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=areafeaturedrawing">
					features by area and their drawings</a></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>

			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=squarefeaturedrawing">
					features by square and their drawings</a></td>
		    </tr>

			<tr><td class="emptyline" height="5">&nbsp;</td></tr>
			
						
			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					featurelog & synoptic feature form by area and supervisor</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "select distinct featurelogareas.area || ' - ' || listexcavators.fullnames as areaandsupervisor
					from (fielddata.featurelog left join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber) left join (fielddata.featurelogsupervisors left join fielddata.listexcavators on featurelogsupervisors.supervisor = listexcavators.initials) on featurelog.featurenumber = featurelogsupervisors.featurenumber
					where (((featurelogareas.area) is not null) and ((listexcavators.fullnames) is not null));";
			
			$formname="listareasandsupervisors";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=featurelogandsynopticsbyareaandsupervisor";
			$selectname="areaandsupervisor";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
			

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					featurelog & synoptic feature form by square</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "SELECT DISTINCT squarename FROM fielddata.featurelogsquares ORDER BY squarename;";
			
			$formname="listsquarename";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=featurelogandsynopticsbysquare";
			$selectname="squarename";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					bagregister by area and season</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "select distinct featurelogareas.area || ' - ' || bagregister.bagprefix as areabagprefix
				from (fielddata.featurelog right join fielddata.bagregister on featurelog.featurenumber = bagregister.featurenumber) left join fielddata.featurelogareas on featurelog.featurenumber = featurelogareas.featurenumber
				where featurelogareas.valid=true and bagregister.valid=true and featurelog.valid=true and (((bagregister.bagprefix) is not null) and ((featurelogareas.area) is not null))
				order by (featurelogareas.area || ' - ' || bagregister.bagprefix);";
			
			$formname="listareabagprefix";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=bagregisterbyareaandseason";
			$selectname="areabagprefix";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>

			<tr>
				<td width="14">&nbsp;</td>
				<td colspan="3"><p class="menutext">
					bagregister by bagprefix with featurelog squares</p></td>
			</tr>
			<tr>
				<td width="14">&nbsp;</td>
				<td width="5">&nbsp; </td>
				<td colspan="2">';
    
			$query = "select distinct bagregister.bagprefix
				from fielddata.bagregister
				where bagregister.valid=true and bagregister.bagprefix is not null
				order by bagregister.bagprefix;";
			
			$formname="listbagprefix";
			$formaction="".$sitebasefile."?indexaction=$indexaction&menuaction=$menuaction&submenuaction=bagregisterbybagprefixwithfeaturelogsquares";
			$selectname="bagprefix";

			include 'modulecreatevaluelist.php';

		echo '	</td>
			 </tr>
			    <tr>
			 		<td width="10">&nbsp;</td>
					<td width="9">&nbsp; </td>
					<td width="64">
						<input class="submitbutton" type="submit" name="submit" value="search">
					</td>
				    <td width="65">&nbsp;
					</td>
				</tr>
			</form>
			
	</table>';
}

	include 'componentqueryindividualized.php';
	
?>