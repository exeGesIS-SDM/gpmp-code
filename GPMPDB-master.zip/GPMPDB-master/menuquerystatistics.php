<?php

	  
if (!$submenuaction)
{
echo'
		<TABLE width=100% height=100% BORDER=0 CELLPADDING=0 CELLSPACING=0 align="left" bgcolor="#1A1F2D">
		<TR><TD width="100%" height="100%" valign="top">';

	echo'
		<table width="164" border="0" bgcolor="#333333">
		    <tr valign="bottom"> 
      			<td colspan="5" height="26"><p class="menuheading">
				  statistics of database</p></td>
		    </tr>
	
			<tr> 
     			<td width="14">&nbsp;</td>
     			<td colspan="3"> 
       			<a class="menulink" href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction=featurespersupervisor"><font color="#FFFFFF">
					features per supervisor</a></td>
		    </tr>
		
	</table>';
}

	include 'componentquerystatistics.php';
	
?>