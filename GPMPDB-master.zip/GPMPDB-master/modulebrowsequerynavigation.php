<?php

if ($menuaction=='querydsrs')
{
	echo'<table width="100%" border="0">
 	<tr> 
  	  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
	</tr>
 	<tr> 
	    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">navigation:</td>
	    <td valign="top" width="15%" colspan="6" bgcolor="#212838">
			<form name="returntodefinition" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'" method="POST">
				<input type="submit" class="submitbutton" name="return" value="return to area definition">
			</form>	
		</td>

	    <td valign="top" colspan="6" bgcolor="#212838">
				<form name="returntologselection" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&'.$uservariables.'&chooselog=yes" method="POST">
					<input type="submit" class="submitbutton" name="return" value="return to log selection">
				</form>
		</td>
	</tr>
	</table>';
}

if ($indexaction=='browse' or $menuaction=='queryindividualized')
{
	echo'<table width="100%" border="0">
 	<tr> 
  	  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
	</tr>
	<form name="returntodefinition" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'" method="POST">
 	<tr> 
	    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">navigation:</td>
	    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="return" value="return to '.$menuaction.'"></td>
	</tr>
	</form>
	</table>';
}


if ($menuaction=='editdeletedata')
{
	if ($returnto=='')
	{
		echo'<table width="100%" border="0">
 		<tr> 
  		  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
		</tr>
		<form name="viewrecententries" action="'.$sitebasefile.'?viewrecententries=yes&indexaction=edit&menuaction=editdeletedata&submenuaction='.$submenuaction.'&returnto=editdeletedata" method="POST">
 		<tr> 
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">navigation:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="viewrecent" value="view entries / changes of last 12h"></td>
		</tr>
		</form>
		</table>';
	}
}


if ($viewrecententries=='yes')
{
	# add return button from view recent entries
	if ($returnto=='editdeletedata')
	{
		$menuactionvalue='editdeletedata';
		$buttonvalue='return to edit/delete records';
	}
	else
	{
		$menuactionvalue='adddata';
		$buttonvalue='return to add records';
	}

	echo'<table width="100%" border="0">
 		<tr> 
  		  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
		</tr>
		<form name="returntoprevious" action="'.$sitebasefile.'?indexaction=add&menuaction='.$menuactionvalue.'&submenuaction='.$submenuaction.'&fastdataentry='.$fastdataentry.'" method="POST">
		<tr> 
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">navigation:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="return" value="'.$buttonvalue.'"></td>
		</tr>
		</form>
		</table>';
}

if ($filedownload=='yes' and $filedownloadheader!='')
{
	echo'<table width="100%" border="0">
 	<tr> 
	  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
	</tr>
	<form name="switchfiledownload" action="'.$PHP_SELF.'?'.$_SERVER['QUERY_STRING'].'&filedownload=no" method="POST">
		<tr> 
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">file download:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="disablefiledownload" value="hide linked files"></td>
		</tr>
		</form>
	</table>';
}
elseif ($filedownload=='no' and $filedownloadheader!='')
{
	echo'<table width="100%" border="0">
 	<tr> 
	  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
	</tr>
	<form name="switchfiledownload" action="'.$PHP_SELF.'?'.$_SERVER['QUERY_STRING'].'&'.$uservariables.'&'.$specialcolumnvariables.'&filedownload=yes" method="POST">
		<tr> 
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">file download:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="enablefiledownload" value="show linked files"></td>
		</tr>
	</form>
	</table>';
}
?>