<?php

	// definition of special column variables
	$specialcolumnvariables = "includeimage=$includeimage&filedownload=$filedownload&subrecordslink=$subrecordslink&extrabutton=$extrabutton";


	if ($fullscreen=="yes")
	{
		include_once 'authentication.php';

		$queryspecialchars = htmlentities($query, ENT_QUOTES);
		echo"<body bgcolor='#000000'>";
	}
	else
	{
		$queryspecialchars = htmlentities($query, ENT_QUOTES);

	}

//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			// @ supresses error messages from database!

			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$columns = pg_numfields($stat);


if ($rows>0)
{
echo'<table width="100%" border="0">
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="5" height="30"> '.$title.'</td>
  </tr>
  <tr>
    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333"> '.$heading1.'</td>
    <td class="largetext" valign="top" width="42%" align="left" bgcolor="#212838">
      '.$text1.'</td>
    <td class="largetextbold" valign="top" align="center" rowspan="2" bgcolor="#333333" width="7%">export:</td>
	<td class="largetext" valign="top" align="center" rowspan="2" bgcolor="#212838" width="18%">';
   		$fullscreenlink = "component$menuaction.php";
		printf ("<form name='saveastxt' method='post' action=\"%s\">
				<input class='submitbutton' type='submit' name='submit' value='save as txt'></form></td>",'modulesavequeryastxt.php?saveastxt=yes');
echo'
    <td class="largetext" valign="top" align="center" rowspan="2" bgcolor="#212838" width="18%">';
		printf ("<form name='saveaspdf' method='post' action=\"%s\">
		<input class='submitbutton' type='submit' name='submit' value='save as pdf'></form></td>",'modulesavequeryasfpdf.php?saveaspdf=yes');
echo'
  </tr>
  <tr>
    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333"> '.$heading2.'</td>
    <td class="largetext" valign="top" width="42%" align="left" bgcolor="#212838">
      '.$text2.'';

# add freetext search variables if existing
if ($searchsql!='')
{
	echo "<br><b>freetext filter:</b> column '$searchcolumn' contains '$searchkeywords'";
}

echo'</td>
  </tr>
  <tr>
    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">result rows:</td>
    <td class="largetext" valign="top" width="42%" align="left" bgcolor="#212838">
      '.$rows.'</td>
    <td class="largetext" valign="top" align="center" bgcolor="#212838" colspan="3">';

	if ($fullscreen=='no' or !$fullscreen)
	{
		$fullscreenlink = "component$menuaction.php";

		printf ("<a class='whitelink' href=\"%s?fullscreen=%s&indexaction=%s&menuaction=%s&submenuaction=%s&%s&%s\" target=\"_blank\">
			printable html version</a></td>",$fullscreenlink, 'yes', $indexaction, $menuaction, $submenuaction, $uservariables, $specialcolumnvariables);
	}
	else
	{
		echo'&nbsp;</td>';
	}
echo'
  </tr>
</table>';


include 'modulesortandsearch.php';

include 'modulebrowsequerynavigation.php';

}



//	CHECK IF QUERY IS CORRECT

			if	(!$stat)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br> Check your query!
				</td></tr></table>";
				die;
			}

//	CHECK IF RECORD EXISTS
			if	($rows==0)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				$norecordtext
				</td></tr></table>";
				die;
			}

if ($rows<=50)
{
	echo'
	<table>
	<tr><td class="emptyline" height="20">&nbsp;</td></tr>
	</table>';
}

include 'modulecreatedbtable.php';


if ($fullscreen=="yes")
	{
	echo'
		</body>
		</html>';
	}

if ($rows>0)
{
		////// register query in session for possible pdf output
		$_SESSION['sessionsite']=$site;
		$_SESSION['sessionquery']=$query;
		$_SESSION['sessionsavename']=$savename;
		$_SESSION['sessionquery']=$query;
		$_SESSION['sessiontitle']=$title;
		$_SESSION['sessionoutputcolumn']=$outputcolumn;
		$_SESSION['sessionoutputcolumns']=$outputcolumns;

		if ($keynumberofcolumns)
		{
			$_SESSION['sessionkeynumberofcolumns']=$keynumberofcolumns;
			$_SESSION['sessionkeycolumn']=$keycolumn;
			$_SESSION['sessionkeytargetfield']=$keytargetfield;
			$_SESSION['sessionkeyquery']=$keyquery;
			$_SESSION['sessionkeysort']=$keysort;
		}
}


?>