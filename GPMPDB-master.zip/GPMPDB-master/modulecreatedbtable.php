<?php

# deal with page numbering

if ($fullscreen=="yes")
	{
	$limit = 50;
	}
	else
	{
	$limit = 25;
	}

$per_page = $limit;
if (!$page)
	{
	$page = 1;
	}
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($per_page * $page) - $per_page;

if ($rows <= $per_page)
	{
	$num_pages = 1;
	}
	elseif(($rows % $per_page) == 0)
	{
	$num_pages = ($rows / $per_page);
	}
	else
	{
	$num_pages = ($rows / $per_page);
	}
$num_pages = ceil($num_pages);
if (($page > $num_pages) || ($page < 0))
	{
	echo "You have specified an invalid page number";
	die;
	}
$offset = (($page * $per_page) - $per_page);

$limit = ($page * $per_page);

if ($limit > $rows)
	{
	$limit = $rows;
	}


# generate adapted page markers

	$counter = 0;

	for	($i = 0; $i < $rows; $i= $i + $per_page)
	{
		$counter++;
		$pageidentifierdata[$counter] = pg_fetch_array($stat, $i);
	}


# identify column name of first order sorting

	for	($i =0; $i < $columns; $i++)
	{
		if (pg_fieldname($stat, $i)==$pageidentifiername)
		{
			$pageidentifiercolumn=$i;
		}
	}


include 'modulecreatedbtablepages.php';


//	CREATE TABLE HEADINGS FOR DATA ARRAY

			for	($i =0; $i < $columns; $i++)
			{
				// saves headings for pdf output
				$headingtext[$i]=pg_fieldname($stat, $i);
			}
			if ($keynumberofcolumns)
			{
				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyquery2 = "$keyquery[$k];";
					$keystat = pg_exec($dbh, $keyquery2);
					$keycolumns = pg_numfields($keystat);

					for	($l =0; $l < $keycolumns; $l++)
					{
						$headingtext[$l+$k+$columns-1] = pg_fieldname($keystat, $l);
					}
				}
			}




//  CREATE QUERY RESULT FOR DATA ARRAY

			for	($i = $offset; $i < $limit; $i++)
			{
				$data = pg_fetch_array($stat, $i);

				for	($j = 0; $j < $columns; $j++)
				{
					# check if data is a feature and then create hyperlink to query "by feature" page in new window
					if ($headingtext[$j]=="feature")
					{
						$resulttext[$i][$j]= "<a class=\"yellowlink\" target=\"_new\" href=".$PHP_SELF."?indexaction=query&menuaction=querybyfeatures&submenuaction=chosenfeature&chosenfeature=".$data[$j].">".$data[$j]."</a>";
						$resulttextraw[$i][$j]= $data[$j];
					}
					else
					{
						$resulttext[$i][$j]=$data[$j];
						$resulttextraw[$i][$j]= $data[$j];
					}
				}


				if ($keynumberofcolumns)
				{
					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($data[$keycolumn[$k]], ENT_QUOTES);

						if (!$keytargetfield[$k])
						{
							$keyfieldname = pg_fieldname($stat, $keycolumn[$k]);
						}
						else
						{
							$keyfieldname = $keytargetfield[$k];
						}

						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";

						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$keyrows = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// create subquery output
						for	($l = 0; $l < $keyrows; $l++)
						{
							$keydata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								if ($headingtext[$k-1+$columns]=="feature" OR $headingtext[$k-1+$columns]=="feature(s)")
								{
									$resulttext[$i][$k-1+$columns] .= "<a class=\"yellowlink\" target=\"_new\" href=".$PHP_SELF."?indexaction=query&menuaction=querybyfeatures&submenuaction=chosenfeature&chosenfeature=".$keydata[$m].">".$keydata[$m]."</a>";
								}
								elseif ($headingtext[$k-1+$columns]=="related images")
								{
									$resulttext[$i][$k-1+$columns] .= "<a class=\"yellowlink\" target=\"_new\" href=".$PHP_SELF."?indexaction=browse&menuaction=browsephotolog&submenuaction=browsesinglephoto&includeimage=yes&imagenumber=".$keydata[$m].">".$keydata[$m]."</a>";
								}
								else
								{
									$resulttext[$i][$k-1+$columns] .= $keydata[$m];
								}
							}
							if ($keyrows>1 and $l < ($keyrows-1))
							{
								$resulttext[$i][$k-1+$columns] .= ", ";
							}
							else
							{
							}
						}
					}
				}
			}


//	CREATE TABLE HEADINGS

			echo '<table border="0"><tr>';
			if ($includeimage=='yes')
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>image</th>";
			}
			if ($filedownload=='yes' and $filedownloadheader!='')
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>".$filedownloadheader."</th>";
			}
			if ($extrabutton=='yes')
			{
				if ($useraccesslevel>=3)
				{
					echo "<th class='columnheading' bgcolor='#333333' height='25'>".$extrabuttonheader."</th>";
				}
			}
			if ($subrecordslink=='yes')
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>".$subrecordslinkheader."</th>";
			}
			for	($i =0; $i < $outputcolumns; $i++)
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>".$headingtext[$outputcolumn[$i]]."</th>";
			}
			echo '</tr>';


//	CREATE CONTENT OUTPUT

			for	($i = $offset; $i < $limit; $i++)
			{
				if ($i%2)
				{
					echo "<tr bgcolor='#212838'>";
				}
				else
				{
					echo "<tr bgcolor='#1A1F2D'>";
				}

				if ($includeimage=='yes')
				{
					echo "<td align='center'><a href='moduleviewdigitals.php?imagenumber=".$resulttext[$i][$imagenumbercolumn]."' target='_blank'><img src='http://gpmpfiles.esdm.co.uk/thumbs/".$resulttext[$i][$imagenumbercolumn].".jpg' border='0'></a></td>";
				}

				if ($filedownload=='yes' and $filedownloadheader!='')
				{
					if((! isset($filedownloadextensions)) and isset($filedownloadextension)){
						$filedownloadextensions = array($filedownloadextension);
					}
					$outputed = false;
					foreach($filedownloadextensions as $ext){
						$url = $filedownloadlink."/".$filedownloadprefix.$resulttextraw[$i][$filedownloadcolumn].".".$ext;
						$ret = remote_file_exists($url);
						// echo $url;

						if ($ret===false){
							continue;
						}elseif ($ret===true){
							echo '<td valign="top" align="center"><a class="yellowlink" href="'.$url.'" target="_blank">download</a></td>';
						}else{
							echo '<td class="columntext">error code: '.$ret.'</td>';
						}
						$outputed = true;
						break;
					}
					if ($outputed === false){
						echo "<td>&nbsp;</td>";
					}
				}
				if ($extrabutton=='yes')
				{
					if ($useraccesslevel>=3)
					{
						echo'<form name="deletelines" action="'.$extrabuttonurl.'" method="POST">';
						echo '<td valign="top" width="10"><input type="submit" class="submitbutton" value="'.$extrabuttonname.'">
						<input type="hidden" name="'.$extrabuttonvariablename.'" value="'.$resulttext[$i][$extrabuttoncolumn].'"></td>';
						echo '</form>';
					}
				}
				if ($subrecordslink=='yes')
				{
					if (recordexists($dbh, $subrecordslinktable, $subrecordslinkcolumnname, $resulttext[$i][$subrecordslinkcolumnnumber])==true)
					{
						echo "<td valign='top' align='center'><a class='yellowlink' href='".$subrecordslinkurl."&subrecordid=".$resulttext[$i][$subrecordslinkcolumnnumber]."'>$subrecordslinktext</a></td>";
					}
					else
					{
						echo "<td>&nbsp;</td>";
					}
				}
				for	($j = 0; $j < $outputcolumns; $j++)
				{
					if ($resulttext[$i][$outputcolumn[$j]]=='')
					{
						echo "<td>&nbsp;</td>";
					}
					else
					{
						echo "<td class='columntext' valign='top'>".$resulttext[$i][$outputcolumn[$j]]."</td>";
					}
				}

				echo "</tr>";
			}

//	CLOSE PGSQL DATABASE

			pg_close($dbh);


// include 'modulecreatedbtablepages.php';


?>