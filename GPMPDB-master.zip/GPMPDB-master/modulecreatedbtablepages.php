<?php

echo ' 	<script language="JavaScript">
			function openPage(url, viewrecententries, fullscreen, indexaction, menuaction, submenuaction, uservariables, page, specialcolumnvariables, includeimage, fastdataentry)
			{
				location.href = url + \'?viewrecententries=\' + viewrecententries + \'&fullscreen=\' + fullscreen + \'&indexaction=\' + indexaction + \'&menuaction=\' + menuaction + \'&submenuaction=\' + submenuaction + \'&\' + uservariables + \'&page=\' + page + \'&\' + specialcolumnvariables + \'&includeimage=\' + includeimage + \'&fastdataentry=\' + fastdataentry;
			}
		</script>';

//echo ' 	<script language="JavaScript">
//			function openPage(url, viewrecententries, fullscreen, indexaction, menuaction, submenuaction, uservariables, page, specialcolumnvariables, includeimage)
//			{
//				location.href = url + \'?viewrecententries=\' + viewrecententries + \'&fullscreen=\' + fullscreen + \'&indexaction=\' + indexaction + \'&menuaction=\' + menuaction + \'&submenuaction=\' + submenuaction + \'&\' + uservariables + \'&page=\' + page + \'&\' + specialcolumnvariables + \'&includeimage=\' + includeimage;
//			}
//		</script>';


//	if ($fullscreen=="yes" and !$viewrecententries)


	if ($uservariables !== "")
	{
		$uservariables = str_replace("+", "%2B", $uservariables);
	}



	if ($fullscreen=="yes")
		{
		if ($num_pages>1)
		{
			echo '
				<table width="100%">
				<tr>
					<td class="largetext" align="left"  bgcolor="#333333">
					<b>PAGES:</b><br>('.$pageidentifiername.')</td>
				</tr>
					<td class="largetextbold"  bgcolor="#212838">';
		}

		if ($prev_page)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$prev_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">&lt;&lt; Prev</a>\n\n";
			}
		for ($i = 1; $i <= $num_pages; $i++)
			{
			if ($i != $page)
				{
					echo "&nbsp;<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$i', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">".$pageidentifierdata[$i][$pageidentifiercolumn]."+</a>&nbsp;\n\n";
				}
				elseif ($num_pages > 1)
				{
					echo "&nbsp;&nbsp;".$pageidentifierdata[$i][$pageidentifiercolumn]."+&nbsp;&nbsp;";
				}
				else
				{
				}
			}
		if ($page != $num_pages)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$next_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">Next &gt;&gt;</a>";
			}

		if ($num_pages>1)
		{
			echo '
			</td></tr>
			<tr class="emptyline" height="10">&nbsp;</tr>
			</table>';
		}
	}
	elseif ($viewrecententries=="yes")
	{
		if ($num_pages>1)
		{
			echo '
				<table width="100%">
				<tr>
					<td class="largetext" align="left"  bgcolor="#333333">
					<b>PAGES:</b><br>('.$pageidentifiername.')</td>
				</tr>
					<td class="largetextbold"  bgcolor="#212838">';
		}

		if ($prev_page)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'yes', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$prev_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">&lt;&lt; Prev</a>\n\n";
			}
		for ($i = 1; $i <= $num_pages; $i++)
			{
			if ($i != $page)
				{
					echo "&nbsp;<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'yes', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$i', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">".$pageidentifierdata[$i][$pageidentifiercolumn]."+</a>&nbsp;\n\n";
				}
				elseif ($num_pages > 1)
				{
					echo "&nbsp;&nbsp;".$pageidentifierdata[$i][$pageidentifiercolumn]."+&nbsp;&nbsp;";
				}
				else
				{
				}
			}
		if ($page != $num_pages)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'yes', 'yes', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$next_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">Next &gt;&gt;</a>";
			}

		if ($num_pages>1)
		{
			echo '
			</td></tr>
			<tr class="emptyline" height="10">&nbsp;</tr>
			</table>';
		}
	}
	else
	{
		if ($num_pages>1)
		{
			echo '
				<table width="100%">
				<tr>
					<td class="largetext" align="left"  bgcolor="#333333">
					<b>PAGES:</b><br>('.$pageidentifiername.')</td>
				</tr>
					<td class="largetextbold"  bgcolor="#212838">';
		}

		if ($prev_page)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'no', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$prev_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">&lt;&lt; Prev</a>\n\n";
			}
		for ($i = 1; $i <= $num_pages; $i++)
			{
			if ($i != $page)
				{
					echo "&nbsp;<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'no', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$i', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">".$pageidentifierdata[$i][$pageidentifiercolumn]."+</a>&nbsp;\n\n";
				}
				elseif ($num_pages > 1)
				{
					echo "&nbsp;&nbsp;".$pageidentifierdata[$i][$pageidentifiercolumn]."+&nbsp;&nbsp;";
				}
				else
				{
				}
			}
		if ($page != $num_pages)
			{
				echo "<a class=\"whitelink\" onclick=\"openPage('$PHP_SELF', 'no', 'no', '$indexaction', '$menuaction', '$submenuaction', '$uservariables', '$next_page', '$specialcolumnvariables', '$includeimage', '$fastdataentry')\">Next &gt;&gt;</a>";
			}

		if ($num_pages>1)
		{
			echo '
			</td></tr>
			<tr class="emptyline" height="10">&nbsp;</tr>
			</table>';
		}
	}
?>