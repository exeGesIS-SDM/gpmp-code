<?php

# get area definitions and make sql commands

		if ($countsquares>0)
		{
			$squarename = explode("<br>or ", $listsquares);
			for ($i=0; $i<$countsquares; $i++)
			{
				$squarename[$i] = "featurelogsquares.squarename='".$squarename[$i]."'";
			}
			$sqlsquares = "AND (".implode(" OR ", $squarename).")";
			$wheresquares = "AND featurelogsquares.valid=true";
		}

		if ($countsupervisors>0)
		{
			$supervisor = explode("<br>or ", $listsupervisors);
			for ($i=0; $i<$countsupervisors; $i++)
			{
				$supervisor[$i] = "featurelogsupervisors.supervisor='".$supervisor[$i]."'";
			}
			$sqlsupervisors = "AND (".implode(" OR ", $supervisor).")";
			$wheresupervisors = "AND featurelogsupervisors.valid=true";
		}
		
		if ($area!='')
		{
			$sqlarea = "AND featurelogareas.area='$area'";
			$wherearea = "AND featurelogareas.valid=true";
		}


?>