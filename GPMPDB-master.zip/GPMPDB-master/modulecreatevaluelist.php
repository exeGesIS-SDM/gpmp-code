<?php
	
			
//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			$stat = pg_exec($dbh, $query);
			$rows = pg_numrows($stat);
			$columns = pg_numfields($stat);

//	CREATE CONTENT OUTPUT

			if ($selectnoform=='yes')
			{
			}
			else
			{
				echo '<form name="'.$formname.'" method="post" action="'.$formaction.'">';
			}

			if ($multipleselect=='yes')
			{
				echo '
				<select style="width: 155px;" name="'.$selectname.'" size="8" multiple>
				<option selected></option>';
			}
			else
			{
				if ($indexaction!='query')
				{
					echo '<input class="text" type="text" name="freetextfilter">&nbsp;&nbsp;';
				}
				
				echo '<select name="'.$selectname.'">
				<option selected></option>';
			}


			for	($i = 0; $i < $rows; $i++)
			{
			
				$data = pg_fetch_array($stat, $i);
		
					for	($j = 0; $j < $columns; $j++)
					{
						echo "<option>".$data[$j]."</option>";
					}
			}
			echo "</select>";


?>