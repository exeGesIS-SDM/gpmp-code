<?php

if ($fastdataentry=='yes')
{
	$evaluatefieldtype="yes";
	include 'modulefastdataentry.php';
}


# define link that can post variables on itself
	$neutralselflink=''.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&directedit='.$directedit.'&returnto='.$returnto.'&fastdataentry='.$fastdataentry.'';


# start transfer of data to database

if ($commit)
{
	# get session variables

	$toplinedata=$_SESSION['toplinedatasession'];
	$alldatamultiple=$_SESSION['alldatamultiple'];

	# start transaction

	$sql = "BEGIN;";
	@$stat = pg_exec($dbh, $sql);




	# delete old entries

		//	delete subline data in DB

// this is the case where there ARE multiple columns in a subquery
		if ($keyeditnumberofcolumns)
		{
			$query1 = $editquery." AND ".$tablename.".oid=$editline;";
			@$stat = pg_exec($dbh, $query1);
			$oldtoplinedata = pg_fetch_array($stat);

			for ($k = 1; $k < ($keyeditnumberofcolumns+1); $k++)
			{
				$keyvalue = htmlentities($oldtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
				$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
				$keyquery2 = "DELETE FROM $subtablename[$k] WHERE $keyfieldname=$keyvalue;";

				/// query information for subquery

				@$keystat = pg_exec($dbh, $keyquery2);
			}
		}

// this is the case where there are no multiple columns in a subquery
		if ($keynumberofcolumns and !$keyeditnumberofcolumns)
		{
			$query1 = $editquery." AND ".$tablename.".oid=$editline;";
			@$stat = pg_exec($dbh, $query1);
			$oldtoplinedata = pg_fetch_array($stat);

			for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
			{
				$keyvalue = htmlentities($oldtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
				$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
				$keyquery2 = "DELETE FROM $subtablename[$k] WHERE $keyfieldname=$keyvalue;";

				/// query information for subquery

				@$keystat = pg_exec($dbh, $keyquery2);
			}
		}

		// delete topline data in DB
		// @ supresses error messages from database!

		$query2 = "DELETE FROM ".$tablename." WHERE ".$tablename.".oid=$editline;";
		@$stat = pg_exec($dbh, $query2);


	# deal with top line data

	// strip whitespace left and right of string and create data with apostrophies and replace null values

	for ($i = 0; $i <= ($columns-1); $i++)
	{
		$toplinedata[$submenuaction][$i]=ltrim($toplinedata[$submenuaction][$i]);
		$toplinedata[$submenuaction][$i]=rtrim($toplinedata[$submenuaction][$i]);

		if ($toplinedata[$submenuaction][$i]=='')
		{
			$toplinedatawithapostrophies[$submenuaction][$i] = 'DEFAULT';
		}
		else
		{
			$toplinedatawithapostrophies[$submenuaction][$i] = "'".$toplinedata[$submenuaction][$i]."'";
		}
	}


	// add lines to db

	$topsqlpart1 = implode(", ", $columnnames);

	if ($toplinedata[$submenuaction]!='')
	{
		$topsqlpart2 = implode(", ", $toplinedatawithapostrophies[$submenuaction]);
		$topsql = "INSERT INTO ".$tablename." (".$topsqlpart1.", dbuser) VALUES (".$topsqlpart2.", '".$PHP_AUTH_USER."') RETURNING oid;";
		$statadddata = pg_exec($dbh, $topsql);
	}

	# get new id of record to use for subrecords

	// @$lastoid = pg_getlastoid($statadddata); // does not work with postgres 9.6+
	if($statadddata!==false) {
		@$lastoid = pg_fetch_result($statadddata, 0, 0); //get the oid from the result of the insert statement
		@$result = pg_exec($dbh,"SELECT $keyidname FROM $tablename WHERE oid=$lastoid");
		@$keyid = pg_result($result,0,0);
	} else {
		@$keyid = false;
	}

	# deal with all the subform fields

	for ($x=1; $x<=$subtables; $x++)
	{
		// create data with apostrophies and replace null values

		for ($i = 1; $i <= $countmultiple[$x]; $i++)
		{
			for ($j = 0; $j <= ($subcolumns[$x]-1); $j++)
			{
				if ($alldatamultiple[$submenuaction][$x][$i][$j]=='')
				{
					$alldatawithapostrophies[$submenuaction][$x][$i][$j] = 'DEFAULT';
				}
				else
				{
					$alldatawithapostrophies[$submenuaction][$x][$i][$j] = "'".$alldatamultiple[$submenuaction][$x][$i][$j]."'";
				}
			}
		}


		// add lines to db

		$sqlpart1 = implode(", ", $subcolumnnames[$x]);

		for ($i = 1; $i <= $countmultiple[$x]; $i++)
		{
			if ($alldatamultiple[$submenuaction][$x][$i]!='')
			{
				$sqlpart2[$i] = implode(", ", $alldatawithapostrophies[$submenuaction][$x][$i]);
				$sql = "INSERT INTO ".$subtablename[$x]." (".$subkeyidname[$x].", ".$sqlpart1.", dbuser) VALUES (".$keyid.", ".$sqlpart2[$i].", '".$PHP_AUTH_USER."');";
				@$statadddata = pg_exec($dbh, $sql);
			}
		}
	}

	# finish transaction

	$sql = "COMMIT;";
	@$stat = pg_exec($dbh, $sql);

	# create error message when upload failed

	if (!$statadddata)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error uploading the data to the database - please check the validity of your entries!')
		</SCRIPT>";
	}
	else
	{
		unset($toplinedata[$submenuaction]);
		$_SESSION['toplinedatasession']=$toplinedata;

		unset($toplinedataoutput[$submenuaction]);
		$_SESSION['toplinedataoutputsession']=$toplinedataoutput;

		unset($alldatamultiple[$submenuaction]);
		$_SESSION['alldatamultiple']=$alldatamultiple;

		unset ($editline);
	}

		unset ($commit);

}
else
{
	# get session variable
	$alldatamultiple=$_SESSION['alldatamultiple'];
}





/////////// start delete of data to database

if ($deletelines and $deleteoid != '')
{

	$limitperpage = 50;

	$sql = "BEGIN;";
	@$statbegin = pg_exec($dbh, $sql);


	# delete lines of db

	for	($i =0; $i < $limitperpage; $i++)
	{
		if ($deleteoid[$i] > 0)
		{

		//	delete subline data in DB
			// case when there ARE multiple columns in a subtable
			if ($keyeditnumberofcolumns)
			{
				$query1 = $editquery." AND ".$tablename.".oid=".$deleteoid[$i].";";
				@$stat = pg_exec($dbh, $query1);
				@$oldtoplinedata = pg_fetch_array($stat);

				for ($k = 1; $k < ($keyeditnumberofcolumns+1); $k++)
				{
					$keyvalue = htmlentities($oldtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
					@$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
					$keyquery2 = "DELETE FROM $subtablename[$k] WHERE $keyfieldname=$keyvalue;";

					/// query information for subquery

					@$keystat = pg_exec($dbh, $keyquery2);
				}
			}

			// case when there are no multiple columns in a subtable
			if ($keynumberofcolumns and !$keyeditnumberofcolumns)
			{
				$query1 = $editquery." AND ".$tablename.".oid=".$deleteoid[$i].";";
				@$stat = pg_exec($dbh, $query1);
				@$oldtoplinedata = pg_fetch_array($stat);

				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyvalue = htmlentities($oldtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
					@$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
					$keyquery2 = "DELETE FROM $subtablename[$k] WHERE $keyfieldname=$keyvalue;";

					/// query information for subquery

					@$keystat = pg_exec($dbh, $keyquery2);
				}
			}

			// delete topline data in DB
			// @ supresses error messages from database!

			$query2 = "SET enable_nestloop TO on; DELETE FROM ".$tablename." WHERE ".$tablename.".oid=".$deleteoid[$i].";";

			@$stat = pg_exec($dbh, $query2);
		}
	}

	# finish transaction

	$sql = "COMMIT;";
	@$statcommit = pg_exec($dbh, $sql);


	# create error message when upload failed

	if (!$stat)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error deleting the data in the database!')
		</SCRIPT>";
	}
	else
	{
	}

	unset ($deletelines);

}





if (!$editline)
{


# direct edit escape path

	if ($directedit=='yes')
	{
		$directedit='';
		$indexaction='editdelete';
		$menuaction='directeditgeneralrecords';
		$submenuaction='';

		include 'menudirecteditdata.php';
		die;
	}


# send header

echo'<table width="100%" border="0">
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="2" height="30">';

if ($viewrecententries=='yes')
{
	echo 'recent entries (12h) of '.$submenuaction.'</td></tr>';
}
else
{
	echo 'edit / delete data of '.$submenuaction.'</td></tr>';
}

if ($nosearchoptions!='yes')
{
	echo'
	<tr><td class="largetextbold" valign="top" width="15%" bgcolor="#333333">freetext filter:</td>
    <td class="largetext" valign="top" width="85%" align="left" bgcolor="#212838">';

	# add freetext search variables if existing
	if ($searchsql!='' and $searchcolumn)
	{
		echo "column '$searchcolumn' contains '$searchkeywords'";
	}
	else
	{
		echo "none";
	}

	echo'</td></tr>';
}

echo'</table>';



// add navigation bar

	include 'modulebrowsequerynavigation.php';


// bring up sort and search options

	include 'modulesortandsearch.php';


//	DEFINE QUERY

			// @ supresses error messages from database!
			//echo $query;
			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$columns = pg_numfields($stat);

//	CHECK IF QUERY IS CORRECT

			if	(!$stat)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br> Check your query!
				</td></tr></table>";
				die;
			}

//	CHECK IF RECORD EXISTS
			if	($rows==0)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				$norecordtext
				</td></tr></table>";
				die;
			}

if ($fullscreen=="yes")
	{
	$limit = 50;
	}
	else
	{
	$limit = 50;
	}


$per_page = $limit;
if (!$page)
	{
	$page = 1;
	}
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($per_page * $page) - $per_page;

if ($rows <= $per_page)
	{
	$num_pages = 1;
	}
	elseif(($rows % $per_page) == 0)
	{
	$num_pages = ($rows / $per_page);
	}
	else
	{
	$num_pages = ($rows / $per_page);
	}
$num_pages = ceil($num_pages);
if (($page > $num_pages) || ($page < 0))
	{
	echo "You have specified an invalid page number";
	die;
	}
$offset = (($page * $per_page) - $per_page);

$limit = ($page * $per_page);

if ($limit > $rows)
	{
	$limit = $rows;
	}


# generate adapted page markers

	$counter = 0;

	for	($i = 0; $i < $rows; $i= $i + $per_page)
	{
		$counter++;
		$pageidentifierdata[$counter] = pg_fetch_array($stat, $i);
	}


# identify column name of first order sorting

	for	($i =0; $i < $columns; $i++)
	{
		if (pg_fieldname($stat, $i)==$pageidentifiername)
		{
			$pageidentifiercolumn=$i;
		}
	}


include 'modulecreatedbtablepages.php';




if ($useraccesslevel>=3)
{
	# function bar

	echo'<form name="deletelines" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&returnto='.$returnto.'" method="POST">
	<table><tr>';

	/// add delete button

	echo'<td>
	<input type="submit" class="submitbutton" name="deletelines" value="delete selected lines"></td>';

	echo '</tr><tr><td class="emptyline" height="5">&nbsp;</td></tr></table>';
}



//	CREATE TABLE HEADINGS FOR DATA ARRAY

			for	($i =0; $i < $columns; $i++)
			{
				// saves headings for pdf output
				$headingtext[$i]=pg_fieldname($stat, $i);
			}
			if ($keynumberofcolumns)
			{
				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyquery2 = "$keyquery[$k];";
					$keystat = pg_exec($dbh, $keyquery2);
					$keycolumns = pg_numfields($keystat);

					for	($l =0; $l < $keycolumns; $l++)
					{
						$headingtext[$l+$k+$columns-1] = pg_fieldname($keystat, $l);
					}
				}
			}




//  CREATE QUERY RESULT FOR DATA ARRAY

			for	($i = $offset; $i < $limit; $i++)
			{
				$data = pg_fetch_array($stat, $i);

				for	($j = 0; $j < $columns; $j++)
				{
					$resulttext[$i][$j]=$data[$j];
				}


				if ($keynumberofcolumns)
				{
					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($data[$keycolumn[$k]], ENT_QUOTES);
						$keyfieldname = pg_fieldname($stat, $keycolumn[$k]);
						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";

						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$keyrows = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// create subquery output
						for	($l = 0; $l < $keyrows; $l++)
						{
							$keydata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								$resulttext[$i][$k-1+$columns] .= $keydata[$m];
							}
							if ($keyrows>1 and $l < ($keyrows-1))
							{
								$resulttext[$i][$k-1+$columns] .= ", ";
							}
							else
							{
							}
						}
					}
				}
			}

//	CLOSE PGSQL DATABASE

			pg_close($dbh);


//	CREATE TABLE HEADINGS

			echo '<table border="0"><tr>';

			if ($useraccesslevel>=3)
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25' colspan='2'>options</th>";
			}
			else
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>option</th>";
			}

			if ($includeimage=='yes')
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>image</th>";
			}
			for	($i =0; $i < $outputcolumns; $i++)
			{
				echo "<th class='columnheading' bgcolor='#333333' height='25'>".$headingtext[$outputcolumn[$i]]."</th>";
			}
			echo "</tr>";

//	CREATE CONTENT OUTPUT

			for	($i = $offset; $i < $limit; $i++)
			{
				if ($i%2)
				{
					echo "<tr bgcolor='#212838'>";
				}
				else
				{
					echo "<tr bgcolor='#1A1F2D'>";
				}

				echo '<td valign="top" width="10"><a href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&edit=yes&editline='.$resulttext[$i][0].'&returnto='.$returnto.'&fastdataentry='.$fastdataentry.'">
						<img src="images/edit-button.gif" border="0"></a></td>';

				if ($useraccesslevel>=3)
				{
				echo '<td valign="top" width="10"><div align="center"><input type="checkbox" class="tickbox" name="deleteoid[]>
				<input type="hidden" name="deleteline[]" value="'.$resulttext[$i][0].'"></div></td>';
				}

				if ($includeimage=='yes')
				{
					echo "<td align='center'><a href='moduleviewdigitals.php?imagenumber=".$data[$imagenumbercolumn]."' target='_blank'><img src='digitals/minithumbs/".$data[$imagenumbercolumn].".jpg' border='0'></a></td>";
				}

				for	($j = 0; $j < $outputcolumns; $j++)
				{
					if ($resulttext[$i][$outputcolumn[$j]]=='')
					{
						echo "<td>&nbsp;</td>";
					}
					else
					{
						echo "<td class='columntext' valign='top'>".$resulttext[$i][$outputcolumn[$j]]."</td>";
					}
				}

				echo '</tr>';

			}

if ($useraccesslevel>=3)
{
	/// add delete button

	echo'<table><tr><td class="emptyline" height="5">&nbsp;</td></tr>
	<tr><td>
	<input type="submit" class="submitbutton" name="deletelines" value="delete selected lines"></td>';

	echo '</tr></table>';

	echo'</form>';
}


//include 'modulecreatedbtablepages.php';

}



if ($editline)
{

// this is the case when there ARE muliple columns in a subquery
	if ($edit and $keyeditnumberofcolumns)
	{
		//	DEFINE TOPLINE QUERY

				// @ supresses error messages from database!

				$query = $editquery." AND ".$tablename.".oid=$editline;";
				@$stat = pg_exec($dbh, $query);


		//	DROP SELECTED ROW INTO VARIABLES

				$newtoplinedata = pg_fetch_array($stat);

# note: removed regular expression replace here 01 dec 2006
				#add backslashes to quotation marks for correct output
//				$pattern[0] = "/'/";
//				$pattern[1] = "/\"/";
//				$replacement[0] = "\'";
//				$replacement[1] = "\\\"";
				$pattern1 = "'";
				$pattern2 = '"';
				$replacement1 = "\'";
				$replacement2 = '\"';

                for ($i=0; $i<=($columns-1); $i++)
				{
//                  $newtoplinedata[$i]=preg_replace($pattern, $replacement, $newtoplinedata[$i]);
                    $newtoplinedata[$i]=str_replace($pattern1, $replacement1, $newtoplinedata[$i]);
                    $newtoplinedata[$i]=str_replace($pattern2, $replacement2, $newtoplinedata[$i]);
				}


		//	DEFINE SUBLINE QUERIES

				if ($keyeditnumberofcolumns)
				{

					for ($k = 1; $k < ($keyeditnumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($newtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
						$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
						if($tablename == "fielddata.synopticfeatureform")
						{
							$keyquery2 = "$keyeditquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keyeditsort[$k];";
						}
						else
						{
							$keyquery2 = "$keyeditquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";
						}
						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$countmultiple[$k] = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// drop data into variables
						for	($l = 0; $l < $countmultiple[$k]; $l++)
						{
							$newcolumndata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								$alldatamultiple[$submenuaction][$k][$l+1][$m]=$newcolumndata[$m];
							}
						}
					}
				}

		$_SESSION['alldatamultiple']=$alldatamultiple;
		$_SESSION['countmultiple']=$countmultiple;
	}

// this is the case when there are no muliple columns in a subquery
	elseif ($edit and !$keyeditnumberofcolumns)
	{
		//	DEFINE TOPLINE QUERY

				// @ supresses error messages from database!

				$query = $editquery." AND ".$tablename.".oid=$editline;";
				@$stat = pg_exec($dbh, $query);


		//	DROP SELECTED ROW INTO VARIABLES

				$newtoplinedata = pg_fetch_array($stat);


# note: removed regular expression replace here 01 dec 2006
				#add backslashes to quotation marks for correct output
//				$pattern[0] = "/'/";
//				$pattern[1] = "/\"/";
//				$replacement[0] = "\'";
//				$replacement[1] = "\\\"";
				$pattern1 = "'";
				$pattern2 = '"';
				$replacement1 = "\'";
				$replacement2 = '\"';

                for ($i=0; $i<=($columns-1); $i++)
				{
//                  $newtoplinedata[$i]=preg_replace($pattern, $replacement, $newtoplinedata[$i]);
                    $newtoplinedata[$i]=str_replace($pattern1, $replacement1, $newtoplinedata[$i]);
                    $newtoplinedata[$i]=str_replace($pattern2, $replacement2, $newtoplinedata[$i]);
				}


		//	DEFINE SUBLINE QUERIES

				if ($keynumberofcolumns)
				{

					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($newtoplinedata[$keyeditcolumn[$k]], ENT_QUOTES);
						$keyfieldname = pg_fieldname($stat, $keyeditcolumn[$k]);
						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";

						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$countmultiple[$k] = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// drop data into variables
						for	($l = 0; $l < $countmultiple[$k]; $l++)
						{
							$newcolumndata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								$alldatamultiple[$submenuaction][$k][$l+1][$m]=$newcolumndata[$m];
							}
						}
					}
				}

		$_SESSION['alldatamultiple']=$alldatamultiple;
		$_SESSION['countmultiple']=$countmultiple;
	}



# tab key emulation (replace tab with enter key)

echo "<SCRIPT LANGUAGE='JavaScript'>

nextfield = 'toplinedata1'; // name of first box on page
formname = 'topline';
netscape = '';
ver = navigator.appVersion; len = ver.length;
for(iln = 0; iln < len; iln++) if (ver.charAt(iln) == '(') break;
netscape = (ver.charAt(iln+1).toUpperCase() != 'C');

function keyDown(DnEvents) { // handles keypress
// determines whether Netscape or Internet Explorer
k = (netscape) ? DnEvents.which : window.event.keyCode;
if (k == 13) { // enter key pressed
if (nextfield == 'notadd') return true; // submit, we finished all fields
else { // we're not done yet, send focus to next box
eval('document.' + formname + '.' + nextfield + '.focus()');
return false;
      }
   }
}
document.onkeydown = keyDown; // work together to analyze keystrokes
if (netscape) document.captureEvents(Event.KEYDOWN|Event.KEYUP);
//  End -->
</script>";


# set focus to the relevant first field

if (!$update and !$addline and !$deleteline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.topline.toplinedata1.focus();
	}

	</script>
	<body onload="setFocus()">';
}

if ($update)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline1.newcolumndata11.focus();
	}

	</script>
	<body onload="setFocus()">';
}
if ($addline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline'.$addline.'.newcolumndata'.$addline.'1.focus();
	}

	</script>
	<body onload="setFocus()">';
}
if ($deleteline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline'.$subdelete.'.newcolumndata'.$subdelete.'1.focus();
	}

	</script>
	<body onload="setFocus()">';
}



# create array from topcolumn entered data form field

	$i=1;

	while ($i <= $columns)
	{
		$var= "toplinedata$i";
		global $$var;
		$newtoplinedata[] = $$var;
		$i++;
	}

# check if topcolumn has changed

	$entrycount = 0;

	for ($i = 0; $i <= ($columns-1); $i++)
	{
		if ($newtoplinedata[$i] != '')
		{
			$entrycount++;
		}
	}

if ($entrycount > 0)
{
	include 'componentdataentrycheck.php';
}

	if ($entrycount==0)
	{
		$toplinedata=$_SESSION['toplinedatasession'];
		$toplinedataoutput=$_SESSION['toplinedataoutputsession'];
	}
	else
	{
		for ($i=0; $i<=($columns-1); $i++)
		{
			if ($fieldtype[$i+1]=='checkbox')
			{
				if ($newtoplinedata[$i]=='on' or $newtoplinedata[$i]=='t')
				{
					$newtoplinedata[$i]='true';
				}
				else
				{
					$newtoplinedata[$i]='false';
				}
			}
			$toplinedata[$submenuaction][$i]=$newtoplinedata[$i];
			$_SESSION['toplinedatasession']=$toplinedata;

			# enable quotation marks in fields
			$toplinedataoutput[$submenuaction][$i]=stripslashes($toplinedata[$submenuaction][$i]);
			$toplinedataoutput[$submenuaction][$i]=htmlspecialchars($toplinedataoutput[$submenuaction][$i], ENT_QUOTES);
			$_SESSION['toplinedataoutputsession']=$toplinedataoutput;

		}
	}


# deal with all the subform fields


	// delete lines if commanded
	if ($delete)
	{
		for ($u=0; $u< count($deleteoid); $u++)
		{
			unset ($alldatamultiple[$submenuaction][$subdelete][$deleteoid[$u]]);
			$_SESSION['alldatamultiple']=$alldatamultiple; //deletes will never happen without this!
		}
		unset ($delete);
	}



for ($x=1; $x<=$subtables; $x++)
{
	if ($addline)
	{
		// create array from newcolumn entered data subform fields

		$i=1;

		while ($i <= $subcolumns[$x])
		{
			$var="newcolumndata$x$i";
			global $$var;
			$newcolumndata[$x][] = $$var;
			$i++;
		}
	}

	// checking, if data has been passed to the form

	$entrycount = 0;

	for ($i = 0; $i <= ($subcolumns[$x]-1); $i++)
	{
		if ($newcolumndata[$x][$i] != '')
		{
			$entrycount++;
		}
	}


# checking validity of new data

	if ($fastdataentry=='yes' and $subfieldtype_original[$x][1]=="dropdown")
	{
		$evaluatefieldtype="no";
		$processfastentry="yes";
		include 'modulefastdataentry.php';
	}
	else
	{
		if ($entrycount > 0)
		{
			include 'moduleduplicatecheck.php';
		}

		// adding new data to the list

		if ($entrycount > 0 and $addline==true)
		{
			$countmultiple[$x]++;
			$_SESSION['countmultiple']=$countmultiple;

			for ($i=0; $i<=($subcolumns[$x]-1); $i++)
			{
				// strip off whitespace left and right of string
				$newcolumndata[$x][$i]=ltrim($newcolumndata[$x][$i]);
				$newcolumndata[$x][$i]=rtrim($newcolumndata[$x][$i]);

				$alldatamultiple[$submenuaction][$x][$countmultiple[$x]][$i]=$newcolumndata[$x][$i];
				$_SESSION['alldatamultiple']=$alldatamultiple;
			}
		}
	}
}



# send header

echo'<table width="100%" border="0">
  <tr>
    <td class="emptyline" colspan="3" height="5">&nbsp;</td>
  </tr>
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="3" height="30">edit data of '.$submenuaction.'</td>
  </tr>';


# function bar

	echo'<tr bgcolor="#212838">';

/// add transaction button

	echo'<form name="commitlines" action="'.$neutralselflink.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="commit" value="update DB">
	<input type="hidden" name="editline" value="'.$editline.'"></td></form>';

/// add cancel button

	echo'<form name="canceledit" action="'.$neutralselflink.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="cancel" value="cancel">
	<input type="hidden" name="0" value="0"></td></form>';


/// add custom button

if ($custombutton=='yes')
{
	echo $custombuttonform;
}
else
{
	echo'<td>&nbsp;</td></tr>
		<tr><td class="emptyline" height="0">&nbsp;</td>';
}
echo "</tr>";

/// add fast entry button

	if ($fastdataentry=='yes')
	{
		echo '
		<form name="switchfastdataentry" action="'.$neutralselflink.'&fastdataentry=no" method="POST">
		<tr>
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">fast data entry:</td>
		    <td valign="top" colspan="6" bgcolor="#212838">
				<input type="submit" class="submitbutton" name="enablefiledownload" value="switch off">
				<input type="hidden" name="editline" value="'.$editline.'"></td>
		</tr>
		</form>';
	}
	else
	{
		echo '
		<form name="switchfastdataentry" action="'.$neutralselflink.'&fastdataentry=yes" method="POST">
		<tr>
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">fast data entry:</td>
		    <td valign="top" colspan="6" bgcolor="#212838">
				<input type="submit" class="submitbutton" name="enablefiledownload" value="switch on">
				<input type="hidden" name="editline" value="'.$editline.'"></td>
		</tr>
		</form>';
	}


echo '</table>';


/// evaluate if there are line breaks requested in top line

	$countlinebreaks=1;

	// set first column value
	unset ($firstcolumnnewline);
	$firstcolumnnewline[1] = 1;

	for ($i=1; $i<=$columns; $i++)
	{
		if ($startnewline[$i] == "yes")
		{
			$countlinebreaks = $countlinebreaks+1;
			$firstcolumnnewline[$countlinebreaks] = $i;
		}
	}
	// set last column value
	$firstcolumnnewline[$countlinebreaks+1] = $columns+1;



/// add single line at top

echo '<form name="topline" action="'.$neutralselflink.'" method="POST">';



// loop through line breaks in top line
for ($linebreakcounter=1; $linebreakcounter<=$countlinebreaks; $linebreakcounter++)
{
	// set the values to be used for outputting the lines
	$linestartcolumn = $firstcolumnnewline[$linebreakcounter];
	$lineendcolumn = $firstcolumnnewline[$linebreakcounter+1]-1;


# create table headings for top line

echo'<table border ="0" width="'.$tablewidth.'"><tr bgcolor="#333333">';

	for ($tablecolumn=$linestartcolumn; $tablecolumn<=$lineendcolumn; $tablecolumn++)
	{
		if ($fieldtype[$tablecolumn]=='hidden')
		{
		}
		else
		{
			echo'<th class="columnheading" nowrap width="'.$fieldcolumnwidth[$tablecolumn].'">
			'.$columnheader[$tablecolumn].'</th>';
		}
	}
	if ($lineendcolumn==$columns and $countlinebreaks>1)
	{
		echo '<th bgcolor="purple" class="columnheading" nowrap width="60">
		options</th></tr>';
	}
	elseif ($lineendcolumn==$columns and $countlinebreaks==1)
	{
		echo '<th class="columnheading" nowrap width="60">
		options</th></tr>';
	}
	else
	{
		echo '</tr>';
	}

	echo '<tr bgcolor="#1A1F2D">';

	for ($tablecolumn=$linestartcolumn; $tablecolumn<=$lineendcolumn; $tablecolumn++)
	{
		if ($tablecolumn==$columns)
		{
			$nextfield = "nextfield = 'update'; formname = 'topline'";
		}
		else
		{
			$nextfield = "nextfield = 'toplinedata".($tablecolumn+1)."'; formname = 'topline'";
		}

		if ($fieldtype[$tablecolumn]=='text')
		{
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
			<input type="text" class="text" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$toplinedataoutput[$submenuaction][$tablecolumn-1].'"></td>';
		}
		elseif ($fieldtype[$tablecolumn]=='password')
		{
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
			<input type="password" class="text" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$toplinedataoutput[$submenuaction][$tablecolumn-1].'">';
		}
		elseif ($fieldtype[$tablecolumn]=='checkbox')
		{
			if ($toplinedataoutput[$submenuaction][$tablecolumn-1]=='true')
			{
				$checkboxstatus='checked';
			}
			else
			{
				$checkboxstatus='';
			}
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
			<input type="checkbox" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" '.$checkboxstatus.'>';
		}
		elseif ($fieldtype[$tablecolumn]=='hidden')
		{
		}
		else
		{
			$query = $dropdownsql[$tablecolumn];
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>';
			$selectfieldname = "toplinedata$tablecolumn";

			$optionselected = $toplinedataoutput[$submenuaction][$tablecolumn-1];

			$selectwidth="".($fieldlength[$tablecolumn]*12)."px;";

			include 'moduledataentrydropdown.php';

			echo'</td>';
		}
	}
	if ($lineendcolumn==$columns)
	{
		echo'
		<td width="60"><input type="submit" class="submitbutton" name="update" value="update">
		<input type="hidden" name="editline" value="'.$editline.'"></td></tr></table></form><br>';
	}
}

# adding sub lines outputs

for ($x=1; $x<=$subtables; $x++)
{


# create a container for sub lines

	echo'<div id="'.$subdivid[$x].'" style="'.$subdivstyle[$x].'">';


# create table headings for sub lines

echo'<table border ="0" width="'.$subtablewidth[$x].'"><tr bgcolor="#333333">';

	for ($i=1; $i<=$subcolumns[$x]; $i++)
	{
		echo'<th class="columnheading" nowrap width="'.$subfieldcolumnwidth[$x][$i].'">
		'.$subcolumnheader[$x][$i].'</th>';
	}
	echo '<th class="columnheading" nowrap width="60">
	options</th></tr>';


/// add empty line for sub input at top

	echo '<form name="subline'.$x.'" action="'.$neutralselflink.'" method="POST"><tr bgcolor="#1A1F2D">';

	for ($subtablecolumn=1; $subtablecolumn<=$subcolumns[$x]; $subtablecolumn++)
	{
		if ($subtablecolumn==$subcolumns[$x])
		{
		$nextfield = "nextfield = 'add".$x."'; formname = 'subline".$x."'";
		}
		else
		{
		$nextfield = "nextfield = 'newcolumndata".$x."".($subtablecolumn+1)."'; formname = 'subline".$x."'";
		}

		if ($subfieldtype[$x][$subtablecolumn]=='text')
		{
			echo'<td width="'.$subfieldcolumnwidth[$x][$subtablecolumn].'" nowrap>
			<input type="text" class="text" name="newcolumndata'.$x.''.$subtablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$subfieldlength[$x][$subtablecolumn].'" size="'.$subfieldsize[$x][$subtablecolumn].'"></td>';
		}
		else
		{
			$query = $subdropdownsql[$x][$subtablecolumn];
			echo'<td width="'.$subfieldcolumnwidth[$x][$subtablecolumn].'" nowrap>';
			$selectfieldname = "newcolumndata$x$subtablecolumn";
			$optionselected = "";

			$selectwidth="".($subfieldlength[$x][$subtablecolumn]*12)."px;";

			include 'moduledataentrydropdown.php';

			echo'</td>';
		}
	}
	echo'
		<td width="60"><input type="submit" class="submitbutton" name="add'.$x.'" value="add">
		<input type="hidden" name="addline" value="'.$x.'">
		<input type="hidden" name="editline" value="'.$editline.'"></td></tr></form>

		<form name="outputsublines" action="'.$neutralselflink.'" method="POST">
		<tr bgcolor="#1A1F2D"><td width="60">
			<input type="submit" class="submitbutton" name="delete" value="delete selected">
			<input type="hidden" name="editline" value="'.$editline.'"></td></tr>';


# create output of already entered lines

	for ($i = 1; $i <= $countmultiple[$x]; $i++)
	{
		if ($alldatamultiple[$submenuaction][$x][$i]!='')
		{
			echo'<tr bgcolor="#1A1F2D">';

			for ($j = 0; $j <= ($subcolumns[$x]-1); $j++)
			{
				if ($alldatamultiple[$submenuaction][$x][$i][$j]=='')
				{
					echo "<td>&nbsp;</td>";
				}
				else
				{
					echo '<td class="columntext" width="'.$subfieldcolumnwidth[$x][$j+1].'" nowrap valign="top">
					'.$alldatamultiple[$submenuaction][$x][$i][$j].'</td>';
				}
			}
			echo '<td>
			<input type="checkbox" class="tickbox" name="deleteoid[]" value="'.$i.'">
			<input type="hidden" name="subdelete" value="'.$x.'"></td></tr>';
		}
	}
	echo '</form></table></div>';
}
}

?>
