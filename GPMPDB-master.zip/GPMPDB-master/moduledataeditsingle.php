<?php


# define link that can post variables on itself
	$neutralselflink=''.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&returnto='.$returnto.'';

	$tablewidth = 760;

# tab key emulation (replace tab with enter key)

if ($edit)
{
echo "<SCRIPT LANGUAGE='JavaScript'>

nextfield = 'newcolumndata1'; // name of first box on page
netscape = '';
ver = navigator.appVersion; len = ver.length;
for(iln = 0; iln < len; iln++) if (ver.charAt(iln) == '(') break;
netscape = (ver.charAt(iln+1).toUpperCase() != 'C');

function keyDown(DnEvents) { // handles keypress
// determines whether Netscape or Internet Explorer
k = (netscape) ? DnEvents.which : window.event.keyCode;
if (k == 13) { // enter key pressed
if (nextfield == 'notupdate') return true; // submit, we finished all fields
else { // we're not done yet, send focus to next box
eval('document.inputline.' + nextfield + '.focus()');
return false;
      }
   }
}
document.onkeydown = keyDown; // work together to analyze keystrokes
if (netscape) document.captureEvents(Event.KEYDOWN|Event.KEYUP);
//  End -->
</script>";



# set focus to first fields
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.inputline.newcolumndata1.focus();
	}

	</script>
	<body onload="setFocus()">';
}


//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			// @ supresses error messages from database!

			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$tablecolumns = pg_numfields($stat);

//	CHECK IF QUERY IS CORRECT

			if	(!$stat)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br> Check your query!
				</td></tr></table>";
				die;
			}



# create array from newcolumn entered data form field

	$i=1;

	while ($i <= $tablecolumns)
	{
		$var="newcolumndata$i";
		global $$var;
		$newcolumndata[] = $$var;
		$i++;
	}


# checking validity of new data

if ($update)
{
	include 'componentdataentrycheck.php';
}

# start update of data to database

if ($update)
{
	$sql = "BEGIN;";
	@$statbegin = pg_exec($dbh, $sql);

	# check for validity of records and lock them

	$sqllock = "SELECT * FROM ".$tablename." WHERE ".$tablename.".oid =".$updateline." AND ".$tablename.".valid=true FOR UPDATE;";
	@$statlockdata = pg_exec($dbh, $sqllock);
	@$rows = pg_numrows($statlockdata);

	if ($rows==0)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('Data could not be updated in database - data row does not exist anymore.')
		</SCRIPT>";
		$sqlrollback = "ROLLBACK;";
		@$statrollback = pg_exec($dbh, $sqlrollback);
	}
	else
	{
	# remove left and right whitespace and create data with apostrophies and replace null values

		for ($i = 0; $i < ($tablecolumns-1); $i++)
		{
			if ($fieldtype[$i+1]=='checkbox')
			{
				if ($newcolumndata[$i]=='on')
				{
					$newcolumndata[$i]='true';
				}
				else
				{
					$newcolumndata[$i]='false';
				}
			}
			$newcolumndata[$i]=ltrim($newcolumndata[$i]);
			$newcolumndata[$i]=rtrim($newcolumndata[$i]);

			$newcolumndatawithapostrophies[$i] = "'".$newcolumndata[$i]."'";
		}


	# create set command data


	for ($i = 0; $i < ($tablecolumns-1); $i++)
	{
		if ($newcolumndata[$i] == '')
		{
			$setcommanddata[$i] = "".$columnnames[$i+1]."=NULL";
		}
		else
		{
			$setcommanddata[$i] = "".$columnnames[$i+1]."=".$newcolumndatawithapostrophies[$i]."";
		}
	}
	$setcommanddata = implode(", ", $setcommanddata);

	# update lines to db

	if ($newcolumndata != '')
	{
		$sqlupdate = "UPDATE ".$tablename." SET ".$setcommanddata.", dbuser='".$PHP_AUTH_USER."' WHERE ".$tablename.".oid =".$updateline.";";
		@$statupdatedata = pg_exec($dbh, $sqlupdate);
	}


	# finish transaction

	$sql = "COMMIT;";
	@$statcommit = pg_exec($dbh, $sql);


	# create error message when upload failed

	if (!$statupdatedata)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error updating the data in the database - please check the validity of your entries!')
		</SCRIPT>";
	}
	else
	{
	}
	}
	unset ($update);

}



/////////// start delete of data to database

if ($deletelines and $deleteoid != '')
{
	$limitperpage = 50;


	$sql = "BEGIN;";
	@$statbegin = pg_exec($dbh, $sql);


	# delete lines of db

	for	($i =0; $i < $limitperpage; $i++)
	{
		if ($deleteoid[$i] > 0)
		{
			$sqldelete = "SET enable_nestloop TO on; DELETE FROM ".$tablename." WHERE ".$tablename.".oid =".$deleteoid[$i].";";
			@$statdeletedata = pg_exec($dbh, $sqldelete);
		}
	}


	# finish transaction

	$sql = "COMMIT;";
	@$statcommit = pg_exec($dbh, $sql);


	# create error message when upload failed

	if (!$statdeletedata)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error deleting the data in the database!')
		</SCRIPT>";
	}
	else
	{
	}

	unset ($deletelines);

}


//	RELOAD QUERY DEFINITION TO SHOW UPDATED RECORDS!!!

			// @ supresses error messages from database!

			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$tablecolumns = pg_numfields($stat);


# send header

echo'<table width="100%" border="0">
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="2" height="30">';

if ($viewrecententries=='yes')
{
	echo 'recent entries (12h) of '.$submenuaction.'</td></tr>';
}
else
{
	echo 'edit / delete data of '.$submenuaction.'</td></tr>';
}

if ($nosearchoptions!='yes')
{
	echo'
	<tr><td class="largetextbold" valign="top" width="15%" bgcolor="#333333">freetext filter:</td>
    <td class="largetext" valign="top" width="85%" align="left" bgcolor="#212838">';

	# add freetext search variables if existing
	if ($searchsql!='' and $searchcolumn)
	{
		echo "column '$searchcolumn' contains '$searchkeywords'";
	}
	else
	{
		echo "none";
	}

	echo'</td></tr>';
}

	echo '</table>';

// add navigation bar

	include 'modulebrowsequerynavigation.php';


// bring up sort and search options

	include 'modulesortandsearch.php';



$limit = 50;

$per_page = $limit;
if (!$page)
	{
	$page = 1;
	}
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($per_page * $page) - $per_page;

if ($rows <= $per_page)
	{
	$num_pages = 1;
	}
	elseif(($rows % $per_page) == 0)
	{
	$num_pages = ($rows / $per_page);
	}
	else
	{
	$num_pages = ($rows / $per_page);
	}
$num_pages = ceil($num_pages);
if (($page > $num_pages) || ($page < 0))
	{
	echo "You have specified an invalid page number";
	die;
	}
$offset = (($page * $per_page) - $per_page);

$limit = ($page * $per_page);

if ($limit > $rows)
	{
	$limit = $rows;
	}


# generate adapted page markers

	$counter = 0;

	for	($i = 0; $i < $rows; $i= $i + $per_page)
	{
		$counter++;
		$pageidentifierdata[$counter] = pg_fetch_array($stat, $i);
	}


# identify column name of first order sorting

	for	($i =0; $i <= $columns; $i++)
	{
		if (pg_fieldname($stat, $i)==$pageidentifiername)
		{
			$pageidentifiercolumn=$i;
		}
	}


include 'modulecreatedbtablepages.php';



if ($useraccesslevel>=3)
{
	if (!$editline)
	{
		# function bar

			echo'<form name="deletelines" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&returnto='.$returnto.'" method="POST">
			<table><tr>';

		/// add deletion button

			echo'<td>
			<input type="submit" class="submitbutton" name="deletelines" value="delete selected lines"></td>';

			echo '</tr><tr><td class="emptyline" height="5">&nbsp;</td></tr></table>';
	}
}


//	CREATE TABLE HEADINGS

			echo '<table border="0" width="'.$tablewidth.'"><tr>';


			echo '<th class="columnheading" nowrap bgcolor="#333333" height="25" colspan="2">options</th>';


			for	($i =1; $i < $tablecolumns; $i++)
			{
				echo '<th class="columnheading" nowrap width="'.$fieldcolumnwidth[$i].'" bgcolor="#333333" height="25">'.pg_fieldname($stat, $i).'</th>';
			}
			echo '</tr>';


//	CREATE CONTENT OUTPUT

			for	($i = $offset; $i < $limit; $i++)
			{
				$data = pg_fetch_array($stat, $i);

				if ($i%2)
				{
					echo "<tr bgcolor='#212838'>";
				}
				else
				{
					echo "<tr bgcolor='#1A1F2D'>";
				}

				if ($editline==$data[0])
				{
					echo '<form name="inputline" action="'.$neutralselflink.'" method="POST">';

					echo'<td width="10"><input type="submit" class="submitbutton" name="update" value="update">
							<input type="hidden" name="updateline" value="'.$data[0].'"></td>';

					echo '<td width="10"><a href="'.$neutralselflink.'">
							<img src="images/cancel-button.gif" border="0"></a></td>';

					for ($tablecolumn=1; $tablecolumn<=$columns; $tablecolumn++)
					{
						# enable quotation marks in fields
						$data[$tablecolumn]=stripslashes($data[$tablecolumn]);
						$data[$tablecolumn]=htmlspecialchars($data[$tablecolumn], ENT_QUOTES);

						if ($tablecolumn==$columns)
						{
							$nextfield = "nextfield = 'update'";
						}
						else
						{
							$nextfield = "nextfield = 'newcolumndata".($tablecolumn+1)."'";
						}

						if ($fieldtype[$tablecolumn]=='text')
						{
							echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
							<input type="text" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$data[$tablecolumn].'"></td>';
						}
						elseif ($fieldtype[$tablecolumn]=='password')
						{
							echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
							<input type="password" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$data[$tablecolumn].'"></td>';
						}
						elseif ($fieldtype[$tablecolumn]=='checkbox')
						{
							if ($data[$tablecolumn]=='yes')
							{
								$checkboxstatus='checked';
							}
							else
							{
								$checkboxstatus='';
							}
							echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
							<input type="checkbox" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" '.$checkboxstatus.'></td>';
						}
						else
						{
							$query = $dropdownsql[$tablecolumn];
							echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>';
							$selectfieldname = "newcolumndata$tablecolumn";
							$optionselected = $data[$tablecolumn];

							$selectwidth="".($fieldlength[$tablecolumn]*12)."px;";

							include 'moduledataentrydropdown.php';

							echo'</td>';
						}
					}
					echo'</tr></form>';
				}
				else
				{

					echo '<td valign="top" width="10"><a href="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&page='.$page.'&includeimage='.$includeimage.'&edit=yes&editline='.$data[0].'&returnto='.$returnto.'">
						<img src="images/edit-button.gif" border="0"></a></td>';

					if ($useraccesslevel>=3)
					{
						if (!$editline)
						{
							echo '<td valign="top" width="10"><div align="center"><input type="checkbox" class="tickbox" name="deleteoid[]>
								<input type="hidden" name="deleteline[]" value="'.$data[0].'"></div></td>';
						}
						else
						{
							echo '<td>&nbsp;</td>';
						}
					}
					else
					{
						echo '<td>&nbsp;</td>';
					}

					for	($j = 1; $j < $tablecolumns; $j++)
					{
						if ($fieldtype[$j]=='password')
						{
							echo "<td class='columntext' valign='top'>****************</td>";
						}
						elseif ($data[$j]=='')
						{
							echo "<td>&nbsp;</td>";
						}
						else
						{
							echo "<td class='columntext' valign='top'>".$data[$j]."</td>";
						}
					}

					echo '</tr>';
				}
			}


if ($useraccesslevel>=3)
{
	if (!$editline)
	{
		/// add deletion button

			echo'<table><tr><td class="emptyline" height="5">&nbsp;</td></tr>
			<tr><td>
			<input type="submit" class="submitbutton" name="deletelines" value="delete selected lines"></td>';

			echo '</tr></table>';

		echo '</form>';
	}
}


//	CLOSE PGSQL DATABASE

			pg_close($dbh);


//include 'modulecreatedbtablepages.php';

?>