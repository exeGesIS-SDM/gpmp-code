<?php


//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			$statdd = pg_exec($dbh, $query);
			$rowsdd = pg_numrows($statdd);
			$columnsdd = pg_numfields($statdd);

//	CREATE CONTENT OUTPUT

		
			echo '<select style="width: '.$selectwidth.'" name="'.$selectfieldname.'" onFocus="'.$nextfield.'">
			<option selected>'.$optionselected.'</option>';

			for	($l = 0; $l < $rowsdd; $l++)
			{
			
				$datadd = pg_fetch_array($statdd, $l);
		
					for	($m = 0; $m < $columnsdd; $m++)
					{
						echo "<option>".$datadd[$m]."</option>";
					}
			}
			echo "<option></option>";
			echo "</select>";


?>