<?php

if ($fastdataentry=='yes')
{
	$evaluatefieldtype="yes";
	include 'modulefastdataentry.php';
}

# tab key emulation (replace tab with enter key)

echo "<SCRIPT LANGUAGE='JavaScript'>

nextfield = 'toplinedata1'; // name of first box on page
formname = 'topline';
netscape = '';
ver = navigator.appVersion; len = ver.length;
for(iln = 0; iln < len; iln++) if (ver.charAt(iln) == '(') break;
netscape = (ver.charAt(iln+1).toUpperCase() != 'C');

function keyDown(DnEvents) { // handles keypress
// determines whether Netscape or Internet Explorer
k = (netscape) ? DnEvents.which : window.event.keyCode;
if (k == 13) { // enter key pressed
if (nextfield == 'notadd') return true; // submit, we finished all fields
else { // we're not done yet, send focus to next box
eval('document.' + formname + '.' + nextfield + '.focus()');
return false;
      }
   }
}
document.onkeydown = keyDown; // work together to analyze keystrokes
if (netscape) document.captureEvents(Event.KEYDOWN|Event.KEYUP);
//  End -->
</script>";


if ($recallpreviousrecordvalues)
{
		$toplinedata=$_SESSION['previoustoplinedatasession'];
		$_SESSION['toplinedatasession']=$toplinedata;

		$toplinedataoutput=$_SESSION['previoustoplinedataoutputsession'];
		$_SESSION['toplinedataoutputsession']=$toplinedataoutput;

		$alldatamultiple=$_SESSION['previousalldatamultiple'];
		$_SESSION['alldatamultiple']=$alldatamultiple;
}


# set focus to the relevant first field

if (!$update and !$addline and !$deleteline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.topline.toplinedata1.focus();
	}

	</script>
	<body onload="setFocus()">';
}

if ($update)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline1.newcolumndata11.focus();
	}

	</script>
	<body onload="setFocus()">';
}
if ($addline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline'.$addline.'.newcolumndata'.$addline.'1.focus();
	}

	</script>
	<body onload="setFocus()">';
}
if ($deleteline)
{
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.subline'.$subdelete.'.newcolumndata'.$subdelete.'1.focus();
	}

	</script>
	<body onload="setFocus()">';
}

# clear entry if requested

if ($clearform)
{
	unset($toplinedata[$submenuaction]);
	$_SESSION['toplinedatasession']=$toplinedata;

	unset($toplinedataoutput[$submenuaction]);
	$_SESSION['toplinedataoutputsession']=$toplinedataoutput;

	unset($alldatamultiple[$submenuaction]);
	$_SESSION['alldatamultiple']=$alldatamultiple;

	unset ($clearentry);
}




# start transfer of data to database

if ($commit)
{
	# get session variables

	$toplinedata=$_SESSION['toplinedatasession'];
	$alldatamultiple=$_SESSION['alldatamultiple'];

	# start transaction

	$sql = "BEGIN;";
	@$stat = pg_exec($dbh, $sql);


	# deal with top line data

	// remove whitespaces from strings and create data with apostrophies and replace null values

	for ($i = 0; $i <= ($columns-1); $i++)
	{
		$toplinedata[$submenuaction][$i]=ltrim($toplinedata[$submenuaction][$i]);
		$toplinedata[$submenuaction][$i]=rtrim($toplinedata[$submenuaction][$i]);

		if ($toplinedata[$submenuaction][$i]=='')
		{
			$toplinedatawithapostrophies[$submenuaction][$i] = 'DEFAULT';
		}
		else
		{
			$toplinedatawithapostrophies[$submenuaction][$i] = "'".$toplinedata[$submenuaction][$i]."'";
		}
	}


	// add lines to db

	$topsqlpart1 = implode(", ", $columnnames);

	if ($toplinedata[$submenuaction]!='')
	{
		$topsqlpart2 = implode(", ", $toplinedatawithapostrophies[$submenuaction]);
		$topsql = "INSERT INTO ".$tablename." (".$topsqlpart1.", dbuser) VALUES (".$topsqlpart2.", '".$PHP_AUTH_USER."') RETURNING oid;";
		@$statadddata = pg_exec($dbh, $topsql);
	}

	# get new id of record to use for subrecords

	// @$lastoid = pg_getlastoid($statadddata); // does not work with postgres 9.6+
	if($statadddata!==false) {
		@$lastoid = pg_fetch_result($statadddata, 0, 0); //get the oid from the result of the insert statement
		@$result = pg_exec($dbh,"SELECT $keyidname FROM $tablename WHERE oid=$lastoid");
		@$keyid = pg_result($result,0,0);
	} else {
		@$keyid = false;
	}


	# deal with all the subform fields

	for ($x=1; $x<=$subtables; $x++)
	{
		// create data with apostrophies and replace null values

		for ($i = 1; $i <= $countmultiple[$x]; $i++)
		{
			for ($j = 0; $j <= ($subcolumns[$x]-1); $j++)
			{
				if ($alldatamultiple[$submenuaction][$x][$i][$j]=='')
				{
					$alldatawithapostrophies[$submenuaction][$x][$i][$j] = 'DEFAULT';
				}
				else
				{
					$alldatawithapostrophies[$submenuaction][$x][$i][$j] = "'".$alldatamultiple[$submenuaction][$x][$i][$j]."'";
				}
			}
		}


		// add lines to db

		$sqlpart1 = implode(", ", $subcolumnnames[$x]);

		for ($i = 1; $i <= $countmultiple[$x]; $i++)
		{
			if ($alldatamultiple[$submenuaction][$x][$i]!='')
			{
				$sqlpart2[$i] = implode(", ", $alldatawithapostrophies[$submenuaction][$x][$i]);
				$sql = "INSERT INTO ".$subtablename[$x]." (".$subkeyidname[$x].", ".$sqlpart1.", dbuser) VALUES (".$keyid.", ".$sqlpart2[$i].", '".$PHP_AUTH_USER."');";
				@$statadddata = pg_exec($dbh, $sql);
			}
		}
	}

	# finish transaction

	$sql = "COMMIT;";
	@$stat = pg_exec($dbh, $sql);

	# create error message when upload failed

	if (!$statadddata)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error uploading the data to the database - please check the validity of your entries!')
		</SCRIPT>";
	}
	else
	{
		$previoustoplinedata[$submenuaction]=$toplinedata[$submenuaction];
		$_SESSION['previoustoplinedatasession']=$previoustoplinedata;
		unset($toplinedata[$submenuaction]);
		$_SESSION['toplinedatasession']=$toplinedata;

		$toplinedataoutput=$_SESSION['toplinedataoutputsession'];
		$previoustoplinedataoutput[$submenuaction]=$toplinedataoutput[$submenuaction];
		$_SESSION['previoustoplinedataoutputsession']=$previoustoplinedataoutput;
		unset($toplinedataoutput[$submenuaction]);
		$_SESSION['toplinedataoutputsession']=$toplinedataoutput;

		$previousalldatamultiple[$submenuaction]=$alldatamultiple[$submenuaction];
		$_SESSION['previousalldatamultiple']=$previousalldatamultiple;
		unset($alldatamultiple[$submenuaction]);
		$_SESSION['alldatamultiple']=$alldatamultiple;
	}

		unset ($commit);
}
else
{
	# get session variable
	$alldatamultiple=$_SESSION['alldatamultiple'];
}



# create array from topcolumn entered data form field


	$i=1;

	while ($i <= $columns)
	{
		$var="toplinedata$i";
		global $$var;
		$newtoplinedata[] = $$var;
		$i++;
	}

# check if topcolumn has changed

	$entrycount = 0;

	for ($i = 0; $i <= ($columns-1); $i++)
	{
		if ($newtoplinedata[$i] != '')
		{
			$entrycount++;
		}
	}


# checking validity of new data

if ($entrycount > 0)
{
	include 'componentdataentrycheck.php';
}


	if ($entrycount==0 and !$recallpreviousrecordvalues)
	{
		$toplinedata=$_SESSION['toplinedatasession'];
		$toplinedataoutput=$_SESSION['toplinedataoutputsession'];
	}
	elseif ($recallpreviousrecordvalues)
	{
	}
	else
	{
		for ($i=0; $i<=($columns-1); $i++)
		{
			if ($fieldtype[$i+1]=='checkbox')
			{
				if ($newtoplinedata[$i]=='on')
				{
					$newtoplinedata[$i]='true';
				}
				else
				{
					$newtoplinedata[$i]='false';
				}
			}
			$toplinedata[$submenuaction][$i]=$newtoplinedata[$i];
			$_SESSION['toplinedatasession']=$toplinedata;

			# enable quotation marks in fields
			$toplinedataoutput[$submenuaction][$i]=stripslashes($toplinedata[$submenuaction][$i]);
			$toplinedataoutput[$submenuaction][$i]=htmlspecialchars($toplinedataoutput[$submenuaction][$i], ENT_QUOTES);
			$_SESSION['toplinedataoutputsession']=$toplinedataoutput;
		}
	}


# deal with all the subform fields

	// delete lines if commanded
	if ($delete)
	{
		for ($u=0; $u< count($deleteoid); $u++)
		{
			unset ($alldatamultiple[$submenuaction][$subdelete][$deleteoid[$u]]);
		}
		unset ($delete);
	}

for ($x=1; $x<=$subtables; $x++)
{
	// create array from newcolumn entered data subform fields

	$i=1;

	while ($i <= $subcolumns[$x])
	{
		$var="newcolumndata$x$i";
		global $$var;
		$newcolumndata[$x][] = $$var;
		$i++;
	}


	// checking, if data has been passed to the form

	$entrycount = 0;

	for ($i = 0; $i <= ($subcolumns[$x]-1); $i++)
	{
		if ($newcolumndata[$x][$i] != '')
		{
			$entrycount++;
		}
	}


	# checking validity of new data

	if ($fastdataentry=='yes' and $subfieldtype_original[$x][1]=="dropdown")
	{
		$evaluatefieldtype="no";
		$processfastentry="yes";
		include 'modulefastdataentry.php';
	}
	else
	{
		if ($entrycount > 0)
		{
			include 'moduleduplicatecheck.php';
		}

		// adding new data to the list

		if ($entrycount > 0 and $addline==true)
		{
			$countmultiple[$x]++;
			$_SESSION['countmultiple']=$countmultiple;

			for ($i=0; $i<=($subcolumns[$x]-1); $i++)
			{
				// strip off whitespace left and right of string
				$newcolumndata[$x][$i]=ltrim($newcolumndata[$x][$i]);
				$newcolumndata[$x][$i]=rtrim($newcolumndata[$x][$i]);

				$alldatamultiple[$submenuaction][$x][$countmultiple[$x]][$i]=$newcolumndata[$x][$i];
				$_SESSION['alldatamultiple']=$alldatamultiple;
			}
		}
	}
}


# send header

echo'<table width="100%" border="0">
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="5" height="30">add data to '.$submenuaction.'</td>
  </tr>';


# function bar

	echo'<tr bgcolor="#212838">';

/// add transaction button

	echo'<form name="commitlines" action="'.$PHP_self.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="commit" value="upload data"></td></form>';


/// add view button

	echo'<form name="viewrecententries" action="'.$sitebasefile.'?viewrecententries=yes&indexaction=edit&menuaction=editdeletedata&submenuaction='.$submenuaction.'&fastdataentry='.$fastdataentry.'&returnto=adddata" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="viewrecent" value="view entries / changes of last 12h"></td></form>';

/// add recall previously uploaded record button

	echo'<form name="recallrecord" action="'.$PHP_self.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="recallpreviousrecordvalues" value="recall previous record"></td></form>';

/// add clear button

	echo'<form name="clearthisform" action="'.$PHP_self.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="clearform" value="clear form"></td></form>';

/// add custom button

if ($custombutton=='yes')
{
	echo $custombuttonform;
}
else
{
	echo'<td>&nbsp;</td></tr>
		<tr><td class="emptyline" height="0">&nbsp;</td>';
}
echo "</tr>";

/// add fast entry button

	if ($fastdataentry=='yes')
	{
		echo '
		<form name="switchfastdataentry" action="'.$PHP_SELF.'?'.$_SERVER['QUERY_STRING'].'&'.$uservariables.'&'.$specialcolumnvariables.'&fastdataentry=no" method="POST">
		<tr>
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">fast data entry:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="enablefiledownload" value="switch off"></td>
		</tr>
		</form>';
	}
	else
	{
		echo '
		<form name="switchfastdataentry" action="'.$PHP_SELF.'?'.$_SERVER['QUERY_STRING'].'&'.$uservariables.'&'.$specialcolumnvariables.'&fastdataentry=yes" method="POST">
		<tr>
		    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">fast data entry:</td>
		    <td valign="top" colspan="6" bgcolor="#212838"><input type="submit" class="submitbutton" name="enablefiledownload" value="switch on"></td>
		</tr>
		</form>';
	}


echo '</table>';


/// evaluate if there are line breaks requested in top line

	$countlinebreaks=1;

	// set first column value
	unset ($firstcolumnnewline);
	$firstcolumnnewline[1] = 1;

	for ($i=1; $i<=$columns; $i++)
	{
		if ($startnewline[$i] == "yes")
		{
			$countlinebreaks = $countlinebreaks+1;
			$firstcolumnnewline[$countlinebreaks] = $i;
		}
	}
	// set last column value
	$firstcolumnnewline[$countlinebreaks+1] = $columns+1;


/// add single line at top

echo '<form name="topline" action="'.$PHP_self.'" method="POST">';



// loop through line breaks in top line
for ($linebreakcounter=1; $linebreakcounter<=$countlinebreaks; $linebreakcounter++)
{
	// set the values to be used for outputting the lines
	$linestartcolumn = $firstcolumnnewline[$linebreakcounter];
	$lineendcolumn = $firstcolumnnewline[$linebreakcounter+1]-1;


# create table headings for top line

echo'<table border ="0" width="'.$tablewidth.'"><tr bgcolor="#333333">';

	for ($i=$linestartcolumn; $i<=$lineendcolumn; $i++)
	{
		echo'<th class="columnheading" nowrap width="'.$fieldcolumnwidth[$i].'">
		'.$columnheader[$i].'</th>';
	}

	if ($lineendcolumn==$columns and $countlinebreaks>1)
	{
		echo '<th bgcolor="purple" class="columnheading" nowrap width="60">
		options</th></tr>';
	}
	elseif ($lineendcolumn==$columns and $countlinebreaks==1)
	{
		echo '<th class="columnheading" nowrap width="60">
		options</th></tr>';
	}
	else
	{
		echo '</tr>';
	}

	echo '<tr bgcolor="#1A1F2D">';


	for ($tablecolumn=$linestartcolumn; $tablecolumn<=$lineendcolumn; $tablecolumn++)
	{
		if ($tablecolumn==$columns)
		{
			$nextfield = "nextfield = 'update'; formname = 'topline'";
		}
		else
		{
			$nextfield = "nextfield = 'toplinedata".($tablecolumn+1)."'; formname = 'topline'";
		}

		if ($fieldtype[$tablecolumn]=='text')
		{
			# sets field to a custom default if empty and applicable
			if ($toplinedataoutput[$submenuaction][$tablecolumn-1]=='' and $defaultvalue[$tablecolumn])
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="text" class="text" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$defaultvalue[$tablecolumn].'"></td>';
			}
			else
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="text" class="text" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$toplinedataoutput[$submenuaction][$tablecolumn-1].'"></td>';
			}
		}
		elseif ($fieldtype[$tablecolumn]=='password')
		{
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
			<input type="password" class="text" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$toplinedataoutput[$submenuaction][$tablecolumn-1].'">';
		}
		elseif ($fieldtype[$tablecolumn]=='checkbox')
		{
			if ($toplinedataoutput[$submenuaction][$tablecolumn-1]=='true')
			{
				$checkboxstatus='checked';
			}
			else
			{
				$checkboxstatus='';
			}
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
			<input type="checkbox" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" '.$checkboxstatus.'>';
		}
		else
		{
			$query = $dropdownsql[$tablecolumn];
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>';
			$selectfieldname = "toplinedata$tablecolumn";

			# sets field to a custom default if empty and applicable
			if ($toplinedataoutput[$submenuaction][$tablecolumn-1]=='' and $defaultvalue[$tablecolumn])
			{
				$optionselected = $defaultvalue[$tablecolumn];
			}
			else
			{
				$optionselected = $toplinedataoutput[$submenuaction][$tablecolumn-1];
			}

			$selectwidth="".($fieldlength[$tablecolumn]*12)."px;";

			include 'moduledataentrydropdown.php';

			echo'</td>';
		}
	}

	if ($lineendcolumn==$columns)
	{
		echo'
		<td width="60"><input type="submit" class="submitbutton" name="update" value="update"></td>
		</tr></table></form><br>';
	}
}


# adding sub lines outputs

for ($x=1; $x<=$subtables; $x++)
{


# create a container for sub lines

	echo'<div id="'.$subdivid[$x].'" style="'.$subdivstyle[$x].'">';


# create table headings for sub lines

echo'<table border ="0" width="'.$subtablewidth[$x].'"><tr bgcolor="#333333">';

	for ($i=1; $i<=$subcolumns[$x]; $i++)
	{
		echo'<th class="columnheading" nowrap width="'.$subfieldcolumnwidth[$x][$i].'">
		'.$subcolumnheader[$x][$i].'</th>';
	}
	echo '<th class="columnheading" nowrap width="60">
	options</th></tr>';


/// add empty line for sub input at top

	echo '<form name="subline'.$x.'" action="'.$PHP_self.'" method="POST"><tr bgcolor="#1A1F2D">';

	for ($subtablecolumn=1; $subtablecolumn<=$subcolumns[$x]; $subtablecolumn++)
	{
		if ($subtablecolumn==$subcolumns[$x])
		{
		$nextfield = "nextfield = 'add".$x."'; formname = 'subline".$x."'";
		}
		else
		{
		$nextfield = "nextfield = 'newcolumndata".$x."".($subtablecolumn+1)."'; formname = 'subline".$x."'";
		}

		if ($subfieldtype[$x][$subtablecolumn]=='text')
		{
			echo'<td width="'.$subfieldcolumnwidth[$x][$subtablecolumn].'" nowrap>
			<input type="text" class="text" name="newcolumndata'.$x.''.$subtablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$subfieldlength[$x][$subtablecolumn].'" size="'.$subfieldsize[$x][$subtablecolumn].'"></td>';
		}
		else
		{
			$query = $subdropdownsql[$x][$subtablecolumn];
			echo'<td width="'.$subfieldcolumnwidth[$x][$subtablecolumn].'" nowrap>';
			$selectfieldname = "newcolumndata$x$subtablecolumn";
			$optionselected = "";

			$selectwidth="".($subfieldlength[$x][$subtablecolumn]*12)."px;";

			include 'moduledataentrydropdown.php';

			echo'</td>';
		}
	}
	echo'
		<td width="60"><input type="submit" class="submitbutton" name="add'.$x.'" value="add">
		<input type="hidden" name="addline" value="'.$x.'"></td></tr></form>
		<form name="outputsublines" action="'.$PHP_self.'" method="POST">
			<tr bgcolor="#1A1F2D"><td width="60">
			<input type="submit" class="submitbutton" name="delete" value="delete selected"></td></tr>';

# create output of already entered lines

	for ($i = 1; $i <= $countmultiple[$x]; $i++)
	{
		if ($alldatamultiple[$submenuaction][$x][$i]!='')
		{
			echo'<tr bgcolor="#1A1F2D">';

			for ($j = 0; $j <= ($subcolumns[$x]-1); $j++)
			{
				if ($alldatamultiple[$submenuaction][$x][$i][$j]=='')
				{
					echo "<td>&nbsp;</td>";
				}
				else
				{
					echo '<td class="columntext" width="'.$subfieldcolumnwidth[$x][$j+1].'" nowrap valign="top">
					'.$alldatamultiple[$submenuaction][$x][$i][$j].'</td>';
				}
			}
			echo '<td>
			<input type="checkbox" class="tickbox" name="deleteoid[]" value="'.$i.'">
			<input type="hidden" name="subdelete" value="'.$x.'"></td></tr>';
		}
	}
	echo '</form></table></div>';
}

?>