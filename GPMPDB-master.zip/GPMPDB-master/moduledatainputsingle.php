<?php

	$tablewidth = 760;

# tab key emulation (replace tab with enter key)

echo "<SCRIPT LANGUAGE='JavaScript'>

nextfield = 'newcolumndata1'; // name of first box on page
netscape = '';
ver = navigator.appVersion; len = ver.length;
for(iln = 0; iln < len; iln++) if (ver.charAt(iln) == '(') break;
netscape = (ver.charAt(iln+1).toUpperCase() != 'C');

function keyDown(DnEvents) { // handles keypress
// determines whether Netscape or Internet Explorer
k = (netscape) ? DnEvents.which : window.event.keyCode;
if (k == 13) { // enter key pressed
if (nextfield == 'notadd') return true; // submit, we finished all fields
else { // we're not done yet, send focus to next box
eval('document.inputline.' + nextfield + '.focus()');
return false;
      }
   }
}
document.onkeydown = keyDown; // work together to analyze keystrokes
if (netscape) document.captureEvents(Event.KEYDOWN|Event.KEYUP);
//  End -->
</script>";



# set focus to first fields
	echo '
	<script type="text/javascript">

	function setFocus()
	{
	  document.inputline.newcolumndata1.focus();
	}

	</script>
	<body onload="setFocus()">';




# start transfer of data to database

if ($commit)
{
	# get session variable

	$alldata=$_SESSION['alldata'];

	$sql = "BEGIN;";
	@$stat = pg_exec($dbh, $sql);


	# remove whitespaces left and right of string and create data with apostrophies and replace null values

	for ($i = 1; $i <= $count; $i++)
	{
		for ($j = 0; $j <= ($columns-1); $j++)
		{
			if ($alldata[$submenuaction][$i][$j]=='')
			{
				$alldatawithapostrophies[$submenuaction][$i][$j] = 'DEFAULT';
			}
			else
			{
				$alldatawithapostrophies[$submenuaction][$i][$j] = "'".$alldata[$submenuaction][$i][$j]."'";
			}
		}
	}


	# add lines to db

	$sqlpart1 = implode(", ", $columnnames);

	for ($i = 1; $i <= $count; $i++)
	{
		if ($alldata[$submenuaction][$i]!='')
		{
			$sqlpart2[$i] = implode(", ", $alldatawithapostrophies[$submenuaction][$i]);
			$sql = "INSERT INTO ".$tablename." (".$sqlpart1.", dbuser) VALUES (".$sqlpart2[$i].", '".$PHP_AUTH_USER."');";
			@$statadddata = pg_exec($dbh, $sql);
		}
	}

	# finish transaction

	$sql = "COMMIT;";
	@$stat = pg_exec($dbh, $sql);


	# create error message when upload failed

	if (!$statadddata)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('There has been an error uploading the data to the database - please check the validity of your entries!')
		</SCRIPT>";
	}
	else
	{
	unset($alldata[$submenuaction]);
	$_SESSION['alldata']=$alldata;
	}

	unset ($commit);
}
else
{
	# get session variable
	$alldata=$_SESSION['alldata'];
}


# delete line if commanded

if ($deleteline)
{
	unset ($alldata[$submenuaction][$deleteline]);
	unset ($deleteline);
	$alldata[$submenuaction]=array_values($alldata[$submenuaction]); //re-index the array
	array_unshift($alldata[$submenuaction],array()); //code uses 1 based array start so shift over and remove index 0
	unset ($alldata[$submenuaction][0]);
	$count=count($alldata[$submenuaction]);
	$_SESSION['count']=$count;
	$_SESSION['alldata']=$alldata;
}

if ($editline)
{
	// make sure that quotes come through ok
	$editdata[$editline]=$alldata[$submenuaction][$editline];
	unset ($alldata[$submenuaction][$editline]);
	$alldata[$submenuaction]=array_values($alldata[$submenuaction]); //re-index the array
	array_unshift($alldata[$submenuaction],array()); //code uses 1 based array start so shift over and remove index 0
	unset ($alldata[$submenuaction][0]);
	$count=count($alldata[$submenuaction]);
	$_SESSION['count']=$count;
	$_SESSION['alldata']=$alldata;
}

# create array from newcolumn entered data form field

	$i=1;

	while ($i <= $columns)
	{
		$var="newcolumndata$i";
		global $$var;
		$newcolumndata[] = $$var;
		$i++;
	}

# checking, if data has been passed to the form

	$entrycount = 0;

	for ($i = 0; $i <= ($columns-1); $i++)
	{
		if ($newcolumndata[$i] != '')
		{
			$entrycount++;
		}
	}



# checking validity of new data

if ($entrycount > 0)
{
	include 'componentdataentrycheck.php';
}



# adding new data to the list

if ($entrycount > 0 and $add==true)
{
	$count++;
	$_SESSION['count']=$count;

	for ($i=0; $i<=($columns-1); $i++)
	{
		if ($fieldtype[$i+1]=='checkbox')
		{
			if ($newcolumndata[$i]=='on')
			{
				$newcolumndata[$i]='true';
			}
			else
			{
				$newcolumndata[$i]='false';
			}
		}

		// strip off whitespace left and right of string
		$newcolumndata[$i]=ltrim($newcolumndata[$i]);
		$newcolumndata[$i]=rtrim($newcolumndata[$i]);

		$alldata[$submenuaction][$count][$i]=$newcolumndata[$i];
		$_SESSION['alldata']=$alldata;
	}
}

// debuglog($_SESSION, "All Data");

# send notification to commit
if(isset($alldata[$submenuaction]) && is_array($alldata[$submenuaction]))
{
	$entries = count($alldata[$submenuaction]);
} else $entries = 0;

if ($entries>=10)
{
	echo "<SCRIPT LANGUAGE='JavaScript'>
	alert('You have entered 10 or more new records - please upload your data to the database!')
	</SCRIPT>";
}



# send header

echo'<table width="100%" border="0">
  <tr bgcolor="#333333">
    <td class="heading" valign="top" colspan="3" height="30">add data to '.$submenuaction.'</td>
  </tr>';


# function bar

	echo'<tr bgcolor="#212838">';


/// add transaction button

	echo'<form name="commitlines" action="'.$PHP_self.'" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="commit" value="upload data"></td></form>';


/// add view button

	echo'<form name="viewrecententries" action="'.$sitebasefile.'?viewrecententries=yes&indexaction=edit&menuaction=editdeletedata&submenuaction='.$submenuaction.'&returnto=adddata" method="POST"><td width="15%" align="center">
	<input type="submit" class="submitbutton" name="viewrecent" value="view entries / changes of last 12h"></td></form>';

	echo'<td>&nbsp;</td>';

	echo '</tr>
	<tr><td class="emptyline" height="30">&nbsp;</td></tr>
	</table>';



# create table headings

echo'<table border ="0" width="'.$tablewidth.'"><tr bgcolor="#333333">';

	for ($i=1; $i<=$columns; $i++)
	{
		echo'<th class="columnheading" nowrap width="'.$fieldcolumnwidth[$i].'">
		'.$columnheader[$i].'</th>';
	}
	echo '<th class="columnheading" nowrap width="60">
	options</th></tr>';




# create output of already entered lines

	for ($i = 1; $i <= $count; $i++)
	{
		if ($alldata[$submenuaction][$i]!='')
		{
			echo '<tr bgcolor="#1A1F2D">';


			for ($j = 0; $j <= ($columns-1); $j++)
			{
				# enable quotation marks in fields
				$alldataoutput[$submenuaction][$i][$j]=stripslashes($alldata[$submenuaction][$i][$j]);
				$alldataoutput[$submenuaction][$i][$j]=htmlspecialchars($alldataoutput[$submenuaction][$i][$j], ENT_QUOTES);

				if ($fieldtype[$j+1]=='password')
				{
					echo "<td class='columntext' valign='top'>****************</td>";
				}
				elseif ($fieldtype[$j+1]=='checkbox')
				{
					if ($alldataoutput[$submenuaction][$i][$j]=='true')
					{
						$checkboxoutput='yes';
					}
					else
					{
						$checkboxoutput='no';
					}
					echo '<td class="columntext" width="'.$fieldcolumnwidth[$j+1].'" nowrap valign="top">
					'.$checkboxoutput.'</td>';
				}
				elseif ($alldataoutput[$submenuaction][$i][$j]=='')
				{
					echo "<td>&nbsp;</td>";
				}
				else
				{
					echo '<td class="columntext" width="'.$fieldcolumnwidth[$j+1].'" nowrap valign="top">
					'.$alldataoutput[$submenuaction][$i][$j].'</td>';
				}
			}

			echo '<td>
			<table><tr><td>
			<form name="editline" action="'.$PHP_self.'" method="POST">
			<input type="submit" class="submitbutton" name="edit" value="edit">
			<input type="hidden" name="editline" value="'.$i.'"></form>
			</td>
			<td>
			<form name="deleteline" action="'.$PHP_self.'" method="POST">
			<input type="submit" class="submitbutton" name="delete" value="delete">
			<input type="hidden" name="deleteline" value="'.$i.'"></form>
			</td></tr></table>
			</td></tr>';
		}
	}


/// add empty line for input at bottom

	echo '	<form name="inputline" action="'.$PHP_self.'" method="POST">
			<tr bgcolor="#1A1F2D">';

	for ($tablecolumn=1; $tablecolumn<=$columns; $tablecolumn++)
	{
		if ($tablecolumn==$columns)
		{
			$nextfield = "nextfield = 'add'";
		}
		else
		{
			$nextfield = "nextfield = 'newcolumndata".($tablecolumn+1)."'";
		}

		$editfieldvalue = htmlspecialchars(stripslashes($editdata[$editline][$tablecolumn-1]), ENT_QUOTES);

		if ($fieldtype[$tablecolumn]=='text')
		{
			# sets field to a custom default if empty and applicable
			if ($defaultvalue[$tablecolumn])
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>';

				if ($editline)
				{
					echo'<input type="text" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$editfieldvalue.'"></td>';
				}
				else
				{
					echo'<input type="text" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$defaultvalue[$tablecolumn].'"></td>';
				}
			}
			else
			{
				if ($editline)
				{
					echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
					<input type="text" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'" value="'.$editfieldvalue.'"></td>';
				}
				else
				{
					echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
					<input type="text" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'"></td>';
				}
			}
		}
		elseif ($fieldtype[$tablecolumn]=='checkbox')
		{
			if ($editline)
			{
				if ($editfieldvalue=='true')
				{
					$editfieldvalue='checked';
				}
				else
				{
					$editfieldvalue='';
				}
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="checkbox" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" '.$editfieldvalue.'></td>';
			}
			else
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="checkbox" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'"></td>';
			}
		}
		elseif ($fieldtype[$tablecolumn]=='password')
		{
			if ($editline)
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="password" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'"  value="'.$editfieldvalue.'"></td>';
			}
			else
			{
				echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
				<input type="password" class="text" name="newcolumndata'.$tablecolumn.'" onFocus="'.$nextfield.'" maxlength="'.$fieldlength[$tablecolumn].'" size="'.$fieldsize[$tablecolumn].'"></td>';
			}
		}
		// why do we need this bit????? there shouldn't be any toplinedata in here?!
		//elseif ($fieldtype[$tablecolumn]=='checkbox')
		//{
		//	if ($toplinedata[$submenuaction][$tablecolumn-1]=='true')
		//	{
		//		$checkboxstatus='checked';
		//	}
		//	else
		//	{
		//		$checkboxstatus='';
		//	}
		//	echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>
		//	<input type="checkbox" name="toplinedata'.$tablecolumn.'" onFocus="'.$nextfield.'" '.$checkboxstatus.'>';
		//}
		else
		{
			$query = $dropdownsql[$tablecolumn];
			echo'<td width="'.$fieldcolumnwidth[$tablecolumn].'" nowrap>';
			$selectfieldname = "newcolumndata$tablecolumn";

			# sets field to a custom default if empty and applicable
			if ($editline)
			{
				$optionselected = $editfieldvalue;
			}
			else
			{
				if ($defaultvalue[$tablecolumn])
				{
					$optionselected = $defaultvalue[$tablecolumn];
				}
				else
				{
					$optionselected = '';
				}
			}
			$selectwidth="".($fieldlength[$tablecolumn]*12)."px;";

			include 'moduledataentrydropdown.php';

			echo'</td>';
		}
	}
	echo'
		<td width="60"><input type="submit" class="submitbutton" name="add" value="add"></td>
		</tr></table></form>';

?>