<?php

if ($subtablename[$x]!='fielddata.photologspecialists' and $subtablename[$x]!='fielddata.drawinglogdigitalstorage' and $subtablename[$x]!='fielddata.synopticfeatureformphases' and $subtablename[$x]!='fielddata.synopticfeatureformrelationships' and $subtablename[$x]!='fielddata.synopticfeatureformcutfillrelationships')
{

//// create data array
	for ($i=0; $i<=$countmultiple[$x]; $i++)
	{
		$dataarray[$i]=$alldatamultiple[$submenuaction][$x][$i][0];
	}	


	if (checkforduplicates($dataarray, $newcolumndata[$x][0])==true)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>
		alert('Data validation error! The record you attempt to add exists already in this list!')
		</SCRIPT>";
		unset ($entrycount);
	}
}
?>