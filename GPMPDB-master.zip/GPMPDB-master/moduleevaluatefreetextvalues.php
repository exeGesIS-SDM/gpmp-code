<?php

	// evaluating entered filter data and releasing serialised string of valid values

	if (strlen($freetextfilter)>0)
	{
			$freetextfilter=trim($freetextfilter);
			
			$array=explode(",", $freetextfilter);
			$uniquearray=array_unique($array);

			//	RETRIEVE VALID VALUES FROM DB
	
			$statdd = pg_exec($dbh, $queryarray[$submenuaction]);
			$rowsdd = pg_numrows($statdd);
			$columnsdd = pg_numfields($statdd);
			
			for	($t = 0; $t < $rowsdd; $t++)
			{
				$datadd = pg_fetch_array($statdd, $t);
				$possiblevalues[] = $datadd[0];
			}
			
			for ($s = 0; $s < count($uniquearray); $s++)
			{
				$uniquearray[$s]=trim($uniquearray[$s]);
				
				if(in_array($uniquearray[$s], $possiblevalues)==true)
				{
					$filtervalues[$s]=$uniquearray[$s];
				}
			}
			@$filtervaluesserial = implode(", ", $filtervalues);
	}
?>