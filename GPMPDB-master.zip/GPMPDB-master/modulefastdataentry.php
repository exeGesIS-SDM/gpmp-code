<?php

# deal with all the subform fields

if ($evaluatefieldtype=="yes")
{
	for ($x=1; $x<=$subtables; $x++)
	{
 		if (count($subfieldtype[$x])==1)
		{
			for ($subtablecolumn=1; $subtablecolumn<=$subcolumns[$x]; $subtablecolumn++)
			{
				if ($subfieldtype[$x][$subtablecolumn]=="dropdown")
				{
					$subfieldtype_original[$x][$subtablecolumn]="dropdown";
					$subfieldtype[$x][$subtablecolumn]="text";
					$subfieldlength[$x][$subtablecolumn] = "255";
				}
			}
		}
	}
}
elseif ($processfastentry=="yes")
{
	// adding new data to the list

	if ($entrycount > 0 and $addline==true)
	{
		for ($i=0; $i<=($subcolumns[$x]-1); $i++)
		{
			$newcolumndata[$x][$i]=trim($newcolumndata[$x][$i]);
			
			$array=explode(",", $newcolumndata[$x][$i]);
			$uniquearray=array_unique($array);
			

			//	RETRIEVE VALID VALUES FROM DB
	
			$statdd = pg_exec($dbh, $subdropdownsql[$x][$i+1]);
			$rowsdd = pg_numrows($statdd);
			$columnsdd = pg_numfields($statdd);

			for	($t = 0; $t < $rowsdd; $t++)
			{
				$datadd = pg_fetch_array($statdd, $t);
				$possiblevalues[] = $datadd[0];
			}
			
			for ($t=0; $t<=$countmultiple[$x]; $t++)					{
				$existingvalues[]=$alldatamultiple[$submenuaction][$x][$t][0];
			}
					
			for ($s=0; $s<count($uniquearray); $s++)
			{
				$uniquearray[$s]=trim($uniquearray[$s]);
				
				if(in_array($uniquearray[$s], $possiblevalues)==true AND in_array($uniquearray[$s], $existingvalues)==false)
				{
					$countmultiple[$x]++;
					$alldatamultiple[$submenuaction][$x][$countmultiple[$x]][$i]=$uniquearray[$s];
					$_SESSION['alldatamultiple']=$alldatamultiple;
				}
			}
			$_SESSION['countmultiple']=$countmultiple;				
		}	
	}
}
?>