<?php

if(is_array($datafeaturelogsupervisors))
{
	$output_excavators = join('<br/>', $datafeaturelogsupervisors);
}
if(is_array($datafeaturelogsquares))
{
	$output_squares = join('<br/>', $datafeaturelogsquares);
}
if(is_array($datafeaturelogareas))
{
	$output_areas = join('<br/>', $datafeaturelogareas);
}
if(is_array($data_phases))
{
	$output_phases = join(', ', $data_phases);
}
if(is_array($data_grouplog))
{
	$output_grouplog = join(', ', $data_grouplog);
}




// START new TOBI April 2009
if(is_array($data_synopticfeatureform_relationships))
{
	$output_synopticfeatureform_relationships = join('<br/>', $data_synopticfeatureform_relationships);
}
if(is_array($data_synopticfeatureform_cutfillrelationships))
{
	$output_synopticfeatureform_cutfillrelationships = join('<br/>', $data_synopticfeatureform_cutfillrelationships);
}

// END new TOBI April 2009





echo <<<HTML_END
<table border="0" width="100%">
  <tr bgcolor="#42242D">
    <td class="browseresultheading" colspan="6" height="26" nowrap> feature $chosenfeature: complete feature information</td>
  </tr>
  <tr>
    <td class="browseresulttextbold" width="80" nowrap bgcolor="#333333">supervisors:</td>
    <td class="browseresulttext" width="140" nowrap bgcolor="#333333">$output_excavators</td>
    <td class="browseresulttextbold" width="60" nowrap bgcolor="#333333">date:</td>
    <td class="browseresulttext" width="90" nowrap bgcolor="#333333">$datafeaturelog[1]</td>
    <td class="browseresulttextbold" width="75" nowrap bgcolor="#333333"></td>
    <td class="browseresulttext" width="120" nowrap bgcolor="#333333"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold" width="80" nowrap valign="top" bgcolor="#333333">description:</td>
    <td class="browseresulttext" width="140" nowrap valign="top" bgcolor="#333333">$datafeaturelog[2]</td>
    <td class="browseresulttextbold" bgcolor="#333333" nowrap valign="top" width="60">squares:</td>
    <td class="browseresulttext" nowrap valign="top" bgcolor="#333333" width="90">$output_squares</td>
    <td class="browseresulttextbold" nowrap valign="top" bgcolor="#333333" width="75">areas:</td>
    <td class="browseresulttext" nowrap valign="top" bgcolor="#333333" width="120">$output_areas</td>
  </tr>
  <tr>
    <td class="browseresulttextbold" nowrap valign="top" bgcolor="#333333" width="80">extended feature description:</td>
    <td class="browseresulttext" nowrap valign="top" colspan="5" bgcolor="#333333">$datasynopticfeatureform[5]</td>
  </tr>
  <tr>
    <td class="browseresulttext" nowrap valign="top" colspan="6" height="10"></td>
  </tr>
</table>

<table border="0" width="100%">
  <colgroup style="background: #333333">
    <col width="145">
    <col width="145">
    <col width="145">
    <col width="145">
  </colgroup>
  <tr>
    <td class="browseresulttextbold">feature category:</td>
    <td class="browseresulttext">$datasynopticfeatureform[0]</td>
    <td class="browseresulttextbold">feature type:</td>
    <td class="browseresulttext">$datasynopticfeatureform[1]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">matrix group number:</td>
    <!--<td class="browseresulttext">$datasynopticfeatureform[2]</td>  used to come from synoptics, now coming from grouplog TT 01jun2011-->
	<td class="browseresulttext">$output_grouplog</td>
    <td class="browseresulttextbold">group number closed:</td>
    <td class="browseresulttext">$datasynopticfeatureform[3]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">room designations:</td>
    <td class="browseresulttext">$datasynopticfeatureform[4]</td>
    <td class="browseresulttextbold">orientation:</td>
    <td class="browseresulttext">$datasynopticfeatureform[6]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">space number:</td>
    <td class="browseresulttext">$datasynopticfeatureform[16]</td>
    <td class="browseresulttextbold">structure number:</td>
    <td class="browseresulttext">$datasynopticfeatureform[17]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">max length (m):</td>
    <td class="browseresulttext">$datasynopticfeatureform[7]</td>
    <td class="browseresulttextbold">max width (m):</td>
    <td class="browseresulttext">$datasynopticfeatureform[8]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">max vd (m):</td>
    <td class="browseresulttext">$datasynopticfeatureform[9]</td>
    <td class="browseresulttextbold">level top (m):</td>
    <td class="browseresulttext">$datasynopticfeatureform[10]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">level bottom (m):</td>
    <td class="browseresulttext">$datasynopticfeatureform[11]</td>
    <td class="browseresulttextbold">internal/external/structural/other:</td>
    <td class="browseresulttext">$datasynopticfeatureform[12]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">excavated:</td>
    <td class="browseresulttext">$datasynopticfeatureform[13]</td>
    <td class="browseresulttextbold">100% excavated:</td>
    <td class="browseresulttext">$datasynopticfeatureform[14]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">risk of contamination:</td>
    <td class="browseresulttext">$datasynopticfeatureform[15]</td>
    <td class="browseresulttextbold">full extent visible in plan:</td>
    <td class="browseresulttext">$datasynopticfeatureform[18]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">last modified:</td>
    <td class="browseresulttext">$datasynopticfeatureform[19]</td>
    <td class="browseresulttextbold">excavation notes:</td>
    <td class="browseresulttext">$datasynopticfeatureform[20]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">entity(def):</td>
    <td class="browseresulttext">$logoutput[2]</td>
    <td class="browseresulttextbold">sampleregister:</td>
    <td class="browseresulttext">$logoutput[16]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">entity (incl):</td>
    <td class="browseresulttext">$logoutput[3]</td>
    <td class="browseresulttextbold">exoticmaterials:</td>
    <td class="browseresulttext">$logoutput[17]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">phase:</td>
    <td class="browseresulttext">$output_phases</td>
    <td class="browseresulttextbold">drawinglog:</td>
    <td class="browseresulttext">$logoutput[18]</td>
  </tr>
  <tr>
    <td class="browseresulttextbold">photolog:</td>
    <td class="browseresulttext">$logoutput[19]</td>
    <td class="browseresulttextbold">bagregister:</td>
    <td class="browseresulttext">$logoutput[15]</td>
  </tr>
</table>


<!-- START new TOBI April 2009 -->
<hr/>
<table border="0" width="100%">
  <colgroup style="background: #333333">
    <col width="145">
    <col width="145">
    <col width="145">
    <col width="145">
  </colgroup>
  <tr>
    <td class="browseresulttextbold">relationships:</td>
    <td class="browseresulttext">$output_synopticfeatureform_relationships</td>
    <td class="browseresulttextbold">cut/fill relationships</td>
    <td class="browseresulttext">$output_synopticfeatureform_cutfillrelationships</td>
  </tr>
</table>
<!-- END new TOBI April 2009 -->


<hr/>
<table border="0" width="100%">
  <colgroup style="background: #333333">
    <col width="145">
    <col width="145">
    <col width="145">
    <col width="145">
  </colgroup>
  <tr>
    <td class="browseresulttextbold">feature form scan:</td>
    <td class="browseresulttext">$logoutput[1]</td>
    <td class="browseresulttextbold">* ceramics:</td>
    <td class="browseresulttext"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold">* finds:</td>
    <td class="browseresulttext"></td>
    <td class="browseresulttextbold">* sealings:</td>
    <td class="browseresulttext"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold">* lithics:</td>
    <td class="browseresulttext"></td>
    <td class="browseresulttextbold">* notebooks:</td>
    <td class="browseresulttext"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold">* botanical:</td>
    <td class="browseresulttext"></td>
    <td class="browseresulttextbold">* dsr:</td>
    <td class="browseresulttext"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold">* charcoal:</td>
    <td class="browseresulttext"></td>
    <td class="browseresulttextbold">* surveylog:</td>
    <td class="browseresulttext"></td>
  </tr>
  <tr>
    <td class="browseresulttextbold">* fauna:</td>
    <td class="browseresulttext"></td>
    <td class="browseresulttextbold">* burials:</td>
    <td class="browseresulttext"></td>
  </tr>
</table><table>
	<tr><td class="largetext" valign="bottom" height="30">* = not yet integrated into database</td></tr>
</table>
HTML_END;

?>