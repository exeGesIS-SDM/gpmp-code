<?php

		# special cases of searching
		if ($sortcolumn[1]=="bagregister.bagprefix, bagregister.bagnumber")
		{
			$sortcolumn[1]="(CASE WHEN bagregister.bagprefix IS NULL THEN '' WHEN bagregister.bagprefix IS NOT NULL THEN bagregister.bagprefix END) || '-' || (CASE WHEN bagregister.bagnumber IS NULL THEN '0' WHEN bagregister.bagnumber IS NOT NULL THEN bagregister.bagnumber END)";
		}
		if ($sortcolumn[1]=="drawinglog.season, drawinglog.drawingnumber")
		{
			$sortcolumn[1]="(CASE WHEN drawinglog.season IS NULL THEN '' WHEN drawinglog.season IS NOT NULL THEN drawinglog.season END) || '-' || (CASE WHEN drawinglog.drawingnumber IS NULL THEN '0' WHEN drawinglog.drawingnumber IS NOT NULL THEN drawinglog.drawingnumber END)";
		}
		
		
		# define freetext search
		if ($searchcolumn!='' and $searchkeywords!='')
		{
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				if ($sortcolumndisplay[$i]==$searchcolumn)
				{
					$DBsearchcolumn=$sortcolumn[$i];
				}
			}

			// create array from entered keywords
			$searchkeywordsarray = explode (",", $searchkeywords);

				// strip off whitespace left and right of keywords and add sql commands
				for	($i =0; $i < count($searchkeywordsarray); $i++)
				{
					$searchkeywordsarray[$i]=trim($searchkeywordsarray[$i]);
					$searchkeywordsarray[$i]="concat('',$DBsearchcolumn) ~* '".$searchkeywordsarray[$i]."'";
				}

			// create searchsql
			$searchsql = "AND (".implode(" OR ", $searchkeywordsarray).")";
			$searchuservariables="searchcolumn=$searchcolumn&searchkeywords=$searchkeywords";
		}

?>