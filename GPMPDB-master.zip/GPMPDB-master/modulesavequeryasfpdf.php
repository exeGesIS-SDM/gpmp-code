<?php

	// If you experience timeouts running this script, uncomment this
	// command to extend the execution-time.
	set_time_limit(600);

define('FPDF_FONTPATH','fpdf-1.85/font/');
require('fpdf-1.85/fpdfmaketable.php');


include_once 'authentication.php';



// get session variables

	$site=$_SESSION['sessionsite'];
	$query=$_SESSION['sessionquery'];
	$savename=$_SESSION['sessionsavename'];
	$query=$_SESSION['sessionquery'];
	$title=$_SESSION['sessiontitle'];
	$outputcolumn=$_SESSION['sessionoutputcolumn'];
	$outputcolumns=$_SESSION['sessionoutputcolumns'];

	$keynumberofcolumns=$_SESSION['sessionkeynumberofcolumns'];
	$keycolumn=$_SESSION['sessionkeycolumn'];
	$keytargetfield=$_SESSION['sessionkeytargetfield'];
	$keyquery=$_SESSION['sessionkeyquery'];
	$keysort=$_SESSION['sessionkeysort'];



//  CREATE THE FILENAME
# regular expressions replace removed 04-12-2006
//	$name = preg_replace('/[^a-zA-Z0-9 ]/', '-', $savename);
	$name = $savename;
	$today = date("mdy");
    $currentusername=$_SERVER['PHP_AUTH_USER'];
	$pdffilename = $name." ".$currentusername." ".$today.".pdf";



//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			// @ supresses error messages from database!

			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$columns = pg_numfields($stat);

//	CHECK IF QUERY IS CORRECT

			if	(!$stat)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br> Check your query!
				</td></tr></table>";
				die;
			}

//	CHECK IF RECORD EXISTS
			if	($rows==0)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				$norecordtext
				</td></tr></table>";
				die;
			}



//	CREATE TABLE HEADINGS FOR DATA ARRAY

			for	($i =0; $i < $columns; $i++)
			{
				// saves headings for pdf output
				$headingtext[$i]=pg_fieldname($stat, $i);
			}
			if ($keynumberofcolumns)
			{
				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyquery2 = "$keyquery[$k];";
					$keystat = pg_exec($dbh, $keyquery2);
					$keycolumns = pg_numfields($keystat);

					for	($l =0; $l < $keycolumns; $l++)
					{
						$headingtext[$l+$k+$columns-1] = pg_fieldname($keystat, $l);
					}
				}
			}




//  CREATE QUERY RESULT FOR DATA ARRAY

			for	($i = 0; $i < $rows; $i++)
			{
				$data = pg_fetch_array($stat, $i);

				for	($j = 0; $j < $columns; $j++)
				{
					$resulttext[$i][$j]=$data[$j];
				}


				if ($keynumberofcolumns)
				{
					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($data[$keycolumn[$k]], ENT_QUOTES);

						if (!$keytargetfield[$k])
						{
							$keyfieldname = pg_fieldname($stat, $keycolumn[$k]);
						}
						else
						{
							$keyfieldname = $keytargetfield[$k];
						}

						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";

						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$keyrows = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// create subquery output
						for	($l = 0; $l < $keyrows; $l++)
						{
							$keydata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								$resulttext[$i][$k-1+$columns] .= $keydata[$m];
							}
							if ($keyrows>1 and $l < ($keyrows-1))
							{
								$resulttext[$i][$k-1+$columns] .= ", ";
							}
							else
							{
							}
						}
					}
				}
			}

//	CLOSE PGSQL DATABASE

			pg_close($dbh);


// remove unwanted columns

	for($i = 0; $i < $rows; $i++)
	{
		for ($j = 0; $j < $outputcolumns; $j++)
		{
			$pdfresulttext[$i][$j]=$resulttext[$i][$outputcolumn[$j]];
		}
	}




# GENERATE PDF FILE

for($i=0;$i<$outputcolumns;$i++)
{
	$columnwidths[$i]=265/$outputcolumns;
	$header[$i]=$headingtext[$outputcolumn[$i]];
}

$pdf=new PDF_MC_Table();
// $pdf->Open(); //FPDF no longer has this method

$pdf->SetAuthor($_SERVER['PHP_AUTH_USER']);
$pdf->SetCreator("gpmp excavation database");
$pdf->SetSubject("excavation database query output");
$pdf->SetTitle($name);

$pdf->AddPage('L');
$pdf->SetFont('Arial','',9);

$pdf->SetWidths($columnwidths);
$pdf->SetMargins(15, 20);
$pdf->SetXY(15, 20);
$pdf->PageHeader($pdffilename);
$pdf->TableHeader($header);

for($i=0;$i<$rows;$i++)
{
    $pdf->Row($pdfresulttext[$i], $header, $pdffilename);
}
//force download
$pdf->Output($pdffilename, 'D');
//send to browser
//$pdf->Output($pdffilename, 'I');
//$pdf->Output();



// remove session variables
//	unset($query);
//	unset($savename);
//	unset($query);
//	unset($title);
//	unset($outputcolumn);
//	unset($outputcolumns);
//	unset($keynumberofcolumns);
//	unset($keycolumn);
//	unset($keyquery);
//	unset($keysort);

//	$_SESSION['sessionquery']=$query;
//	$_SESSION['sessionsavename']=$savename;
//	$_SESSION['sessionquery']=$query;
//	$_SESSION['sessiontitle']=$title;
//	$_SESSION['sessionoutputcolumn']=$outputcolumn;
//	$_SESSION['sessionoutputcolumns']=$outputcolumns;
//	$_SESSION['sessionkeynumberofcolumns']=$keynumberofcolumns;
//	$_SESSION['sessionkeycolumn']=$keycolumn;
//	$_SESSION['sessionkeyquery']=$keyquery;
//	$_SESSION['sessionkeysort']=$keysort;

?>