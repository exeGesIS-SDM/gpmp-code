<?php
	set_time_limit(600);

	include 'authentication.php';




if ($nosessionvariables!='yes')
// this is because of the direct download option
{

// get session variables

	$site=$_SESSION['sessionsite'];
	$query=$_SESSION['sessionquery'];
	$savename=$_SESSION['sessionsavename'];
	$query=$_SESSION['sessionquery'];
	$title=$_SESSION['sessiontitle'];
	$outputcolumn=$_SESSION['sessionoutputcolumn'];
	$outputcolumns=$_SESSION['sessionoutputcolumns'];
				
	$keynumberofcolumns=$_SESSION['sessionkeynumberofcolumns'];
	$keycolumn=$_SESSION['sessionkeycolumn'];
	$keytargetfield=$_SESSION['sessionkeytargetfield'];
	$keyquery=$_SESSION['sessionkeyquery'];
	$keysort=$_SESSION['sessionkeysort'];
}

//echo $query;

//	OPEN PGSQL DATABASE

	if	(!$dbh)
	{
		die ("The connection to the database could not be established<br>\n");
	}

//	DEFINE QUERY

 	//replaces unwanted characters from the filename and replaces with '-' symbol
   	$name = preg_replace('/[^a-zA-Z0-9 ]/', '-', $savename);

//    $name = $savename;
	$stat = pg_exec($dbh, $query);
	$rows = pg_numrows($stat);
	$columns = pg_numfields($stat);

//	CREATE FILE FOR STORING TABLE INFO
	
	$today = date("mdy");
    $currentusername=$_SERVER['PHP_AUTH_USER'];

	$file = $name." ".$currentusername." ".$today.".txt";
	
	$handle = fopen("output/$file", "w") or
		die ("cannot open file");



//	CREATE TABLE HEADINGS FOR DATA ARRAY

			for	($i =0; $i < $columns; $i++)
			{
				// saves headings for pdf output
				$headingtext[$i]=pg_fieldname($stat, $i);
			}
			if ($keynumberofcolumns)
			{
				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyquery2 = "$keyquery[$k];";
					$keystat = pg_exec($dbh, $keyquery2);						
					$keycolumns = pg_numfields($keystat);
					
					for	($l =0; $l < $keycolumns; $l++)
					{
						$headingtext[$l+$k+$columns-1] = pg_fieldname($keystat, $l);
					}
				}
			}		




//  CREATE QUERY RESULT FOR DATA ARRAY

			for	($i = 0; $i < $rows; $i++)
			{
				$data = pg_fetch_array($stat, $i);
		
				for	($j = 0; $j < $columns; $j++)
				{
					$resulttext[$i][$j]=$data[$j];
				}
			

				if ($keynumberofcolumns)
				{
					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($data[$keycolumn[$k]], ENT_QUOTES);
						
						if (!$keytargetfield[$k])
						{
							$keyfieldname = pg_fieldname($stat, $keycolumn[$k]);
						}
						else
						{
							$keyfieldname = $keytargetfield[$k];
						}
						
						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";
	
						/// query information for subquery
						
						$keystat = pg_exec($dbh, $keyquery2);						
						$keyrows = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						/// create subquery output
						for	($l = 0; $l < $keyrows; $l++)
						{
							$keydata = pg_fetch_array($keystat, $l);
					
							for	($m = 0; $m < $keycolumns; $m++)
							{
								$resulttext[$i][$k-1+$columns] .= $keydata[$m];
							}
							if ($keyrows>1 and $l < ($keyrows-1))
							{
								$resulttext[$i][$k-1+$columns] .= ", ";
							}
							else
							{
							}
						}
					}
				}			
			}

//	CLOSE PGSQL DATABASE

			pg_close($dbh);


			
//	CREATE TABLE HEADINGS

	for	($i =0; $i < $outputcolumns; $i++)
	{
		fputs($handle, $headingtext[$outputcolumn[$i]]."\t");
	}
	
	fputs($handle, "\r");

	
//	CREATE CONTENT OUTPUT

	for	($i = 0; $i < $rows; $i++)
	{
		for	($j = 0; $j < $outputcolumns; $j++)
		{
			fputs($handle, $resulttext[$i][$outputcolumn[$j]]."\t");
		}
		
		fputs($handle, "\r");
	}

//	CLOSE FILE FOR STORING TABLE INFO

	fclose($handle);


//	DOWNLOAD FILE
	
	header("Content-type: application/force-download"); 

	header("Content-Disposition: attachment; filename=$file"); 

	readfile("output/$file");

//	DELETE FILE FROM SERVER

	unlink ("output/$file");
	
	
// remove session variables
//	unset($query);
//	unset($savename);
//	unset($title);
//	unset($outputcolumn);
//	unset($outputcolumns);
//	unset($keynumberofcolumns);
//	unset($keycolumn);
//	unset($keyquery);
//	unset($keysort);
	
//	$_SESSION['sessionquery']=$query;
//	$_SESSION['sessionsavename']=$savename;
//	$_SESSION['sessiontitle']=$title;
//	$_SESSION['sessionoutputcolumn']=$outputcolumn;
//	$_SESSION['sessionoutputcolumns']=$outputcolumns;
//	$_SESSION['sessionkeynumberofcolumns']=$keynumberofcolumns;
//	$_SESSION['sessionkeycolumn']=$keycolumn;
//	$_SESSION['sessionkeyquery']=$keyquery;
//	$_SESSION['sessionkeysort']=$keysort;
?>
