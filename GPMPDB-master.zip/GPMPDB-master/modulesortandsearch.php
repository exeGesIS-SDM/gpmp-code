<?php

if ($nosortingoptions=='yes')
{

}
else
{
	echo'<table width="100%" border="0">';

	if ($fullscreen=="yes")
	{
	  $fullscreenlink = "component$menuaction.php";
	  echo '<form name="sortresults" action="'.$fullscreenlink.'?fullscreen=yes&indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&'.$specialcolumnvariables.'&returnto='.$returnto.'" method="POST">';
	}
	else
	{
	  echo '<form name="sortresults" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&'.$specialcolumnvariables.'&returnto='.$returnto.'" method="POST">';
	}


	echo'
 	 <tr> 
  	  <td colspan="7" class="emptyline" height="10">&nbsp;</td>
	  </tr>
 	 <tr> 
	    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333"> sort 
      result by:</td>
	    <td class="largetextbold" valign="top" width="22%" bgcolor="#212838">
			<select style="width: 150px" name="sort1">
			<option selected></option>';
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				echo "<option>".$sortcolumndisplay[$i]."</option>";
			}
	echo'
		</td>
   	 <td class="largetext" valign="top" align="left" width="6%" bgcolor="#333333">then 
   	   by:</td>
   	 <td class="largetext" valign="top" align="left" width="22%" bgcolor="#212838">
			<select style="width: 150px" name="sort2">
			<option selected></option>';
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				echo "<option>".$sortcolumndisplay[$i]."</option>";
			}
	echo'
		</td>
	    <td class="largetext" valign="top" align="left" width="6%" bgcolor="#333333">then 
	      by:</td>
	    <td class="largetext" valign="top" align="left" width="22%" bgcolor="#212838">
			<select style="width: 150px" name="sort3">
			<option selected></option>';
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				echo "<option>".$sortcolumndisplay[$i]."</option>";
			}
	echo'
		</td>
		<td width="6%" valign="top" bgcolor="#333333" align="center">
			<input type="hidden" name="sortsql" value="">
			<input type="submit" class="submitbutton" name="sort" value="sort"></td>
	  </tr></form>';
}
	  
if ($nosearchoptions=='yes')
{

}
else
{
	if ($fullscreen=="yes")
	{
	  $fullscreenlink = "component$menuaction.php";
	  echo '<form name="freetextsearch" action="'.$fullscreenlink.'?fullscreen=yes&indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&'.$specialcolumnvariables.'" method="POST">';
	}
	else
	{
	  echo '<form name="freetextsearch" action="'.$sitebasefile.'?indexaction='.$indexaction.'&menuaction='.$menuaction.'&submenuaction='.$submenuaction.'&'.$uservariables.'&'.$specialcolumnvariables.'" method="POST">';
	}
	
	echo'
 	 <tr> 
  	  <td colspan="7" class="emptyline" height="5">&nbsp;</td>
	  </tr>
 	 <tr> 
	    <td class="largetextbold" valign="top" width="15%" bgcolor="#333333">freetext search in:</td>
	    <td class="largetextbold" valign="top" width="22%" bgcolor="#212838">
			<select style="width: 150px" name="searchcolumn">
			<option selected></option>';
			for	($i =1; $i <= count($sortcolumn); $i++)
			{
				echo "<option>".$sortcolumndisplay[$i]."</option>";
			}
	echo'
		</td>
   	 <td class="largetext" valign="top" align="left" colspan="2" bgcolor="#333333">enter keywords separated by commas:</td>
   	 <td class="largetext" valign="top" align="left" colspan="2" bgcolor="#212838">
			<input class="text" type="text" name="searchkeywords" size="35" maxlength="100">
		</td>
		<td width="6%" valign="top" bgcolor="#333333" align="center">
			<input type="hidden" name="searchsql" value="">
			<input type="submit" class="submitbutton" name="search" value="search"></td>
	  </tr></form>';
echo'</table>';
}
?>