<?php

include_once 'authentication.php';

$query = <<<SQL_END
select
  photoid,
  imagenumber,
  date,
  facing,
  description,
  cdnumber,
  photographer
from
  fielddata.photolog
where
  valid=true
  and imagenumber=$imagenumber
SQL_END;

// XXX: early optimization!
$keynumberofcolumns = 3;
$keycolumn[1] = 0;
$keyquery[1] = "select photologfeatures.featurenumber from fielddata.photologfeatures where photologfeatures.valid=true";
$keysort[1] = "photologfeatures.featurenumber";
$keycolumn[2] = 0;
$keyquery [2] = "select photologsquares.squarename from fielddata.photologsquares where photologsquares.valid=true";
$keysort[2] = "photologsquares.squarename";
$keycolumn[3] = 0;
$keyquery [3] = "select photologareas.area from fielddata.photologareas where photologareas.valid=true";
$keysort[3] = "photologareas.area";

$photorelated_query = <<<SQL_END
select
  p.imagenumber
from
  fielddata.photologrelatedphotos p
where
  p.valid = 't'
SQL_END;
$photorelated_order = "p.imagenumber";


//	OPEN PGSQL DATABASE

			if	(!$dbh)
			{
				die ("The connection to the database could not be established<br>\n");
			}

//	DEFINE QUERY

			// @ supresses error messages from database!

			@$stat = pg_exec($dbh, $query);
			@$rows = pg_numrows($stat);
			@$columns = pg_numfields($stat);

//	CHECK IF QUERY IS CORRECT

			if	(!$stat)
			{
				echo "
				<table>
				<tr><td class='largetextyellow'>
				ERROR!!!<br><br> Check your query!
				</td></tr></table>";
				die;
			}


# get DB info about picture

	$data = pg_fetch_array($stat, $i);

	echo "<body bgcolor='#000000' text='#000000'>
		<div align='center'>

		<img src='https://gpmpfiles.esdm.co.uk/printable/".$imagenumber.".jpg'>";

	// echo"	<br>
	//		<a class='yellowlink' href='http://gpmpfiles.esdm.co.uk/printable/".$imagenumber.".jpg'>DOWNLOAD PRINTABLE VERSION</a>";


	if	($rows==0)
	{
		echo "
		<table>
		<tr><td class='largetextyellow'>
			No image information exists in database.
		</td></tr></table>";
	}
	else
	{
		echo"
		<p class='normaltext'>&nbsp;</p>

		<table border='1'><tr>";


			//	CREATE TABLE HEADINGS

			for	($i =0; $i < $columns; $i++)
			{
				echo "<th class='columnheading'>".pg_fieldname($stat, $i)."</th>";
			}

			if ($keynumberofcolumns)
			{
				for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
				{
					$keyquery2 = "$keyquery[$k];";
					$keystat = pg_exec($dbh, $keyquery2);
					$keycolumns = pg_numfields($keystat);

					for	($i =0; $i < $keycolumns; $i++)
					{
						echo "<th class='columnheading'>".pg_fieldname($keystat, $i)."</th>";
					}
				}
			}

			echo '<th class="columnheading">reated image</th>';

				echo "</tr><tr>";

				for	($j = 0; $j < $columns; $j++)
				{
					if ($data[$j]=='')
					{
						echo "<td>&nbsp;</td>";
					}
					else
					{
						echo "<td class='columntext' valign='top'>".$data[$j]."</td>";
					}
				}


				if ($keynumberofcolumns)
				{

					for ($k = 1; $k < ($keynumberofcolumns+1); $k++)
					{
						$keyvalue = htmlentities($data[$keycolumn[$k]], ENT_QUOTES);

						if (!$keytargetfieldname[$k])
						{
							$keyfieldname = pg_fieldname($stat, $keycolumn[$k]);
						}
						else
						{
							$keyfieldname = $keytargetfieldname[$k];
						}

						$keyquery2 = "$keyquery[$k] AND $keyfieldname=$keyvalue ORDER BY $keysort[$k];";

						/// query information for subquery

						$keystat = pg_exec($dbh, $keyquery2);
						$keyrows = pg_numrows($keystat);
						$keycolumns = pg_numfields($keystat);

						echo "<td class='columntext' valign='top'>";

						if ($keyrows==0)
						{
							echo "&nbsp;";
						}

						/// create subquery output
						for	($l = 0; $l < $keyrows; $l++)
						{
							$keydata = pg_fetch_array($keystat, $l);

							for	($m = 0; $m < $keycolumns; $m++)
							{
								echo "".$keydata[$m]."";
							}
							if ($keyrows>1 and $l < ($keyrows-1))
							{
								echo ", ";
							}
							else
							{
							}
						}
						echo "</td>";
					}

					// for photologrelatedphotos
					$k = htmlentities($data[0], ENT_QUOTES);
					$query = <<<SQL_END
$photorelated_query
  and p.photoid = $k
order by
  $photorelated_order
SQL_END;
					$keystat = pg_exec($dbh, $query);
					$keyrows = pg_numrows($keystat);
					if($keyrows == 0){
					  echo "<td>&nbsp;</td>";
					}else{
					  echo "<td>";
					  for($i = 0; $i < $keyrows; $i++){
					    $ar = pg_fetch_array($keystat);
					    echo '<a href="/indexstart.php?indexaction=browse&menuaction=browsephotolog&submenuaction=browsesinglephoto&includeimage=yes&imagenumber=' . $ar[0] . '">' . $ar[0] . '</a><br/>';
					  }
					}
				}

				echo "</tr></table>
					</div></body>";
	}


?>