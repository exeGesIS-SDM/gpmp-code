<?php

if ($fullscreen=='yes')
{
	include_once 'authentication.php';
	echo'<body bgcolor="#000000" text="#000000">';
}


	echo"<p class='dataentryheading'>
		meta data for gpmp excavation database raw tables</p>
		<table width='90%'><tr>
		<td class='largetext' colspan='2'>
		this section explains the meta data of the raw tables.
		</td></tr>
		<tr><td class='emptyline' height='10'>&nbsp;</td></tr>";
		
	if (!$fullscreen)
	{
		echo "<tr><td>";
		printf ("<a class='yellowlink' href=\"rawtablesmetadata.php?fullscreen=%s&indexaction=%s\" target=\"_blank\">
			printable version</a>", 'yes', $indexaction);
		echo "</td></tr>
			<tr><td class='emptyline' height='20'>&nbsp;</td></tr>";
	}

	$metadataheadings[1] = 'type:';
	$metadataheadings[2] = 'description:';	
	$metadataheadings[3] = 'columns:';
	$metadataheadings[4] = 'constraints:';
	$metadataheadings[5] = 'relationships:';

	$tablecounter = 0;
	
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'bagregister';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of bag register';
		$rawtablemetadata[$tablecounter][3] = 'bagregisterid {int8},<br>bagprefix {varchar(8)},<br>bagnumber {int4},<br>featurenumber {int4},<br>date {date},<br>bagtype {varchar(40)},<br>comments {varchar(255)},<br>category {varchar(40)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [bagregisterid], unique [bagprefix]+[bagnumber]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [bagregistersquares] on [bagregister.bagregisterid]=[bagregistersquares.bagregisterid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'bagregistersquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for field records of bag register';
		$rawtablemetadata[$tablecounter][3] = 'bagregisterid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [bagregisterid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [bagregister] on [bagregistersquares.bagregisterid]=[bagregister.bagregisterid]';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'broadareas';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'archive of generic excavation area definitions';
		$rawtablemetadata[$tablecounter][3] = 'broadareaid {int8},<br>broadareacode {varchar(5)},<br>broadareaname {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [broadareaid],<br>unique [broadareacode]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [broadareaslocalareas] on [broadareas.broadareaid]=[broadareaslocalareas.broadareaid]';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'broadareaslocalareas';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'local areas of broad areas';
		$rawtablemetadata[$tablecounter][3] = 'broadareaid {int8},<br>localareacode {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [broadareaid] + [localareacode]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [broadareas] on [broadareaslocalareas.broadareaid]=[broadareas.broadareaid],<br>
												many-to-one with [localareas] on [broadareaslocalareas.localareacode]=[localareas.localareacode]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'burialregister';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of burials and their features';
		$rawtablemetadata[$tablecounter][3] = 'burialnumber {int4},<br>featurenumber {int4},<br>burialtype {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [burialnumber]+[featurenumber]';
		$rawtablemetadata[$tablecounter][5] = 'none';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'cdinventory';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'inventory of backup CDs/DVDs';
		$rawtablemetadata[$tablecounter][3] = 'cdid {int8},<br>storagemedium {varchar(5)},<br>number {int4},<br>contents {varchar(150)},<br>giza {bool},<br>boston {bool},<br>newyork {bool}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [cdid], unique [number]';
		$rawtablemetadata[$tablecounter][5] = 'none';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'drawinglog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of drawing log';
		$rawtablemetadata[$tablecounter][3] = 'drawingid {int8},<br>season {varchar(5)},<br>drawingnumber {int2},<br>area {varchar(30)},<br>date {date},<br>drawinglabel {varchar(255)},<br>scale {int2},<br>checked {varchar(3)},<br>cd {int2},<br>drawingtype {varchar(20)},<br>portfolionumber {int2},<br>locationoriginal {varchar(20)},<br>copied {varchar(3)},<br>scanned {varchar(3)},<br>cropped {varchar(3)},<br>renamed {varchar(3)},<br>burnttocd {varchar(3)},<br>scanuploaded {varchar(3)},<br>drawingsenttoboston {date}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [drawingid]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [drawinglogfeatures] on [drawinglog.drawingid]=[drawinglogfeatures.drawingid],<br>
									one-to-many with [drawinglogsquares] on [drawinglog.drawingid]=[drawinglogsquares.drawingid],<br>
									one-to-many with [drawinglogsupervisors] on [drawinglog.drawingid]=[drawinglogsupervisors.drawingid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'drawinglogfeatures';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'features of field records of drawing log';
		$rawtablemetadata[$tablecounter][3] = 'drawingid {int8},<br>featurenumber {int4}';
		$rawtablemetadata[$tablecounter][4] = 'unique [drawingid]+[featurenumber]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [drawinglog] on [drawinglogfeatures.drawingid]=[drawinglog.drawingid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'drawinglogsquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares of field records of drawing log';
		$rawtablemetadata[$tablecounter][3] = 'drawingid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [drawingid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [drawinglog] on [drawinglogsquares.drawingid]=[drawinglog.drawingid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'drawinglogsupervisors';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'supervisors of field records of drawing log';
		$rawtablemetadata[$tablecounter][3] = 'drawingid {int8},<br>supervisor {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [drawingid]+[supervisor]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [drawinglog] on [drawinglogsupervisors.drawingid]=[drawinglog.drawingid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'entitylog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'post-ex records of entity log';
		$rawtablemetadata[$tablecounter][3] = 'entitynumber {int4},<br>entitytype {varchar(25)},<br>entityname {varchar(100)},<br>excavationarea {varchar(30)},<br>date {date},<br>supervisor {varchar(5)},<br>description {varchar(255)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [entitynumber]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [entitylogchanges] on [entitylog.entitynumber]=[entitylogchanges.entitynumber],<br>
									one-to-many with [entitylogdefinedbyfeaturenumbers] on [entitylog.entitynumber]=[entitylogdefinedbyfeaturenumbers.entitynumber],<br>
									one-to-many with [entitylogincludesentitynumbers] on [entitylog.entitynumber]=[entitylogincludesentitynumbers.entitynumber],<br>
									one-to-many with [entitylogincludesfeaturenumbers] on [entitylog.entitynumber]=[entitylogincludesfeaturenumbers.entitynumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'entitylogchanges';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'changes of post-ex records of entity log';
		$rawtablemetadata[$tablecounter][3] = 'entitynumber {int4},<br>date {date},<br>supervisor {varchar(5)},<br>description {varchar(200)}';
		$rawtablemetadata[$tablecounter][4] = 'none';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [entitylog] on [entitylogchanges.entitynumber]=[entitylog.entitynumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'entitylogdefinedbyfeaturenumbers';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'features an entity of the entity log is defined by';
		$rawtablemetadata[$tablecounter][3] = 'entitynumber {int4},<br>definedbyfeaturenumber {int4}';
		$rawtablemetadata[$tablecounter][4] = 'unique [entitynumber]+[definedbyfeaturenumber]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [entitylog] on [entitylogdefinedbyfeaturenumbers.entitynumber]=[entitylog.entitynumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'entitylogincludesentitynumbers';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'entities an entity of the entity log includes';
		$rawtablemetadata[$tablecounter][3] = 'entitynumber {int4},<br>inclentitynumber {int4}';
		$rawtablemetadata[$tablecounter][4] = 'unique [entitynumber]+[inclentitynumber]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [entitylog] on [entitylogincludesentitynumbers.entitynumber]=[entitylog.entitynumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'entitylogincludesfeaturenumbers';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'features an entity of the entity log includes';
		$rawtablemetadata[$tablecounter][3] = 'entitynumber {int4},<br>inclfeaturenumber {int4}';
		$rawtablemetadata[$tablecounter][4] = 'unique [entitynumber]+[inclfeaturenumber]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [entitylog] on [entitylogincludesfeaturenumbers.entitynumber]=[entitylog.entitynumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'exoticmaterialregister';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of exotic material register';
		$rawtablemetadata[$tablecounter][3] = 'exoticmaterialregisterid {int8},<br>featurenumber {int4},<br>date {date},<br>materialtype {varchar(25)},<br>count {int2},<br>weightprefix {varchar(1)},<br>weight {float4},<br>comments {varchar(100)},<br>materialcategory {varchar(25)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [exoticmaterialregisterid]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [exoticmaterialregistersquares] on [exoticmaterialregister.exoticmaterialregisterid]=[exoticmaterialregistersquares.exoticmaterialregisterid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'exoticmaterialregistersquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for field records of exotic material register';
		$rawtablemetadata[$tablecounter][3] = 'exoticmaterialregisterid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [exoticmaterialregisterid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [exoticmaterialregister] on [exoticmaterialregistersquares.exoticmaterialregisterid]=[exoticmaterialregister.exoticmaterialregisterid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'featurelog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of feature log';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>date {date},<br>description {varchar(145)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [featurenumber]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [featurelogareas] on [featurelog.featurenumber]=[featurelogareas.featurenumber],<br>
									one-to-many with [featurelogsquares] on [featurelog.featurenumber]=[featurelogsquares.featurenumber],<br>
									one-to-many with [featurelogsupervisors] on [featurelog.featurenumber]=[featurelogsupervisors.featurenumber],<br>
									one-to-many with [reassignedfeatures] on [featurelog.featurenumber]=[reassignedfeatures.featurenumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'featurelogareas';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'areas for field records of feature log';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>area {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [featurenumber]+[area]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [featurelog] on [featurelogareas.featurenumber]=[featurelog.featurenumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'featurelogsquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for field records of feature log';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [featurenumber]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [featurelog] on [featurelogsquares.featurenumber]=[featurelog.featurenumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'featurelogsupervisors';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'supervisors for field records of feature log';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>supervisor {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [featurenumber]+[supervisor]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [featurelog] on [featurelogsupervisors.featurenumber]=[featurelog.featurenumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'localareas';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'archive of historic excavation area definitions';
		$rawtablemetadata[$tablecounter][3] = 'localareaid {int8},<br>localareacode {varchar(5)},<br>localareaname {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [localareaid],<br>unique [localareacode]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [broadareaslocalareas] on [localareas.localareacode]=[broadareaslocalareas.localareacode],<br>
											one-to-many with [localareasexcavators] on [localareas.localareaid]=[localareasexcavators.localareaid],<br>
											one-to-many with [localareassquares] on [localareas.localareaid]=[localareassquares.localareaid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'localareasexcavators';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'excavators of local areas';
		$rawtablemetadata[$tablecounter][3] = 'localareaid {int8},<br>supervisor {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [localareaid] + [supervisor]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [localareas] on [localareasexcavators.localareaid]=[localareas.localareaid]';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'localareassquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares of local areas';
		$rawtablemetadata[$tablecounter][3] = 'localareaid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [localareaid] + [squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [localareas] on [localareassquares.localareaid]=[localareas.localareaid]';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'notebookscatalog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'catalog of field notebooks';
		$rawtablemetadata[$tablecounter][3] = 'notebookid {int8},<br>notebookname {varchar(50)},<br>datestarted {date},<br>datecompleted {date},<br>cdlocation {int2},<br>arearecordbinderlocation {int2},<br>comments {varchar(80)},<br>bindertype {varchar(3)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [notebookid], unique [notebookname]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [notebookscatalogareas] on [notebookscatalog.notebookid]=[notebookscatalogareas.notebookid],<br>
									one-to-many with [notebookscatalogsquares] on [notebookscatalog.notebookid]=[notebookscatalogsquares.notebookid],<br>
									one-to-many with [notebookscatalogsupervisors] on [notebookscatalog.notebookid]=[notebookscatalogsupervisors.notebookid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'notebookscatalogareas';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'areas for catalog of field notebooks';
		$rawtablemetadata[$tablecounter][3] = 'notebookid {int8},<br>area {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [notebookid]+[area]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [notebookscatalog] on [notebookscatalogareas.notebookid]=[notebookscatalog.notebookid]';
	$tablecounter++;

	$rawtablename[$tablecounter] = 'notebookscatalogsquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for catalog of field notebooks';
		$rawtablemetadata[$tablecounter][3] = 'notebookid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [notebookid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [notebookscatalog] on [notebookscatalogsquares.notebookid]=[notebookscatalog.notebookid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'notebookscatalogsupervisors';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'supervisors for catalog of field notebooks';
		$rawtablemetadata[$tablecounter][3] = 'notebookid {int8},<br>supervisor {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [notebookid]+[supervisor]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [notebookscatalog] on [notebookscatalogsupervisors.notebookid]=[notebookscatalog.notebookid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photolog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>date {date},<br>facing {varchar(9)},<br>description {varchar(150)},<br>imagenumber {int4},<br>cdnumber {int4},<br>photographer {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [photoid],<br>unique [imagenumber]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [photologareas] on [photolog.photoid]=[photologareas.photoid],<br>
									one-to-many with [photologfeatures] on [photolog.photoid]=[photologfeatures.photoid],<br>
									one-to-many with [photologsquares] on [photolog.photoid]=[photologsquares.photoid],<br>
									one-to-many with [photologspecialists] on [photolog.photoid]=[photologspecialists.photoid],<br>
									one-to-many with [photologindex] on [photolog.photoid]=[photologindex.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photologareas';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'areas for field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>area {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [photoid]+[area]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [photolog] on [photologareas.photoid]=[photolog.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photologfeatures';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'features for field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>featurenumber {int4}';
		$rawtablemetadata[$tablecounter][4] = 'unique [photoid]+[featurenumber]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [photolog] on [photologfeatures.photoid]=[photolog.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photologindex';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'index entries for field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>indexcode {varchar(7)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [photoid]+[indexcode]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [photolog] on [photologindex.photoid]=[photolog.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photologspecialists';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'specialist information about field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>specialistcategory {varchar(18)},<br>specialistid {varchar(20)}';
		$rawtablemetadata[$tablecounter][4] = 'none';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [photolog] on [photologspecialists.photoid]=[photolog.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'photologsquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for field records of photo log';
		$rawtablemetadata[$tablecounter][3] = 'photoid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [photoid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [photolog] on [photologsquares.photoid]=[photolog.photoid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'reassignedfeatures';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'reassigned features for field records of feature log';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>oldfeaturenumber {varchar(25)},<br>olddate {date}';
		$rawtablemetadata[$tablecounter][4] = 'unique [featurenumber]+[oldfeaturenumber]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-one with [featurelog] on [reassignedfeatures.featurenumber]=[featurelog.featurenumber]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'reportscatalog';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'catalog of gpmp reports';
		$rawtablemetadata[$tablecounter][3] = 'reportid {int8},<br>reportname {varchar(50)},<br>date {date},<br>reporttype {varchar(30)},<br>comments {varchar(80)},<br>cd {int2}';
		$rawtablemetadata[$tablecounter][4] = 'primary key on [reportid], unique [reportname]';
		$rawtablemetadata[$tablecounter][5] = 'one-to-many with [reportscatalogareas] on [reportscatalog.reportid]=[reportscatalogareas.reportid],<br>
									one-to-many with [reportscatalogsquares] on [reportscatalog.reportid]=[reportscatalogsquares.reportid],<br>
									one-to-many with [reportscatalogauthors] on [reportscatalog.reportid]=[reportscatalogauthors.reportid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'reportscatalogareas';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'areas for catalog of gpmp reports';
		$rawtablemetadata[$tablecounter][3] = 'reportid {int8},<br>area {varchar(50)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [reportid]+[area]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [reportscatalog] on [reportscatalogareas.reportid]=[reportscatalog.reportid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'reportscatalogsquares';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'squares for catalog of gpmp reports';
		$rawtablemetadata[$tablecounter][3] = 'reportid {int8},<br>squarename {varchar(8)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [reportid]+[squarename]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [reportscatalog] on [reportscatalogsquares.reportid]=[reportscatalog.reportid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'reportscatalogauthors';
		$rawtablemetadata[$tablecounter][1] = 'sub table';
		$rawtablemetadata[$tablecounter][2] = 'authors for catalog of gpmp reports';
		$rawtablemetadata[$tablecounter][3] = 'reportid {int8},<br>author {varchar(5)}';
		$rawtablemetadata[$tablecounter][4] = 'unique [reportid]+[author]';
		$rawtablemetadata[$tablecounter][5] = 'many-to-one with [reportscatalog] on [reportscatalogauthors.reportid]=[reportscatalog.reportid]';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'sampleregister';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'field records of sample register';
		$rawtablemetadata[$tablecounter][3] = 'samplenumber {int4},<br>date {date},<br>sampletype {varchar(50)},<br>featurenumber {int4},<br>bagnumber {int4},<br>comments {varchar(255)},<br>sampleprefix {varchar(10)}';
		$rawtablemetadata[$tablecounter][4] = 'none';
		$rawtablemetadata[$tablecounter][5] = 'none';
	$tablecounter++;
	
	$rawtablename[$tablecounter] = 'synopticfeatureform';
		$rawtablemetadata[$tablecounter][1] = 'main table';
		$rawtablemetadata[$tablecounter][2] = 'post-ex records of synoptic feature form';
		$rawtablemetadata[$tablecounter][3] = 'featurenumber {int4},<br>phase {varchar(11)},<br>matrixgroupnumber {varchar(5)},<br>featuretype {varchar(70)},<br>int_ext {varchar(10)},<br>contaminated {varchar(20)},<br>insitu {varchar(20)},<br>fullyexcavated {varchar(20)},<br>entrycomplete {bool}';
		$rawtablemetadata[$tablecounter][4] = 'unique [featurenumber]';
		$rawtablemetadata[$tablecounter][5] = 'none';
		

	// add anchor navigation
	
	echo "<tr bgcolor='#333333'><td class='helptextyellow' colspan='2'>list of content</td></tr>
			<tr bgcolor='#1A1F2D'><td class='helptext' colspan='2'>";
	for	($i=1; $i<=count($rawtablename); $i++)
	{
		echo "<a class='whitelink' href='#".$rawtablename[$i]."'>".$rawtablename[$i]."</a><br>";
	}
	echo "</td></tr><tr><td class='emptyline' height='40' colspan='2'>&nbsp;</td></tr>";
	
	
	// content
	
	for	($i=1; $i<=count($rawtablename); $i++)
	{
		echo "<tr bgcolor='#333333'><td class='largetextyellow' colspan='2'><a name='".$rawtablename[$i]."'></a>
				".$rawtablename[$i]."</td></tr>";

		for ($j=1; $j<=count($metadataheadings); $j++)
		{
			echo "<tr bgcolor='#1A1F2D' valign='top'><td class='largetextbold' width='15%'>".$metadataheadings[$j]."</td>
				<td class='largetext' width=85%>".$rawtablemetadata[$i][$j]."</td></tr>";
		}
		echo "<tr><td class='emptyline' height='20' colspan='2'>&nbsp;</td></tr>";
	}

		
if ($fullscreen=='yes')
{
	echo'
		<script language="JavaScript">
		<!--
		if (window.print){ window.print(); }
		// -->
		</script>
	';
}
?>